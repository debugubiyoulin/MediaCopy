﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;

namespace MediaCopyAssistant
{
    public partial class SnakeForm : Form
    {
        // 游戏常量
        private const int GRID_SIZE = 20;
        private const int GRID_WIDTH = 30;
        private const int GRID_HEIGHT = 20;
        private const int SIDEBAR_WIDTH = 200;

        // 游戏变量
        private List<Point> snake;
        private Point food;
        private Direction currentDirection;
        private Direction nextDirection;
        private int score;
        private bool isGameOver;
        private bool isPaused;
        private Random random;
        private Timer gameTimer;

        // 颜色定义
        private Color snakeColor = Color.LimeGreen;
        private Color snakeHeadColor = Color.Green;
        private Color foodColor = Color.Red;
        private Color backgroundColor = Color.Black;
        private Color gridColor = Color.FromArgb(50, 50, 50);

        // 方向枚举
        private enum Direction
        {
            Up,
            Down,
            Left,
            Right
        }

        public SnakeForm()
        {
            InitializeComponent();
            InitializeGame();
        }

        /// <summary>
        /// 获取默认字体
        /// </summary>
        private Font GetDefaultFont(float size, FontStyle style = FontStyle.Regular)
        {
            try
            {
                return new Font("得意黑", size + 1, style);
            }
            catch
            {
                return new Font("微软雅黑", size, style);
            }
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // SnakeForm
            // 
            this.ClientSize = new System.Drawing.Size(GRID_WIDTH * GRID_SIZE + SIDEBAR_WIDTH, GRID_HEIGHT * GRID_SIZE);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "贪吃蛇";
            this.BackColor = backgroundColor;
            this.DoubleBuffered = true;
            this.KeyPreview = true;
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.SnakeForm_KeyDown);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.SnakeForm_Paint);
            this.Icon = MediaCopyAssistant.Properties.Resources.贪吃蛇;
            this.ResumeLayout(false);
        }

        private void InitializeGame()
        {
            // 初始化游戏变量
            random = new Random();
            score = 0;
            isGameOver = false;
            isPaused = false;

            // 初始化蛇
            snake = new List<Point>();
            int startX = GRID_WIDTH / 2;
            int startY = GRID_HEIGHT / 2;

            // 创建初始蛇身（3个格子）
            for (int i = 0; i < 3; i++)
            {
                snake.Add(new Point(startX - i, startY));
            }

            // 设置初始方向
            currentDirection = Direction.Right;
            nextDirection = Direction.Right;

            // 生成食物
            GenerateFood();

            // 创建游戏计时器
            gameTimer = new Timer();
            gameTimer.Interval = 150; // 游戏速度
            gameTimer.Tick += new EventHandler(GameTimer_Tick);
            gameTimer.Start();

            // 设置窗口大小
            this.ClientSize = new Size(GRID_WIDTH * GRID_SIZE + SIDEBAR_WIDTH, GRID_HEIGHT * GRID_SIZE);
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            if (!isPaused && !isGameOver)
            {
                UpdateGame();
            }
            this.Invalidate();
        }

        private void UpdateGame()
        {
            // 更新方向
            currentDirection = nextDirection;

            // 计算新的头部位置
            Point newHead = snake[0];
            switch (currentDirection)
            {
                case Direction.Up:
                    newHead.Y--;
                    break;
                case Direction.Down:
                    newHead.Y++;
                    break;
                case Direction.Left:
                    newHead.X--;
                    break;
                case Direction.Right:
                    newHead.X++;
                    break;
            }

            // 检查碰撞
            if (CheckCollision(newHead))
            {
                GameOver();
                return;
            }

            // 移动蛇
            snake.Insert(0, newHead);

            // 检查是否吃到食物
            if (newHead == food)
            {
                score += 10;
                GenerateFood();

                // 每得50分加速一次
                if (score % 50 == 0 && gameTimer.Interval > 50)
                {
                    gameTimer.Interval -= 10;
                }
            }
            else
            {
                // 如果没有吃到食物，移除尾部
                snake.RemoveAt(snake.Count - 1);
            }
        }

        private bool CheckCollision(Point head)
        {
            // 检查墙壁碰撞
            if (head.X < 0 || head.X >= GRID_WIDTH || head.Y < 0 || head.Y >= GRID_HEIGHT)
            {
                return true;
            }

            // 检查自身碰撞（从第二个身体部分开始检查）
            for (int i = 1; i < snake.Count; i++)
            {
                if (head == snake[i])
                {
                    return true;
                }
            }

            return false;
        }

        private void GenerateFood()
        {
            while (true)
            {
                food = new Point(random.Next(GRID_WIDTH), random.Next(GRID_HEIGHT));

                // 确保食物不会生成在蛇身上
                bool onSnake = false;
                foreach (Point segment in snake)
                {
                    if (food == segment)
                    {
                        onSnake = true;
                        break;
                    }
                }

                if (!onSnake) break;
            }
        }

        private void GameOver()
        {
            isGameOver = true;
            gameTimer.Stop();
        }

        private void SnakeForm_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            DrawGameBoard(g);
            DrawSnake(g);
            DrawFood(g);
            DrawSidebar(g);
            DrawGameStatus(g);
        }

        private void DrawGameBoard(Graphics g)
        {
            // 绘制游戏区域边框
            g.DrawRectangle(Pens.White, 0, 0, GRID_WIDTH * GRID_SIZE, GRID_HEIGHT * GRID_SIZE);

            // 绘制网格线
            for (int x = 0; x <= GRID_WIDTH; x++)
            {
                g.DrawLine(new Pen(gridColor), x * GRID_SIZE, 0, x * GRID_SIZE, GRID_HEIGHT * GRID_SIZE);
            }
            for (int y = 0; y <= GRID_HEIGHT; y++)
            {
                g.DrawLine(new Pen(gridColor), 0, y * GRID_SIZE, GRID_WIDTH * GRID_SIZE, y * GRID_SIZE);
            }
        }

        private void DrawSnake(Graphics g)
        {
            for (int i = 0; i < snake.Count; i++)
            {
                Point segment = snake[i];
                Color color = (i == 0) ? snakeHeadColor : snakeColor; // 头部用不同颜色

                Rectangle rect = new Rectangle(
                    segment.X * GRID_SIZE,
                    segment.Y * GRID_SIZE,
                    GRID_SIZE - 1,
                    GRID_SIZE - 1
                );

                // 绘制蛇身
                g.FillRectangle(new SolidBrush(color), rect);
                g.DrawRectangle(Pens.White, rect);

                // 为头部绘制眼睛
                if (i == 0)
                {
                    DrawSnakeEyes(g, segment);
                }
            }
        }

        private void DrawSnakeEyes(Graphics g, Point head)
        {
            int eyeSize = GRID_SIZE / 5;
            int offset = GRID_SIZE / 3;

            // 根据方向绘制眼睛
            switch (currentDirection)
            {
                case Direction.Right:
                    g.FillEllipse(Brushes.White,
                        head.X * GRID_SIZE + GRID_SIZE - offset,
                        head.Y * GRID_SIZE + offset,
                        eyeSize, eyeSize);
                    g.FillEllipse(Brushes.White,
                        head.X * GRID_SIZE + GRID_SIZE - offset,
                        head.Y * GRID_SIZE + GRID_SIZE - offset - eyeSize,
                        eyeSize, eyeSize);
                    break;
                case Direction.Left:
                    g.FillEllipse(Brushes.White,
                        head.X * GRID_SIZE + offset - eyeSize,
                        head.Y * GRID_SIZE + offset,
                        eyeSize, eyeSize);
                    g.FillEllipse(Brushes.White,
                        head.X * GRID_SIZE + offset - eyeSize,
                        head.Y * GRID_SIZE + GRID_SIZE - offset - eyeSize,
                        eyeSize, eyeSize);
                    break;
                case Direction.Up:
                    g.FillEllipse(Brushes.White,
                        head.X * GRID_SIZE + offset,
                        head.Y * GRID_SIZE + offset - eyeSize,
                        eyeSize, eyeSize);
                    g.FillEllipse(Brushes.White,
                        head.X * GRID_SIZE + GRID_SIZE - offset - eyeSize,
                        head.Y * GRID_SIZE + offset - eyeSize,
                        eyeSize, eyeSize);
                    break;
                case Direction.Down:
                    g.FillEllipse(Brushes.White,
                        head.X * GRID_SIZE + offset,
                        head.Y * GRID_SIZE + GRID_SIZE - offset,
                        eyeSize, eyeSize);
                    g.FillEllipse(Brushes.White,
                        head.X * GRID_SIZE + GRID_SIZE - offset - eyeSize,
                        head.Y * GRID_SIZE + GRID_SIZE - offset,
                        eyeSize, eyeSize);
                    break;
            }
        }

        private void DrawFood(Graphics g)
        {
            Rectangle rect = new Rectangle(
                food.X * GRID_SIZE,
                food.Y * GRID_SIZE,
                GRID_SIZE - 1,
                GRID_SIZE - 1
            );

            // 绘制食物（苹果形状）
            g.FillEllipse(new SolidBrush(foodColor), rect);

            // 绘制苹果柄
            int stemX = food.X * GRID_SIZE + GRID_SIZE / 2;
            int stemY = food.Y * GRID_SIZE;
            g.DrawLine(new Pen(Color.Brown, 2),
                stemX, stemY,
                stemX, stemY - GRID_SIZE / 4);

            // 绘制苹果叶子
            g.FillEllipse(Brushes.Green,
                stemX, stemY - GRID_SIZE / 3,
                GRID_SIZE / 4, GRID_SIZE / 6);
        }

        private void DrawSidebar(Graphics g)
        {
            int sidebarX = GRID_WIDTH * GRID_SIZE;

            // 绘制侧边栏背景
            g.FillRectangle(new SolidBrush(Color.FromArgb(40, 40, 40)),
                sidebarX, 0, SIDEBAR_WIDTH, GRID_HEIGHT * GRID_SIZE);

            // 绘制分隔线
            g.DrawLine(Pens.White, sidebarX, 0, sidebarX, GRID_HEIGHT * GRID_SIZE);
        }

        private void DrawGameStatus(Graphics g)
        {
            int startX = GRID_WIDTH * GRID_SIZE + 10;
            int startY = 20;

            string statusText = isGameOver ? "游戏结束!" : (isPaused ? "游戏暂停" : "游戏中");
            Color statusColor = isGameOver ? Color.Red : (isPaused ? Color.Yellow : Color.LightGreen);

            // 使用统一的字体方法
            g.DrawString($"状态: {statusText}",
                GetDefaultFont(12f, FontStyle.Bold),
                new SolidBrush(statusColor), startX, startY);

            g.DrawString($"分数: {score}",
                GetDefaultFont(12f, FontStyle.Bold), Brushes.White, startX, startY + 40);

            g.DrawString($"长度: {snake.Count}",
                GetDefaultFont(12f, FontStyle.Bold), Brushes.White, startX, startY + 70);

            g.DrawString($"速度: {GetSpeedText()}",
                GetDefaultFont(12f, FontStyle.Bold), Brushes.White, startX, startY + 100);

            // 绘制控制说明
            g.DrawString("控制说明:",
                GetDefaultFont(10f, FontStyle.Bold), Brushes.Yellow, startX, startY + 150);

            string[] controls = {
                "↑ ↓ ← → : 控制方向",
                "空格 : 暂停/继续",
                "R : 重新开始",
                "ESC : 退出游戏"
            };

            for (int i = 0; i < controls.Length; i++)
            {
                g.DrawString(controls[i],
                    GetDefaultFont(9f, FontStyle.Regular),
                    Brushes.LightGray, startX, startY + 180 + i * 20);
            }

            // 游戏结束时显示提示
            if (isGameOver)
            {
                g.DrawString("按 R 键重新开始",
                    GetDefaultFont(14f, FontStyle.Bold),
                    Brushes.Orange, startX, startY + 280);
            }
        }

        private string GetSpeedText()
        {
            int speedLevel = (150 - gameTimer.Interval) / 10 + 1;
            return $"{speedLevel}级";
        }

        private void SnakeForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (isGameOver)
            {
                if (e.KeyCode == Keys.R)
                {
                    RestartGame();
                }
                else if (e.KeyCode == Keys.Escape)
                {
                    this.Close();
                }
                return;
            }

            switch (e.KeyCode)
            {
                case Keys.Up:
                    if (currentDirection != Direction.Down)
                        nextDirection = Direction.Up;
                    break;

                case Keys.Down:
                    if (currentDirection != Direction.Up)
                        nextDirection = Direction.Down;
                    break;

                case Keys.Left:
                    if (currentDirection != Direction.Right)
                        nextDirection = Direction.Left;
                    break;

                case Keys.Right:
                    if (currentDirection != Direction.Left)
                        nextDirection = Direction.Right;
                    break;

                case Keys.Space:
                    TogglePause();
                    break;

                case Keys.R:
                    RestartGame();
                    break;

                case Keys.Escape:
                    this.Close();
                    break;
            }
        }

        private void TogglePause()
        {
            isPaused = !isPaused;

            if (isPaused)
            {
                gameTimer.Stop();
            }
            else
            {
                gameTimer.Start();
            }

            this.Invalidate();
        }

        private void RestartGame()
        {
            gameTimer.Stop();
            InitializeGame();
            gameTimer.Start();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            gameTimer?.Stop();
            gameTimer?.Dispose();
        }
    }
}