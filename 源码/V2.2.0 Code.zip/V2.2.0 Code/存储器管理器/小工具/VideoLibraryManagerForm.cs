﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;
using System.Collections.Concurrent;

namespace MediaCopyAssistant
{
    public partial class VideoLibraryManager : Form
    {
        #region 控件定义

        // 主布局
        private TableLayoutPanel mainLayout;
        private Panel leftPanel;
        private Panel rightPanel;

        // 左侧：数据库管理
        private Panel leftHeader;
        private Button btnNewDatabase;
        private Button btnOpenDatabase;
        private TreeView tvDatabase;
        private ContextMenuStrip treeContextMenu;

        // 右侧：标签页
        private TabControl tabMain;
        private TabPage tabStorage;      // 储存卡管理
        private TabPage tabLog;          // 操作日志
        private TabPage tabInfo;         // 库信息
        private TabPage tabHelp;         // 程序说明

        // 储存卡管理页控件
        private FlowLayoutPanel flpDriveCards;
        private Label lblDriveStatus;
        private FlowLayoutPanel flpDateFolders;  // 日期文件夹容器（大图标模式）
        private ListView lvFileList;             // 文件列表（详细信息模式）
        private Panel pnlFileBrowser;           // 文件浏览器容器
        private Button btnBack;                  // 返回按钮
        private Label lblCurrentPath;           // 当前路径显示
        private Stack<string> navigationStack;  // 导航堆栈

        // 操作日志页控件
        private TextBox txtLog;
        private Button btnClearLog;
        private Button btnSaveLog;

        // 库信息页控件
        private TextBox txtDbName;
        private TextBox txtDbPath;
        private TextBox txtCreateTime;
        private TextBox txtModifyTime;
        private TextBox txtTags;
        private Button btnSaveInfo;
        private Button btnOpenFolder;

        // 程序说明页控件
        private TextBox txtHelp;

        // 底部操作栏
        private Panel pnlBottom;
        private Panel pnlBottomLeft;     // 左边：数据库操作按钮
        private Panel pnlBottomRight;    // 右边：拷卡操作按钮
        private Button btnSelectAll;
        private Button btnSelectNone;
        private Button btnBatchRename;
        private Button btnBatchDelete;
        private Button btnBatchMove;
        private Label lblLeftSection;    // "数据库操作"标签
        private Label lblRightSection;   // "拷卡操作"标签
        private Label lblSeparator;      // 分割线

        // 拷贝操作相关控件
        private Button btnCopySelected;
        private ProgressBar pbTotalProgress;
        private ProgressBar pbCurrentProgress;
        private Label lblTotalProgress;
        private Label lblCurrentProgress;

        private TextBox txtNamingRule;
        private Button btnInsertVariable;

        // 命名规则状态标签
        private Label lblRuleStatus;

        #endregion

        #region 变量声明

        private string currentDatabasePath = "";
        private string structureFilePath = "";
        private bool isDatabaseOpen = false;

        private List<DriveInfo> removableDrives = new List<DriveInfo>();
        private System.Windows.Forms.Timer driveMonitor;
        private volatile bool driveCheckInProgress = false;

        private Dictionary<DriveInfo, Dictionary<DateTime, List<VideoFile>>> allDriveVideos = new Dictionary<DriveInfo, Dictionary<DateTime, List<VideoFile>>>();
        private Dictionary<DateTime, List<VideoFile>> currentDriveVideos = new Dictionary<DateTime, List<VideoFile>>();
        private List<VideoFile> currentDateVideos = new List<VideoFile>();
        private CancellationTokenSource scanCancellation;

        private List<CopyTask> copyTasks = new List<CopyTask>();
        private CancellationTokenSource copyCancellation;

        private StringBuilder logContent = new StringBuilder();
        private List<string> cachedLogs = new List<string>();
        private readonly object logLock = new object();

        // FFmpeg路径
        private string ffmpegPath = "";
        private string ffprobePath = "";

        // 拖动相关
        private TreeNode dragSourceNode;
        private DateTime dragStartTime;
        private bool isDragging = false;
        private Point dragStartPoint;
        private const int DRAG_DELAY_MS = 500; // 长按0.5秒触发拖动

        // 日期文件夹加载相关
        private CancellationTokenSource dateFolderCancellation;

        // 视频分析相关
        private SemaphoreSlim analysisSemaphore;
        private ConcurrentDictionary<string, bool> fileAnalysisInProgress = new ConcurrentDictionary<string, bool>();
        private ConcurrentDictionary<string, VideoFile> analyzedFiles = new ConcurrentDictionary<string, VideoFile>();
        private CancellationTokenSource videoAnalysisCancellation;

        // 命名规则
        private List<string> availableVariables = new List<string>
        {
            "{序号}", "{文件夹名}", "{原文件名}", "{分辨率}", "{帧率}",
            "{时长}", "{拍摄时间}", "{视频编码}", "{音频编码}", "{码率}"
        };

        #endregion

        #region 数据结构

        public class VideoFile
        {
            public string Path { get; set; }
            public string Name { get; set; }
            public long Size { get; set; }
            public string Resolution { get; set; } = "NULL";
            public string FrameRate { get; set; } = "NULL";
            public string VideoCodec { get; set; } = "NULL";
            public string AudioCodec { get; set; } = "NULL";
            public string Duration { get; set; } = "NULL";
            public string Bitrate { get; set; } = "NULL";
            public DateTime CreateTime { get; set; }
            public string FormattedCreateTime { get; set; }
            public string DateFolder { get; set; } // 拍摄日期文件夹
            public volatile bool IsAnalyzing = false; // 标记是否正在分析
            public volatile bool IsAnalyzed = false; // 标记是否已分析
        }

        public class CopyTask
        {
            public string Source { get; set; }
            public string Destination { get; set; }
            public string NewName { get; set; }
            public long Size { get; set; }
            public string MD5 { get; set; }
            public bool Completed { get; set; }
            public bool Verified { get; set; }
            public bool IsMove { get; set; } // 是否是移动操作
        }

        #endregion

        #region 构造函数和初始化

        public VideoLibraryManager()
        {
            InitializeComponent();
            InitializeUI();

            this.Load += VideoLibraryManager_Load;
            this.FormClosing += VideoLibraryManager_FormClosing;
            this.FormClosed += VideoLibraryManager_FormClosed;
            this.WindowState = FormWindowState.Maximized;//打开最大化
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MinimumSize = new Size(1200, 800); // 设置最小大小，防止窗口过小
            this.MaximizeBox = true; // 显示最大化按钮
            this.MinimizeBox = true; // 显示最小化按钮
            this.FormBorderStyle = FormBorderStyle.Sizable; // 允许调整大小
            this.DoubleBuffered = true;
        }

        private void InitializeComponent()
        {
            this.Text = "影视建库管理工具 ";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font = new Font("微软雅黑", 9);
            this.BackColor = Color.Black;
            this.Icon = MediaCopyAssistant.Properties.Resources.影视建库工具图标;

            CreateMainLayout();
            CreateLeftPanel();
            CreateRightPanel();
            CreateBottomPanel();
        }

        private void VideoLibraryManager_Load(object sender, EventArgs e)
        {
            // 启用双缓冲，减少闪烁
            SetStyle(ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.UserPaint, true);

            // 启用控件的双缓冲
            EnableDoubleBuffering(tvDatabase);
            EnableDoubleBuffering(lvFileList);

            // 初始化视频分析信号量（限制并发数为CPU核心数的一半，避免过度消耗资源）
            int maxConcurrent = Math.Max(1, Environment.ProcessorCount / 2);
            analysisSemaphore = new SemaphoreSlim(maxConcurrent, maxConcurrent);

            InitializeFFmpegPaths();
            StartDriveMonitoring();
            FlushCachedLogs();

            // 调整底部面板布局
            AdjustBottomPanelLayout();
        }

        // 辅助方法：启用双缓冲
        private void EnableDoubleBuffering(Control control)
        {
            try
            {
                typeof(Control).InvokeMember("DoubleBuffered",
                    BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.SetProperty,
                    null, control, new object[] { true });
            }
            catch { }
        }

        private void VideoLibraryManager_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                // 取消日期文件夹加载
                CancelDateFolderLoading();

                // 取消视频分析
                CancelVideoAnalysis();

                // 取消扫描任务
                scanCancellation?.Cancel();
                scanCancellation?.Dispose();

                // 取消拷贝任务
                copyCancellation?.Cancel();
                copyCancellation?.Dispose();

                // 停止驱动器监控
                if (driveMonitor != null)
                {
                    driveMonitor.Stop();
                    driveMonitor.Dispose();
                }

                // 释放信号量
                analysisSemaphore?.Dispose();

                // 保存日志
                SaveApplicationState();
            }
            catch (Exception ex)
            {
                Log($"关闭应用时出错: {ex.Message}");
            }
        }

        private void CancelDateFolderLoading()
        {
            try
            {
                dateFolderCancellation?.Cancel();
                dateFolderCancellation?.Dispose();
                dateFolderCancellation = null;
            }
            catch
            {
                // 忽略取消时的异常
            }
        }

        private void CancelVideoAnalysis()
        {
            try
            {
                videoAnalysisCancellation?.Cancel();
                videoAnalysisCancellation?.Dispose();
                videoAnalysisCancellation = null;
            }
            catch
            {
                // 忽略取消时的异常
            }
        }

        private void VideoLibraryManager_FormClosed(object sender, FormClosedEventArgs e)
        {
            // 强制GC清理
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }

        private void CreateMainLayout()
        {
            mainLayout = new TableLayoutPanel();
            mainLayout.Dock = DockStyle.Fill;
            mainLayout.ColumnCount = 2;
            mainLayout.RowCount = 2;
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 88));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 12));
            mainLayout.Padding = new Padding(1);
            mainLayout.BackColor = Color.Black;

            leftPanel = new Panel();
            leftPanel.Dock = DockStyle.Fill;
            leftPanel.BackColor = Color.FromArgb(30, 30, 30);
            leftPanel.BorderStyle = BorderStyle.FixedSingle;
            leftPanel.ForeColor = Color.White;

            rightPanel = new Panel();
            rightPanel.Dock = DockStyle.Fill;
            rightPanel.BackColor = Color.Black;
            rightPanel.BorderStyle = BorderStyle.FixedSingle;
            rightPanel.ForeColor = Color.White;

            // 底部面板
            pnlBottom = new Panel();
            pnlBottom.Dock = DockStyle.Fill;
            pnlBottom.BackColor = Color.FromArgb(40, 40, 40);
            pnlBottom.ForeColor = Color.White;

            mainLayout.Controls.Add(leftPanel, 0, 0);
            mainLayout.Controls.Add(rightPanel, 1, 0);
            mainLayout.Controls.Add(pnlBottom, 0, 1);
            mainLayout.SetColumnSpan(pnlBottom, 2);

            this.Controls.Add(mainLayout);
        }

        private void CreateLeftPanel()
        {
            // 数据库操作按钮区域
            leftHeader = new Panel();
            leftHeader.Dock = DockStyle.Top;
            leftHeader.Height = 100;
            leftHeader.BackColor = Color.FromArgb(40, 40, 40);
            leftHeader.Padding = new Padding(10);
            leftHeader.ForeColor = Color.White;

            btnNewDatabase = new Button();
            btnNewDatabase.Text = "新建数据库";
            btnNewDatabase.Size = new Size(150, 35);
            btnNewDatabase.Location = new Point(10, 10);
            btnNewDatabase.Click += BtnNewDatabase_Click;
            StyleButton(btnNewDatabase, true);

            btnOpenDatabase = new Button();
            btnOpenDatabase.Text = "打开数据库";
            btnOpenDatabase.Size = new Size(150, 35);
            btnOpenDatabase.Location = new Point(170, 10);
            btnOpenDatabase.Click += BtnOpenDatabase_Click;
            StyleButton(btnOpenDatabase, true);

            leftHeader.Controls.AddRange(new Control[] {
                btnNewDatabase, btnOpenDatabase
            });

            // 数据库树形结构
            tvDatabase = new TreeView();
            tvDatabase.Dock = DockStyle.Fill;
            tvDatabase.HideSelection = false;
            tvDatabase.Font = new Font("微软雅黑", 10);
            tvDatabase.BackColor = Color.FromArgb(40, 40, 40);
            tvDatabase.ForeColor = Color.White;
            tvDatabase.LineColor = Color.Gray;
            tvDatabase.AllowDrop = true;
            tvDatabase.ItemHeight = 25;
            tvDatabase.CheckBoxes = true;
            tvDatabase.LabelEdit = true;

            // 事件
            tvDatabase.AfterSelect += TvDatabase_AfterSelect;
            tvDatabase.NodeMouseClick += TvDatabase_NodeMouseClick;
            tvDatabase.MouseDoubleClick += TvDatabase_MouseDoubleClick;
            tvDatabase.MouseDown += TvDatabase_MouseDown;
            tvDatabase.MouseMove += TvDatabase_MouseMove;
            tvDatabase.MouseUp += TvDatabase_MouseUp;
            tvDatabase.ItemDrag += TvDatabase_ItemDrag;
            tvDatabase.DragEnter += TvDatabase_DragEnter;
            tvDatabase.DragOver += TvDatabase_DragOver;
            tvDatabase.DragDrop += TvDatabase_DragDrop;
            tvDatabase.AfterLabelEdit += TvDatabase_AfterLabelEdit;

            leftPanel.Controls.Add(tvDatabase);
            leftPanel.Controls.Add(leftHeader);

            // 右键菜单
            CreateTreeContextMenu();
        }

        private void CreateTreeContextMenu()
        {
            treeContextMenu = new ContextMenuStrip();
            treeContextMenu.BackColor = Color.FromArgb(40, 40, 40);
            treeContextMenu.ForeColor = Color.White;

            ToolStripMenuItem miNewFolder = new ToolStripMenuItem("新建文件夹");
            miNewFolder.Click += MiNewFolder_Click;

            ToolStripMenuItem miNewText = new ToolStripMenuItem("新建说明文件");
            miNewText.Click += MiNewText_Click;

            ToolStripMenuItem miRename = new ToolStripMenuItem("重命名");
            miRename.Click += MiRename_Click;

            ToolStripMenuItem miDelete = new ToolStripMenuItem("删除");
            miDelete.Click += MiDelete_Click;

            ToolStripMenuItem miBatchDeleteChecked = new ToolStripMenuItem("批量删除勾选文件");
            miBatchDeleteChecked.Click += MiBatchDeleteChecked_Click;

            ToolStripMenuItem miOpenFolder = new ToolStripMenuItem("打开文件夹");
            miOpenFolder.Click += MiOpenFolder_Click;

            treeContextMenu.Items.AddRange(new ToolStripItem[] {
                miNewFolder, miNewText, new ToolStripSeparator(),
                miRename, miDelete, new ToolStripSeparator(),
                miOpenFolder
            });
        }

        private void CreateRightPanel()
        {
            tabMain = new TabControl();
            tabMain.Dock = DockStyle.Fill;
            tabMain.Font = new Font("微软雅黑", 10);
            tabMain.BackColor = Color.Black;
            tabMain.ForeColor = Color.White;

            // 创建各标签页
            CreateStorageTab();
            CreateLogTab();
            CreateInfoTab();
            CreateHelpTab();

            tabMain.TabPages.AddRange(new TabPage[] {
                tabStorage, tabLog, tabInfo, tabHelp
            });

            rightPanel.Controls.Add(tabMain);
        }

        private void CreateBottomPanel()
        {
            pnlBottom.Padding = new Padding(10, 5, 10, 5);
            pnlBottom.BackColor = Color.FromArgb(40, 40, 40);

            // 创建左右两个面板
            pnlBottomLeft = new Panel();
            pnlBottomLeft.Dock = DockStyle.Left;
            pnlBottomLeft.Width = 500; // 数据库操作区域宽度
            pnlBottomLeft.BackColor = Color.Transparent;

            pnlBottomRight = new Panel();
            pnlBottomRight.Dock = DockStyle.Right;
            pnlBottomRight.Width = 800;
            pnlBottomRight.BackColor = Color.Transparent;

            // 分割线和标签 - 放到右边面板的顶部
            lblSeparator = new Label();
            lblSeparator.Text = "|";
            lblSeparator.Font = new Font("微软雅黑", 12);
            lblSeparator.ForeColor = Color.Gray;
            lblSeparator.Location = new Point(10, 5);
            lblSeparator.Size = new Size(10, 20);

            lblLeftSection = new Label();
            lblLeftSection.Text = "数据库操作";
            lblLeftSection.Font = new Font("微软雅黑", 9, FontStyle.Bold);
            lblLeftSection.ForeColor = Color.LightSkyBlue;
            lblLeftSection.Location = new Point(10, 5);
            lblLeftSection.Size = new Size(80, 20);

            lblRightSection = new Label();
            lblRightSection.Text = "拷卡操作";
            lblRightSection.Font = new Font("微软雅黑", 9, FontStyle.Bold);
            lblRightSection.ForeColor = Color.LightGreen;
            lblRightSection.Location = new Point(130, 5);
            lblRightSection.Size = new Size(80, 20);

            // 数据库操作按钮（左边）
            btnSelectAll = new Button();
            btnSelectAll.Text = "全选";
            btnSelectAll.Size = new Size(80, 30);
            btnSelectAll.Location = new Point(10, 30);
            btnSelectAll.Click += BtnSelectAll_Click;
            StyleButton(btnSelectAll);

            btnSelectNone = new Button();
            btnSelectNone.Text = "全不选";
            btnSelectNone.Size = new Size(80, 30);
            btnSelectNone.Location = new Point(100, 30);
            btnSelectNone.Click += BtnSelectNone_Click;
            StyleButton(btnSelectNone);

            btnBatchRename = new Button();
            btnBatchRename.Text = "批量重命名";
            btnBatchRename.Size = new Size(100, 30);
            btnBatchRename.Location = new Point(190, 30);
            btnBatchRename.Click += BtnBatchRename_Click;
            StyleButton(btnBatchRename);

            btnBatchDelete = new Button();
            btnBatchDelete.Text = "批量删除";
            btnBatchDelete.Size = new Size(100, 30);
            btnBatchDelete.Location = new Point(300, 30);
            btnBatchDelete.Click += BtnBatchDelete_Click;
            StyleButton(btnBatchDelete);

            btnBatchMove = new Button();
            btnBatchMove.Text = "批量移动";
            btnBatchMove.Size = new Size(100, 30);
            btnBatchMove.Location = new Point(410, 30);
            btnBatchMove.Click += BtnBatchMove_Click;
            StyleButton(btnBatchMove);

            // 拷卡操作按钮（右边） - 与左边按钮在同一水平线上
            btnCopySelected = new Button();
            btnCopySelected.Text = "拷贝选中文件";
            btnCopySelected.Size = new Size(120, 30);
            btnCopySelected.Location = new Point(130, 30);
            btnCopySelected.Click += BtnCopySelected_Click;
            StyleButton(btnCopySelected);

            // 命名规则面板 - 修改为更大的宽度
            Panel namingRulePanel = new Panel();
            namingRulePanel.Size = new Size(410, 100);
            namingRulePanel.Location = new Point(260, 30);
            namingRulePanel.BackColor = Color.Transparent;

            Label lblNamingRule = new Label();
            lblNamingRule.Text = "命名规则:";
            lblNamingRule.Location = new Point(0, 5);
            lblNamingRule.Size = new Size(60, 20);
            lblNamingRule.ForeColor = Color.White;

            txtNamingRule = new TextBox();
            txtNamingRule.Text = "{文件夹名}_{序号}";
            txtNamingRule.Location = new Point(65, 2);
            txtNamingRule.Size = new Size(250, 25);
            txtNamingRule.BackColor = Color.FromArgb(60, 60, 60);
            txtNamingRule.ForeColor = Color.White;
            txtNamingRule.Font = new Font("微软雅黑", 9);
            txtNamingRule.ScrollBars = ScrollBars.Horizontal;
            txtNamingRule.AcceptsReturn = false;
            txtNamingRule.MaxLength = 200;
            txtNamingRule.TextChanged += TxtNamingRule_TextChanged;

            // 预设字符插入按钮
            btnInsertVariable = new Button();
            btnInsertVariable.Text = "插入变量";
            btnInsertVariable.Size = new Size(75, 25);
            btnInsertVariable.Location = new Point(330, 2);
            btnInsertVariable.Click += BtnInsertVariable_Click;
            StyleButton(btnInsertVariable);

            // 示例标签
            Label lblExample = new Label();
            lblExample.Text = "可用变量: {序号} {文件夹名} {原文件名} {分辨率} {帧率} {时长} {拍摄时间}";
            lblExample.Location = new Point(0, 35);
            lblExample.Size = new Size(400, 30);
            lblExample.ForeColor = Color.LightGray;
            lblExample.Font = new Font("微软雅黑", 8);

            namingRulePanel.Controls.AddRange(new Control[] {
        lblNamingRule, txtNamingRule, btnInsertVariable, lblExample
    });

            pbTotalProgress = new ProgressBar();
            pbTotalProgress.Size = new Size(180, 18);
            pbTotalProgress.Style = ProgressBarStyle.Continuous;
            pbTotalProgress.Minimum = 0;
            pbTotalProgress.Maximum = 100;
            pbTotalProgress.Value = 0;

            pbCurrentProgress = new ProgressBar();
            pbCurrentProgress.Size = new Size(180, 18);
            pbCurrentProgress.Style = ProgressBarStyle.Continuous;
            pbCurrentProgress.Minimum = 0;
            pbCurrentProgress.Maximum = 100;
            pbCurrentProgress.Value = 0;

            lblTotalProgress = new Label();
            lblTotalProgress.Text = "总进度: 0%";
            lblTotalProgress.Size = new Size(150, 20);
            lblTotalProgress.ForeColor = Color.White;
            lblTotalProgress.Font = new Font("微软雅黑", 9);

            lblCurrentProgress = new Label();
            lblCurrentProgress.Text = "准备中...";
            lblCurrentProgress.Size = new Size(300, 20);
            lblCurrentProgress.ForeColor = Color.White;
            lblCurrentProgress.Font = new Font("微软雅黑", 9);

            // 调整进度条组件位置，因为命名规则面板变宽了
            pbTotalProgress.Location = new Point(680, 30);
            pbCurrentProgress.Location = new Point(680, 55);

            lblTotalProgress.Location = new Point(880, 30);
            lblCurrentProgress.Location = new Point(880, 55);

            // 添加到左边面板
            pnlBottomLeft.Controls.Add(lblLeftSection);
            pnlBottomLeft.Controls.Add(btnSelectAll);
            pnlBottomLeft.Controls.Add(btnSelectNone);
            pnlBottomLeft.Controls.Add(btnBatchRename);
            pnlBottomLeft.Controls.Add(btnBatchDelete);
            pnlBottomLeft.Controls.Add(btnBatchMove);

            // 添加到右边面板
            pnlBottomRight.Controls.Add(lblSeparator);
            pnlBottomRight.Controls.Add(lblRightSection);
            pnlBottomRight.Controls.Add(btnCopySelected);
            pnlBottomRight.Controls.Add(namingRulePanel);
            pnlBottomRight.Controls.Add(pbTotalProgress);
            pnlBottomRight.Controls.Add(pbCurrentProgress);
            pnlBottomRight.Controls.Add(lblTotalProgress);
            pnlBottomRight.Controls.Add(lblCurrentProgress);

            // 添加到主面板
            pnlBottom.Controls.Add(pnlBottomLeft);
            pnlBottom.Controls.Add(pnlBottomRight);
        }

        // 添加以下方法以确保控件正确显示
        private void AdjustBottomPanelLayout()
        {
            if (pnlBottom != null && pnlBottomRight != null && pnlBottomLeft != null)
            {
                // 计算右边面板的实际宽度
                int rightPanelWidth = pnlBottom.Width - pnlBottomLeft.Width;
                if (rightPanelWidth > 0)
                {
                    pnlBottomRight.Width = rightPanelWidth;
                }
            }
        }

        // 添加窗口大小改变事件
        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            AdjustBottomPanelLayout();
        }

        #endregion

        #region 储存卡管理页

        private void CreateStorageTab()
        {
            tabStorage = new TabPage("储存卡管理");
            tabStorage.Padding = new Padding(5);
            tabStorage.BackColor = Color.Black;
            tabStorage.ForeColor = Color.White;

            // 初始化导航堆栈
            navigationStack = new Stack<string>();

            // 储存卡状态显示
            lblDriveStatus = new Label();
            lblDriveStatus.Text = "未检测到储存卡";
            lblDriveStatus.Dock = DockStyle.Top;
            lblDriveStatus.Height = 30;
            lblDriveStatus.ForeColor = Color.White;
            lblDriveStatus.Font = new Font("微软雅黑", 10, FontStyle.Bold);
            lblDriveStatus.TextAlign = ContentAlignment.MiddleLeft;
            lblDriveStatus.Padding = new Padding(10, 0, 0, 0);

            // 储存卡卡片容器
            Panel driveCardContainer = new Panel();
            driveCardContainer.Dock = DockStyle.Top;
            driveCardContainer.Height = 80;
            driveCardContainer.BackColor = Color.FromArgb(40, 40, 40);
            driveCardContainer.ForeColor = Color.White;

            flpDriveCards = new FlowLayoutPanel();
            flpDriveCards.Dock = DockStyle.Fill;
            flpDriveCards.AutoScroll = true;
            flpDriveCards.BackColor = Color.FromArgb(40, 40, 40);
            flpDriveCards.ForeColor = Color.White;

            driveCardContainer.Controls.Add(flpDriveCards);

            // 文件浏览器容器
            pnlFileBrowser = new Panel();
            pnlFileBrowser.Dock = DockStyle.Fill;
            pnlFileBrowser.BackColor = Color.Black;
            pnlFileBrowser.ForeColor = Color.White;

            // 导航栏
            Panel pnlNavigation = new Panel();
            pnlNavigation.Dock = DockStyle.Top;
            pnlNavigation.Height = 40;
            pnlNavigation.BackColor = Color.FromArgb(50, 50, 50);
            pnlNavigation.Padding = new Padding(5);

            btnBack = new Button();
            btnBack.Text = "← 返回";
            btnBack.Size = new Size(80, 30);
            btnBack.Location = new Point(10, 5);
            btnBack.Enabled = false;
            btnBack.Click += BtnBack_Click;
            StyleButton(btnBack);

            lblCurrentPath = new Label();
            lblCurrentPath.Text = "拍摄日期文件夹";
            lblCurrentPath.Location = new Point(100, 5);
            lblCurrentPath.Size = new Size(500, 30);
            lblCurrentPath.TextAlign = ContentAlignment.MiddleLeft;
            lblCurrentPath.ForeColor = Color.White;

            pnlNavigation.Controls.AddRange(new Control[] { btnBack, lblCurrentPath });

            // 日期文件夹容器（大图标模式）
            flpDateFolders = new FlowLayoutPanel();
            flpDateFolders.Dock = DockStyle.Fill;
            flpDateFolders.AutoScroll = true;
            flpDateFolders.BackColor = Color.Black;
            flpDateFolders.Visible = true;
            flpDateFolders.Padding = new Padding(20);

            // 文件列表容器（详细信息模式）
            lvFileList = new ListView();
            lvFileList.Dock = DockStyle.Fill;
            lvFileList.View = View.Details;
            lvFileList.FullRowSelect = true;
            lvFileList.MultiSelect = true;
            lvFileList.BackColor = Color.FromArgb(40, 40, 40);
            lvFileList.ForeColor = Color.White;
            lvFileList.BorderStyle = BorderStyle.None;
            lvFileList.Visible = false;
            lvFileList.DoubleClick += LvFileList_DoubleClick;

            // 添加鼠标事件支持拖动
            lvFileList.MouseDown += LvFileList_MouseDown;
            lvFileList.MouseMove += LvFileList_MouseMove;
            lvFileList.MouseUp += LvFileList_MouseUp;
            lvFileList.AllowDrop = true;

            // 添加列
            lvFileList.Columns.Add("文件名", 250);
            lvFileList.Columns.Add("分辨率", 100);
            lvFileList.Columns.Add("帧率", 80);
            lvFileList.Columns.Add("时长", 100);
            lvFileList.Columns.Add("码率", 100);
            lvFileList.Columns.Add("大小", 90);
            lvFileList.Columns.Add("拍摄时间", 80);
            lvFileList.Columns.Add("编码格式", 120);

            pnlFileBrowser.Controls.Add(lvFileList);
            pnlFileBrowser.Controls.Add(flpDateFolders);
            pnlFileBrowser.Controls.Add(pnlNavigation);

            tabStorage.Controls.Add(pnlFileBrowser);
            tabStorage.Controls.Add(driveCardContainer);
            tabStorage.Controls.Add(lblDriveStatus);
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            try
            {
                // 取消正在进行的日期文件加载
                CancelDateFolderLoading();

                if (navigationStack.Count > 0)
                {
                    // 从堆栈中弹出上一级
                    string previousPath = navigationStack.Pop();
                    if (previousPath == "root")
                    {
                        // 返回到根目录（日期文件夹视图）
                        ShowDateFoldersView();
                    }
                }

                // 更新返回按钮状态
                btnBack.Enabled = navigationStack.Count > 0;
            }
            catch (Exception ex)
            {
                Log($"返回操作失败: {ex.Message}");
            }
        }

        private void ShowDateFoldersView()
        {
            flpDateFolders.Visible = true;
            lvFileList.Visible = false;
            lblCurrentPath.Text = "拍摄日期文件夹";
            UpdateDateFoldersDisplay();
        }

        private void UpdateDateFoldersDisplay()
        {
            try
            {
                // 暂停布局以加快控件添加
                flpDateFolders.SuspendLayout();
                flpDateFolders.Controls.Clear();

                if (currentDriveVideos.Count == 0)
                {
                    Label lblEmpty = new Label();
                    lblEmpty.Text = "没有找到视频文件";
                    lblEmpty.Size = new Size(200, 30);
                    lblEmpty.ForeColor = Color.Gray;
                    lblEmpty.TextAlign = ContentAlignment.MiddleCenter;
                    lblEmpty.Dock = DockStyle.Fill;
                    flpDateFolders.Controls.Add(lblEmpty);
                    flpDateFolders.ResumeLayout();
                    return;
                }

                // 设置FlowLayoutPanel的对齐方式
                flpDateFolders.FlowDirection = FlowDirection.LeftToRight;
                flpDateFolders.WrapContents = true;
                flpDateFolders.AutoScroll = true;

                // 按日期排序（从新到旧）
                var sortedDates = currentDriveVideos.Keys.OrderByDescending(d => d).ToList();

                // 预先创建所有文件夹控件
                var folderPanels = new List<Panel>();

                foreach (var date in sortedDates)
                {
                    int videoCount = currentDriveVideos[date].Count;
                    long totalSize = currentDriveVideos[date].Sum(v => v.Size);

                    // 创建文件夹控件
                    Panel folderPanel = CreateClickableDateFolderPanel(date, videoCount, totalSize);
                    folderPanels.Add(folderPanel);
                }

                // 一次性添加所有控件
                foreach (var panel in folderPanels)
                {
                    flpDateFolders.Controls.Add(panel);
                }

                flpDateFolders.ResumeLayout(true);
                flpDateFolders.PerformLayout();
                flpDateFolders.Refresh();
            }
            catch (Exception ex)
            {
                Log($"更新日期文件夹显示失败: {ex.Message}");
            }
        }

        // 更好的解决方案：使用透明容器方法
        private Panel CreateClickableDateFolderPanel(DateTime date, int fileCount, long totalSize)
        {
            // 主面板
            Panel folderPanel = new Panel();
            folderPanel.Size = new Size(180, 200);
            folderPanel.Margin = new Padding(10);
            folderPanel.BackColor = Color.FromArgb(60, 60, 60);
            folderPanel.Cursor = Cursors.Hand;
            folderPanel.Tag = date;

            // 启用双缓冲
            SetDoubleBuffered(folderPanel);

            // 创建一个透明的覆盖层，覆盖整个Panel
            Panel clickOverlay = new Panel();
            clickOverlay.Size = new Size(180, 200);
            clickOverlay.BackColor = Color.Transparent;
            clickOverlay.Cursor = Cursors.Hand;

            // 在覆盖层上绘制内容
            clickOverlay.Paint += (sender, e) =>
            {
                Graphics g = e.Graphics;
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

                // 绘制文件夹图标（居中）
                int folderIconWidth = 80;
                int folderIconHeight = 90;
                int folderIconX = (clickOverlay.Width - folderIconWidth) / 2;
                int folderIconY = 20;

                // 绘制文件夹图标
                g.FillRectangle(Brushes.Goldenrod,
                    folderIconX, folderIconY + 10, folderIconWidth, folderIconHeight - 20);
                g.FillRectangle(Brushes.Gold,
                    folderIconX + 10, folderIconY, folderIconWidth - 20, 20);
                g.DrawRectangle(Pens.DarkGoldenrod,
                    folderIconX, folderIconY + 10, folderIconWidth, folderIconHeight - 20);
                g.DrawRectangle(Pens.DarkGoldenrod,
                    folderIconX + 10, folderIconY, folderIconWidth - 20, 20);

                // 绘制日期文本
                using (Font dateFont = new Font("微软雅黑", 10, FontStyle.Bold))
                {
                    string dateText = date.ToString("yyyy年MM月dd日");
                    SizeF dateSize = g.MeasureString(dateText, dateFont);
                    int dateX = (int)((clickOverlay.Width - dateSize.Width) / 2);
                    int dateY = folderIconY + folderIconHeight + 10;

                    g.DrawString(dateText, dateFont, Brushes.White, dateX, dateY);
                }

                // 绘制文件信息
                string infoText = $"{fileCount}个文件\n{FormatFileSize(totalSize)}";
                using (Font infoFont = new Font("微软雅黑", 8))
                {
                    SizeF infoSize = g.MeasureString(infoText, infoFont);
                    int infoX = (int)((clickOverlay.Width - infoSize.Width) / 2);
                    int infoY = folderIconY + folderIconHeight + 40;

                    g.DrawString(infoText, infoFont, Brushes.LightGray, infoX, infoY);
                }
            };

            // 点击事件 - 直接在覆盖层上处理
            clickOverlay.Click += (sender, e) =>
            {
                OpenDateFolderSimple(date, folderPanel);
            };

            // 鼠标悬停效果
            clickOverlay.MouseEnter += (sender, e) =>
            {
                folderPanel.BackColor = Color.FromArgb(80, 80, 80);
                clickOverlay.Invalidate(); // 重绘
            };

            clickOverlay.MouseLeave += (sender, e) =>
            {
                folderPanel.BackColor = Color.FromArgb(60, 60, 60);
                clickOverlay.Invalidate(); // 重绘
            };

            // 将覆盖层添加到面板
            folderPanel.Controls.Add(clickOverlay);

            return folderPanel;
        }

        // 辅助方法：启用双缓冲
        private void SetDoubleBuffered(Control control)
        {
            if (SystemInformation.TerminalServerSession)
                return;

            try
            {
                System.Reflection.PropertyInfo property = typeof(Control).GetProperty(
                    "DoubleBuffered",
                    System.Reflection.BindingFlags.NonPublic |
                    System.Reflection.BindingFlags.Instance);

                if (property != null)
                {
                    property.SetValue(control, true, null);
                }
            }
            catch { }
        }

        private void OpenDateFolderSimple(DateTime date, Panel folderPanel)
        {
            try
            {
                // 1. 立即高亮选中的文件夹
                foreach (Control ctrl in flpDateFolders.Controls)
                {
                    if (ctrl is Panel panel)
                    {
                        panel.BackColor = Color.FromArgb(60, 60, 60);
                    }
                }
                folderPanel.BackColor = Color.FromArgb(80, 80, 80);

                // 2. 立即切换到文件列表视图
                SwitchToFileListDirect(date);

                // 3. 开始加载文件
                LoadDateFilesDirect(date);
            }
            catch (Exception ex)
            {
                Log($"打开日期文件夹失败: {ex.Message}");
            }
        }

        private void SwitchToFileListDirect(DateTime date)
        {
            try
            {
                // 1. 立即切换视图
                flpDateFolders.Visible = false;
                lvFileList.Visible = true;

                // 2. 显示简单的加载状态
                lvFileList.BeginUpdate();
                lvFileList.Items.Clear();

                ListViewItem loadingItem = new ListViewItem("正在加载文件...");
                loadingItem.ForeColor = Color.Gray;
                lvFileList.Items.Add(loadingItem);

                lvFileList.EndUpdate();

                // 3. 更新导航
                lblCurrentPath.Text = date.ToString("yyyy年MM月dd日") + " (正在加载)";
                navigationStack.Push("root");
                btnBack.Enabled = true;
            }
            catch (Exception ex)
            {
                Log($"切换视图失败: {ex.Message}");
            }
        }

        private async void LoadDateFilesDirect(DateTime date)
        {
            try
            {
                // 取消之前的视频分析
                CancelVideoAnalysis();
                videoAnalysisCancellation = new CancellationTokenSource();

                // 检查数据是否存在
                if (!currentDriveVideos.ContainsKey(date))
                {
                    this.Invoke(new Action(() =>
                    {
                        ShowNoFilesMessage(date);
                    }));
                    return;
                }

                // 获取该日期的所有视频
                var videos = currentDriveVideos[date];
                currentDateVideos = videos;

                // 先在UI线程显示基本文件列表
                this.Invoke(new Action(() =>
                {
                    DisplayDirectFileList(videos, date);
                }));

                // 使用多线程分析视频参数
                await StartMultiThreadedVideoAnalysis(videos);
            }
            catch (Exception ex)
            {
                Log($"加载日期文件失败 {date}: {ex.Message}");
                this.Invoke(new Action(() =>
                {
                    lvFileList.Items.Clear();
                    ListViewItem errorItem = new ListViewItem($"加载失败: {ex.Message}");
                    errorItem.ForeColor = Color.Red;
                    lvFileList.Items.Add(errorItem);
                    lblCurrentPath.Text = "加载失败";
                }));
            }
        }

        private void DisplayDirectFileList(List<VideoFile> videos, DateTime date)
        {
            try
            {
                lvFileList.BeginUpdate();
                lvFileList.Items.Clear();

                // 快速显示所有文件的基本信息
                foreach (var video in videos)
                {
                    ListViewItem item = new ListViewItem(video.Name);
                    item.Tag = video;

                    // 先显示基本信息和"等待分析"
                    item.SubItems.Add("等待分析");      // 分辨率
                    item.SubItems.Add("等待分析");      // 帧率
                    item.SubItems.Add("等待分析");      // 时长
                    item.SubItems.Add("等待分析");      // 码率
                    item.SubItems.Add(FormatFileSize(video.Size));  // 大小
                    item.SubItems.Add(video.FormattedCreateTime);   // 拍摄时间
                    item.SubItems.Add("等待分析");      // 编码格式
                    item.ForeColor = Color.Gray;

                    lvFileList.Items.Add(item);
                }

                // 更新标题
                lblCurrentPath.Text = date.ToString("yyyy年MM月dd日") + $" ({videos.Count}个文件)";

                // 自动调整列宽
                AutoResizeColumns();
                lvFileList.EndUpdate();

                Log($"显示 {videos.Count} 个文件的基本信息");
            }
            catch (Exception ex)
            {
                Log($"显示文件列表失败: {ex.Message}");
            }
        }

        private async Task StartMultiThreadedVideoAnalysis(List<VideoFile> videos)
        {
            if (videos.Count == 0 || !File.Exists(ffprobePath))
                return;

            try
            {
                Log($"开始多线程视频分析，共 {videos.Count} 个文件");

                // 清理之前的分析状态
                analyzedFiles.Clear();
                fileAnalysisInProgress.Clear();

                // 获取取消令牌
                var cancellationToken = videoAnalysisCancellation?.Token ?? CancellationToken.None;

                // 使用Parallel.ForEach进行并行处理
                await Task.Run(() =>
                {
                    try
                    {
                        Parallel.ForEach(videos, new ParallelOptions
                        {
                            MaxDegreeOfParallelism = Environment.ProcessorCount, // 使用CPU核心数
                            CancellationToken = cancellationToken
                        }, video =>
                        {
                            try
                            {
                                if (cancellationToken.IsCancellationRequested)
                                    return;

                                // 标记文件为分析中，防止重复分析
                                if (!fileAnalysisInProgress.TryAdd(video.Path, true))
                                    return;

                                video.IsAnalyzing = true;

                                // 使用FFprobe分析视频
                                var detailedVideo = GetVideoInfoWithSemaphore(video.Path);
                                if (detailedVideo != null)
                                {
                                    // 直接赋值
                                    video.Duration = detailedVideo.Duration;
                                    video.Resolution = detailedVideo.Resolution;
                                    video.FrameRate = detailedVideo.FrameRate;
                                    video.VideoCodec = detailedVideo.VideoCodec;
                                    video.AudioCodec = detailedVideo.AudioCodec;
                                    video.Bitrate = detailedVideo.Bitrate;

                                    // 标记为已分析
                                    video.IsAnalyzed = true;

                                    // 添加到已分析文件缓存
                                    analyzedFiles[video.Path] = video;

                                    // 更新UI
                                    UpdateVideoInfoInUI(video);
                                }
                            }
                            catch (OperationCanceledException)
                            {
                                Log($"视频分析被取消: {video.Name}");
                            }
                            catch (Exception ex)
                            {
                                Log($"分析视频失败 {video.Name}: {ex.Message}");
                            }
                            finally
                            {
                                // 清理分析状态
                                fileAnalysisInProgress.TryRemove(video.Path, out _);
                                video.IsAnalyzing = false;
                            }
                        });

                        if (!cancellationToken.IsCancellationRequested)
                        {
                            Log($"视频分析完成，共分析 {videos.Count(v => v.IsAnalyzed)}/{videos.Count} 个文件");
                        }
                    }
                    catch (OperationCanceledException)
                    {
                        Log("视频分析任务被取消");
                    }
                    catch (Exception ex)
                    {
                        Log($"视频分析过程出错: {ex.Message}");
                    }
                });
            }
            catch (Exception ex)
            {
                Log($"启动多线程视频分析失败: {ex.Message}");
            }
        }

        private VideoFile GetVideoInfoWithSemaphore(string filePath)
        {
            // 等待信号量，限制并发数
            analysisSemaphore?.Wait();

            try
            {
                return GetVideoInfoSync(filePath);
            }
            finally
            {
                analysisSemaphore?.Release();
            }
        }

        private VideoFile GetVideoInfoSync(string filePath)
        {
            VideoFile video = new VideoFile
            {
                Path = filePath,
                Name = Path.GetFileName(filePath),
                Size = new FileInfo(filePath).Length,
                CreateTime = File.GetCreationTime(filePath),
                FormattedCreateTime = File.GetCreationTime(filePath).ToString("yyyy-MM-dd HH:mm:ss"),
                Duration = "未知",
                Resolution = "未知",
                FrameRate = "未知",
                VideoCodec = "未知",
                AudioCodec = "未知",
                Bitrate = "未知"
            };

            try
            {
                if (!File.Exists(ffprobePath))
                {
                    return video;
                }

                // 使用FFprobe获取视频信息，包括时长和码率
                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = ffprobePath,
                    Arguments = $"-v error -select_streams v:0 -show_entries stream=width,height,r_frame_rate,codec_name,duration,bit_rate -of default=noprint_wrappers=1 \"{filePath}\"",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    StandardOutputEncoding = Encoding.UTF8
                };

                using (Process process = new Process { StartInfo = psi })
                {
                    process.Start();
                    string output = process.StandardOutput.ReadToEnd();
                    string error = process.StandardError.ReadToEnd();
                    process.WaitForExit(3000); // 3秒超时

                    // 解析输出
                    ParseFFprobeOutputForVideo(output, video);

                    // 如果有错误信息，也尝试解析
                    if (!string.IsNullOrEmpty(error))
                    {
                        ParseFFprobeOutputForVideo(error, video);
                    }
                }

                // 使用FFprobe获取音频编码信息
                ProcessStartInfo psiAudio = new ProcessStartInfo
                {
                    FileName = ffprobePath,
                    Arguments = $"-v error -select_streams a:0 -show_entries stream=codec_name -of default=noprint_wrappers=1 \"{filePath}\"",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    StandardOutputEncoding = Encoding.UTF8
                };

                using (Process process = new Process { StartInfo = psiAudio })
                {
                    process.Start();
                    string output = process.StandardOutput.ReadToEnd();
                    if (output.Contains("codec_name="))
                    {
                        string[] lines = output.Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
                        foreach (string line in lines)
                        {
                            if (line.StartsWith("codec_name="))
                            {
                                video.AudioCodec = line.Substring(11).Trim();
                                break;
                            }
                        }
                    }
                    process.WaitForExit(2000);
                }
            }
            catch (Exception ex)
            {
                Log($"获取视频信息失败 {Path.GetFileName(filePath)}: {ex.Message}");
            }

            return video;
        }

        private void UpdateVideoInfoInUI(VideoFile video)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new Action<VideoFile>(UpdateVideoInfoInUI), video);
                return;
            }

            try
            {
                // 检查ListView是否还包含这个视频
                foreach (ListViewItem item in lvFileList.Items)
                {
                    if (item.Tag is VideoFile videoInList && videoInList.Path == video.Path)
                    {
                        // 更新视频对象引用
                        item.Tag = video;

                        // 更新UI显示
                        UpdateListViewItem(item, video);
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                Log($"更新UI视频信息失败: {ex.Message}");
            }
        }

        private void UpdateListViewItem(ListViewItem item, VideoFile video)
        {
            try
            {
                // 更新分辨率
                if (video.Resolution != "未知" && video.Resolution != "NULL")
                    item.SubItems[1].Text = video.Resolution;
                else
                    item.SubItems[1].Text = "未知";

                // 更新帧率
                if (video.FrameRate != "未知" && video.FrameRate != "NULL")
                    item.SubItems[2].Text = video.FrameRate;
                else
                    item.SubItems[2].Text = "未知";

                // 更新时长
                if (video.Duration != "未知" && video.Duration != "NULL")
                    item.SubItems[3].Text = video.Duration;
                else
                    item.SubItems[3].Text = "未知";

                // 更新码率
                if (video.Bitrate != "未知" && video.Bitrate != "NULL")
                    item.SubItems[4].Text = video.Bitrate;
                else
                    item.SubItems[4].Text = "未知";

                // 更新编码信息（视频/音频）
                string codecInfo = "";
                if (video.VideoCodec != "未知" && video.VideoCodec != "NULL" &&
                    video.AudioCodec != "未知" && video.AudioCodec != "NULL")
                {
                    codecInfo = $"{video.VideoCodec}/{video.AudioCodec}";
                }
                else if (video.VideoCodec != "未知" && video.VideoCodec != "NULL")
                {
                    codecInfo = video.VideoCodec;
                }
                else if (video.AudioCodec != "未知" && video.AudioCodec != "NULL")
                {
                    codecInfo = video.AudioCodec;
                }
                else
                {
                    codecInfo = "未知";
                }
                item.SubItems[7].Text = codecInfo;

                item.ForeColor = video.IsAnalyzed ? Color.White : Color.Gray;
            }
            catch (Exception ex)
            {
                Log($"更新列表项失败: {ex.Message}");
            }
        }

        private void ParseFFprobeOutputForVideo(string output, VideoFile video)
        {
            string[] lines = output.Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string line in lines)
            {
                if (line.StartsWith("width="))
                {
                    string width = line.Substring(6).Trim();
                    if (!string.IsNullOrEmpty(width) && width != "N/A")
                        video.Resolution = width + "x";
                }
                else if (line.StartsWith("height="))
                {
                    string height = line.Substring(7).Trim();
                    if (!string.IsNullOrEmpty(height) && height != "N/A")
                    {
                        if (video.Resolution.EndsWith("x"))
                            video.Resolution += height;
                        else
                            video.Resolution = height;
                    }
                }
                else if (line.StartsWith("r_frame_rate="))
                {
                    string frameRate = line.Substring(13);
                    if (frameRate.Contains('/'))
                    {
                        string[] parts = frameRate.Split('/');
                        if (parts.Length == 2 && decimal.TryParse(parts[0], out decimal num) &&
                            decimal.TryParse(parts[1], out decimal den) && den != 0)
                        {
                            video.FrameRate = $"{num / den:F2} fps";
                        }
                    }
                    else if (decimal.TryParse(frameRate, out decimal fps))
                    {
                        video.FrameRate = $"{fps:F2} fps";
                    }
                }
                else if (line.StartsWith("codec_name="))
                {
                    string codec = line.Substring(11).Trim();
                    if (!string.IsNullOrEmpty(codec) && codec != "N/A")
                        video.VideoCodec = codec;
                }
                else if (line.StartsWith("duration="))
                {
                    if (double.TryParse(line.Substring(9), out double seconds))
                    {
                        video.Duration = FormatDuration(seconds);
                    }
                }
                else if (line.StartsWith("bit_rate="))
                {
                    if (long.TryParse(line.Substring(9), out long bitrate))
                    {
                        video.Bitrate = FormatBitrate(bitrate);
                    }
                }
            }
        }

        private int ScanSpecificFolders(string rootPath, string[] targetFolders, string[] extensions, List<string> results, Panel progressPanel = null)
        {
            int foundFoldersCount = 0;

            try
            {
                // 记录找到的目标文件夹
                List<string> foundFolders = new List<string>();

                // 首先在根目录下查找目标文件夹
                if (progressPanel != null)
                {
                    this.Invoke(new Action(() =>
                    {
                        UpdateScanProgress(progressPanel, "正在检查根目录...", 20);
                    }));
                }

                foundFoldersCount = ScanDirectoriesForTargetFolders(rootPath, targetFolders, foundFolders, 2);

                // 如果没有找到任何目标文件夹，记录日志
                if (foundFolders.Count == 0)
                {
                    Log($"在 {rootPath} 中未找到标准视频文件夹");
                }
                else
                {
                    Log($"在 {rootPath} 中找到 {foundFolders.Count} 个视频文件夹:");

                    // 在找到的文件夹中扫描视频文件
                    for (int i = 0; i < foundFolders.Count; i++)
                    {
                        string folder = foundFolders[i];

                        if (progressPanel != null)
                        {
                            this.Invoke(new Action(() =>
                            {
                                int progress = 20 + (int)((i * 60.0) / foundFolders.Count);
                                UpdateScanProgress(progressPanel, $"正在扫描文件夹: {Path.GetFileName(folder)}...", progress);
                            }));
                        }

                        ScanForVideosInFolder(folder, extensions, results);
                    }
                }
            }
            catch (UnauthorizedAccessException) { }
            catch (PathTooLongException) { }
            catch (Exception ex)
            {
                Log($"扫描文件夹时出错: {ex.Message}");
            }

            return foundFoldersCount;
        }

        private string FormatDuration(double seconds)
        {
            try
            {
                TimeSpan ts = TimeSpan.FromSeconds(seconds);

                if (ts.Hours > 0)
                {
                    return $"{ts.Hours:D2}:{ts.Minutes:D2}:{ts.Seconds:D2}";
                }
                else if (ts.Minutes > 0)
                {
                    return $"{ts.Minutes:D2}:{ts.Seconds:D2}";
                }
                else
                {
                    return $"{ts.Seconds:D2}秒";
                }
            }
            catch
            {
                return "未知";
            }
        }

        private string FormatBitrate(long bitrate)
        {
            try
            {
                if (bitrate >= 1000000) // 大于1 Mbps
                {
                    return $"{(bitrate / 1000000.0):F1} Mbps";
                }
                else if (bitrate >= 1000) // 大于1 Kbps
                {
                    return $"{(bitrate / 1000.0):F0} Kbps";
                }
                else
                {
                    return $"{bitrate} bps";
                }
            }
            catch
            {
                return "未知";
            }
        }

        private void ShowNoFilesMessage(DateTime date)
        {
            lvFileList.Items.Clear();
            ListViewItem emptyItem = new ListViewItem("没有找到该日期的文件");
            emptyItem.ForeColor = Color.Gray;
            lvFileList.Items.Add(emptyItem);
            lblCurrentPath.Text = date.ToString("yyyy年MM月dd日") + " (没有文件)";
        }

        private void AutoResizeColumns()
        {
            if (lvFileList.Columns.Count == 0 || lvFileList.Items.Count == 0)
                return;

            try
            {
                int totalWidth = lvFileList.ClientSize.Width - 25;

                // 重新分配列宽，为时长和码率留出空间
                int[] columnWidths = new int[]
                {
                    (int)(totalWidth * 0.22), // 文件名
                    (int)(totalWidth * 0.10), // 分辨率
                    (int)(totalWidth * 0.08), // 帧率
                    (int)(totalWidth * 0.08), // 时长
                    (int)(totalWidth * 0.08), // 码率
                    (int)(totalWidth * 0.08), // 大小
                    (int)(totalWidth * 0.12), // 拍摄时间
                    (int)(totalWidth * 0.16)  // 编码格式
                };

                // 设置列宽
                for (int i = 0; i < lvFileList.Columns.Count && i < columnWidths.Length; i++)
                {
                    lvFileList.Columns[i].Width = columnWidths[i];
                }
            }
            catch (Exception ex)
            {
                Log($"调整列宽失败: {ex.Message}");
            }
        }

        private void LvFileList_DoubleClick(object sender, EventArgs e)
        {
            if (lvFileList.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = lvFileList.SelectedItems[0];
                VideoFile video = selectedItem.Tag as VideoFile;

                if (video != null && File.Exists(video.Path))
                {
                    OpenVideoWithDefaultPlayer(video.Path);
                }
            }
        }

        #endregion

        #region 操作日志页

        private void CreateLogTab()
        {
            tabLog = new TabPage("操作日志");
            tabLog.Padding = new Padding(5);
            tabLog.BackColor = Color.Black;
            tabLog.ForeColor = Color.White;

            txtLog = new TextBox();
            txtLog.Dock = DockStyle.Fill;
            txtLog.Multiline = true;
            txtLog.ScrollBars = ScrollBars.Both;
            txtLog.ReadOnly = true;
            txtLog.Font = new Font("Consolas", 10);
            txtLog.BackColor = Color.FromArgb(30, 30, 30);
            txtLog.ForeColor = Color.FromArgb(220, 220, 220);
            txtLog.WordWrap = true;

            Panel pnlButtons = new Panel();
            pnlButtons.Dock = DockStyle.Bottom;
            pnlButtons.Height = 40;
            pnlButtons.Padding = new Padding(5);
            pnlButtons.BackColor = Color.FromArgb(40, 40, 40);

            btnClearLog = new Button();
            btnClearLog.Text = "清空日志";
            btnClearLog.Size = new Size(100, 30);
            btnClearLog.Location = new Point(10, 5);
            btnClearLog.Click += BtnClearLog_Click;
            StyleButton(btnClearLog);

            btnSaveLog = new Button();
            btnSaveLog.Text = "保存日志";
            btnSaveLog.Size = new Size(100, 30);
            btnSaveLog.Location = new Point(120, 5);
            btnSaveLog.Click += BtnSaveLog_Click;
            StyleButton(btnSaveLog);

            pnlButtons.Controls.AddRange(new Control[] { btnClearLog, btnSaveLog });

            tabLog.Controls.Add(txtLog);
            tabLog.Controls.Add(pnlButtons);
        }

        #endregion

        #region 库信息页

        private void CreateInfoTab()
        {
            tabInfo = new TabPage("库信息");
            tabInfo.Padding = new Padding(20);
            tabInfo.BackColor = Color.Black;
            tabInfo.ForeColor = Color.White;

            TableLayoutPanel layout = new TableLayoutPanel();
            layout.Dock = DockStyle.Fill;
            layout.ColumnCount = 2;
            layout.RowCount = 6;
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 100));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 35));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 35));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 35));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 35));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 35));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            // 数据库名称
            Label lblName = new Label();
            lblName.Text = "数据库名称:";
            lblName.TextAlign = ContentAlignment.MiddleRight;
            lblName.Dock = DockStyle.Fill;
            lblName.ForeColor = Color.White;

            txtDbName = new TextBox();
            txtDbName.Dock = DockStyle.Fill;
            txtDbName.ReadOnly = true;
            txtDbName.BackColor = Color.FromArgb(60, 60, 60);
            txtDbName.ForeColor = Color.White;
            txtDbName.BorderStyle = BorderStyle.FixedSingle;

            // 数据库路径
            Label lblPath = new Label();
            lblPath.Text = "数据库路径:";
            lblPath.TextAlign = ContentAlignment.MiddleRight;
            lblPath.Dock = DockStyle.Fill;
            lblPath.ForeColor = Color.White;

            txtDbPath = new TextBox();
            txtDbPath.Dock = DockStyle.Fill;
            txtDbPath.ReadOnly = true;
            txtDbPath.BackColor = Color.FromArgb(60, 60, 60);
            txtDbPath.ForeColor = Color.White;
            txtDbPath.BorderStyle = BorderStyle.FixedSingle;

            btnOpenFolder = new Button();
            btnOpenFolder.Text = "打开文件夹";
            btnOpenFolder.Size = new Size(100, 30);
            btnOpenFolder.Click += BtnOpenFolder_Click;
            StyleButton(btnOpenFolder);

            // 创建时间
            Label lblCreate = new Label();
            lblCreate.Text = "创建时间:";
            lblCreate.TextAlign = ContentAlignment.MiddleRight;
            lblCreate.Dock = DockStyle.Fill;
            lblCreate.ForeColor = Color.White;

            txtCreateTime = new TextBox();
            txtCreateTime.Dock = DockStyle.Fill;
            txtCreateTime.ReadOnly = true;
            txtCreateTime.BackColor = Color.FromArgb(60, 60, 60);
            txtCreateTime.ForeColor = Color.White;
            txtCreateTime.BorderStyle = BorderStyle.FixedSingle;

            // 修改时间
            Label lblModify = new Label();
            lblModify.Text = "修改时间:";
            lblModify.TextAlign = ContentAlignment.MiddleRight;
            lblModify.Dock = DockStyle.Fill;
            lblModify.ForeColor = Color.White;

            txtModifyTime = new TextBox();
            txtModifyTime.Dock = DockStyle.Fill;
            txtModifyTime.ReadOnly = true;
            txtModifyTime.BackColor = Color.FromArgb(60, 60, 60);
            txtModifyTime.ForeColor = Color.White;
            txtModifyTime.BorderStyle = BorderStyle.FixedSingle;

            // 分类标签
            Label lblTags = new Label();
            lblTags.Text = "分类标签:";
            lblTags.TextAlign = ContentAlignment.MiddleRight;
            lblTags.Dock = DockStyle.Fill;
            lblTags.ForeColor = Color.White;

            txtTags = new TextBox();
            txtTags.Dock = DockStyle.Fill;
            txtTags.TextChanged += TxtTags_TextChanged;
            txtTags.BackColor = Color.FromArgb(60, 60, 60);
            txtTags.ForeColor = Color.White;
            txtTags.BorderStyle = BorderStyle.FixedSingle;

            btnSaveInfo = new Button();
            btnSaveInfo.Text = "保存修改";
            btnSaveInfo.Size = new Size(100, 30);
            btnSaveInfo.Enabled = false;
            btnSaveInfo.Click += BtnSaveInfo_Click;
            StyleButton(btnSaveInfo);

            // 添加到布局
            layout.Controls.Add(lblName, 0, 0);
            layout.Controls.Add(txtDbName, 1, 0);
            layout.Controls.Add(lblPath, 0, 1);
            layout.Controls.Add(txtDbPath, 1, 1);

            Panel pnlPathButton = new Panel();
            pnlPathButton.Dock = DockStyle.Fill;
            pnlPathButton.BackColor = Color.Black;
            pnlPathButton.Controls.Add(btnOpenFolder);

            layout.Controls.Add(new Panel(), 0, 2);
            layout.Controls.Add(pnlPathButton, 1, 2);

            layout.Controls.Add(lblCreate, 0, 3);
            layout.Controls.Add(txtCreateTime, 1, 3);
            layout.Controls.Add(lblModify, 0, 4);
            layout.Controls.Add(txtModifyTime, 1, 4);
            layout.Controls.Add(lblTags, 0, 5);
            layout.Controls.Add(txtTags, 1, 5);

            Panel pnlSave = new Panel();
            pnlSave.Dock = DockStyle.Bottom;
            pnlSave.Height = 40;
            pnlSave.Padding = new Padding(0, 10, 0, 0);
            pnlSave.BackColor = Color.Black;
            pnlSave.Controls.Add(btnSaveInfo);

            tabInfo.Controls.Add(layout);
            tabInfo.Controls.Add(pnlSave);
        }

        #endregion

        #region 程序说明页

        private void CreateHelpTab()
        {
            tabHelp = new TabPage("程序说明");
            tabHelp.Padding = new Padding(20);
            tabHelp.BackColor = Color.Black;
            tabHelp.ForeColor = Color.White;

            txtHelp = new TextBox();
            txtHelp.Dock = DockStyle.Fill;
            txtHelp.Multiline = true;
            txtHelp.ScrollBars = ScrollBars.Vertical;
            txtHelp.ReadOnly = true;
            txtHelp.Font = new Font("微软雅黑", 10);
            txtHelp.Text = GetHelpText();
            txtHelp.BackColor = Color.FromArgb(40, 40, 40);
            txtHelp.ForeColor = Color.White;

            tabHelp.Controls.Add(txtHelp);
        }

        private string GetHelpText()
        {
            return @"影视建库管理工具 - 使用说明

数据库管理 - 创建/打开视频库，树形结构管理

储存卡扫描 - 自动检测U盘，按日期整理视频

批量操作 - 重命名、移动、删除多个文件

智能分析 - 自动获取视频分辨率、时长、编码等信息

拖拽导入 - 从储存卡拖拽文件到数据库自动整理";
        }

        #endregion

        #region UI辅助方法

        private void InitializeUI()
        {
            ApplyColorScheme();
            StyleControls();
        }

        private void ApplyColorScheme()
        {
            this.BackColor = Color.Black;
            this.ForeColor = Color.White;
        }

        private void StyleControls()
        {
            foreach (Control ctrl in GetAllControls(this))
            {
                if (ctrl is Button button)
                {
                    StyleButton(button, false);
                }
                else if (ctrl is TextBox textBox)
                {
                    textBox.BorderStyle = BorderStyle.FixedSingle;
                    textBox.BackColor = Color.FromArgb(60, 60, 60);
                    textBox.ForeColor = Color.White;
                }
                else if (ctrl is ComboBox comboBox)
                {
                    comboBox.BackColor = Color.FromArgb(60, 60, 60);
                    comboBox.ForeColor = Color.White;
                    comboBox.FlatStyle = FlatStyle.Flat;
                }
                else if (ctrl is Label label)
                {
                    label.ForeColor = Color.White;
                }
            }
        }

        private void StyleButton(Button btn, bool isPrimary = false)
        {
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 1;
            btn.FlatAppearance.BorderColor = isPrimary ? Color.White : Color.FromArgb(0, 78, 152);
            btn.BackColor = isPrimary ? Color.FromArgb(0, 78, 152) : Color.FromArgb(60, 60, 60);
            btn.ForeColor = isPrimary ? Color.White : Color.White;
            btn.Cursor = Cursors.Hand;
            btn.FlatAppearance.MouseOverBackColor = isPrimary ?
                Color.FromArgb(30, 113, 182) : Color.FromArgb(80, 80, 80);
            btn.FlatAppearance.MouseDownBackColor = isPrimary ?
                Color.FromArgb(0, 60, 120) : Color.FromArgb(100, 100, 100);
        }

        private IEnumerable<Control> GetAllControls(Control control)
        {
            var controls = control.Controls.Cast<Control>();
            return controls.SelectMany(ctrl => GetAllControls(ctrl)).Concat(controls);
        }

        #endregion

        #region FFmpeg初始化

        private void InitializeFFmpegPaths()
        {
            try
            {
                // 从%LocalAppData%\Temp\MediaCopyAssistant\ffmpeg路径中查找FFmpeg工具
                string localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                string ffmpegBasePath = Path.Combine(localAppData, "Temp", "MediaCopyAssistant", "ffmpeg");

                if (Directory.Exists(ffmpegBasePath))
                {
                    // 查找ffmpeg.exe
                    string[] ffmpegFiles = Directory.GetFiles(ffmpegBasePath, "ffmpeg.exe", SearchOption.AllDirectories);
                    if (ffmpegFiles.Length > 0)
                    {
                        ffmpegPath = ffmpegFiles[0];
                        Log($"找到FFmpeg: {ffmpegPath}");
                    }

                    // 查找ffprobe.exe
                    string[] ffprobeFiles = Directory.GetFiles(ffmpegBasePath, "ffprobe.exe", SearchOption.AllDirectories);
                    if (ffprobeFiles.Length > 0)
                    {
                        ffprobePath = ffprobeFiles[0];
                        Log($"找到FFprobe: {ffprobePath}");
                    }

                    // 如果没找到，尝试在子目录中查找
                    if (string.IsNullOrEmpty(ffprobePath))
                    {
                        ffprobeFiles = Directory.GetFiles(ffmpegBasePath, "*ffprobe*", SearchOption.AllDirectories);
                        if (ffprobeFiles.Length > 0)
                        {
                            ffprobePath = ffprobeFiles[0];
                            Log($"找到FFprobe: {ffprobePath}");
                        }
                    }
                }
                else
                {
                    Log($"FFmpeg目录不存在: {ffmpegBasePath}");
                }

                // 如果还是没找到，尝试其他常见位置
                if (string.IsNullOrEmpty(ffmpegPath))
                {
                    // 尝试在应用目录中查找
                    string appDir = Application.StartupPath;
                    string appFfmpegPath = Path.Combine(appDir, "ffmpeg.exe");
                    if (File.Exists(appFfmpegPath))
                    {
                        ffmpegPath = appFfmpegPath;
                        Log($"从应用目录找到FFmpeg: {ffmpegPath}");
                    }
                }

                if (string.IsNullOrEmpty(ffprobePath))
                {
                    string appDir = Application.StartupPath;
                    string appFfprobePath = Path.Combine(appDir, "ffprobe.exe");
                    if (File.Exists(appFfprobePath))
                    {
                        ffprobePath = appFfprobePath;
                        Log($"从应用目录找到FFprobe: {ffprobePath}");
                    }
                }

                // 验证FFmpeg工具是否可用
                if (!string.IsNullOrEmpty(ffprobePath) && File.Exists(ffprobePath))
                {
                    if (TestFFmpeg())
                    {
                        Log("FFmpeg工具初始化成功");
                    }
                    else
                    {
                        Log("FFmpeg工具测试失败");
                    }
                }
                else
                {
                    Log("警告：未找到FFprobe工具，视频信息分析功能将受限");
                }
            }
            catch (Exception ex)
            {
                Log($"初始化FFmpeg路径失败: {ex.Message}");
            }
        }

        private bool TestFFmpeg()
        {
            try
            {
                if (!File.Exists(ffprobePath))
                    return false;

                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = ffprobePath,
                    Arguments = "-version",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };

                using (Process process = new Process { StartInfo = psi })
                {
                    process.Start();
                    string output = process.StandardOutput.ReadToEnd();
                    string error = process.StandardError.ReadToEnd();
                    process.WaitForExit(3000);

                    if (!string.IsNullOrEmpty(error) && error.Contains("ffprobe version"))
                    {
                        output = error;
                    }

                    if (output.Contains("ffprobe version") || error.Contains("ffprobe version"))
                    {
                        string versionLine = output.Contains("ffprobe version") ?
                            output.Split('\n').First(l => l.Contains("ffprobe version")) :
                            error.Split('\n').First(l => l.Contains("ffprobe version"));
                        Log($"FFmpeg工具测试成功: {versionLine.Trim()}");
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Log($"FFmpeg测试失败: {ex.Message}");
            }

            return false;
        }

        #endregion

        #region 驱动器管理

        private void StartDriveMonitoring()
        {
            driveMonitor = new System.Windows.Forms.Timer();
            driveMonitor.Interval = 3000;
            driveMonitor.Tick += DriveMonitor_Tick;
            driveMonitor.Start();

            Task.Delay(1000).ContinueWith(_ =>
            {
                if (this.IsHandleCreated && !this.IsDisposed)
                {
                    this.Invoke(new Action(CheckDrives));
                }
            });
        }

        private void DriveMonitor_Tick(object sender, EventArgs e)
        {
            if (driveCheckInProgress || !this.IsHandleCreated || this.IsDisposed)
                return;

            driveCheckInProgress = true;
            try
            {
                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new Action(() =>
                    {
                        CheckDrives();
                        driveCheckInProgress = false;
                    }));
                }
                else
                {
                    CheckDrives();
                    driveCheckInProgress = false;
                }
            }
            catch
            {
                driveCheckInProgress = false;
            }
        }

        private void CheckDrives()
        {
            try
            {
                List<DriveInfo> currentDrives = DriveInfo.GetDrives()
                    .Where(d => d.DriveType == DriveType.Removable && d.IsReady)
                    .ToList();

                // 找出新增的驱动器
                var addedDrives = currentDrives.Where(d => !removableDrives.Any(rd => rd.Name == d.Name)).ToList();
                // 找出移除的驱动器
                var removedDrives = removableDrives.Where(rd => !currentDrives.Any(cd => cd.Name == rd.Name)).ToList();

                if (addedDrives.Count > 0)
                {
                    // 添加新增的驱动器卡片
                    foreach (var drive in addedDrives)
                    {
                        Panel card = CreateDriveCard(drive);
                        flpDriveCards.Controls.Add(card);
                        removableDrives.Add(drive);

                        Log($"检测到新的储存卡: {drive.Name}");
                    }
                }

                if (removedDrives.Count > 0)
                {
                    // 移除已拔出的驱动器
                    foreach (var drive in removedDrives)
                    {
                        // 从界面移除卡片
                        foreach (Control ctrl in flpDriveCards.Controls)
                        {
                            if (ctrl is Panel card && card.Tag is DriveInfo driveInfo && driveInfo.Name == drive.Name)
                            {
                                flpDriveCards.Controls.Remove(card);
                                break;
                            }
                        }

                        // 从缓存中移除
                        if (allDriveVideos.ContainsKey(drive))
                        {
                            allDriveVideos.Remove(drive);
                        }

                        removableDrives.Remove(drive);

                        Log($"储存卡已移除: {drive.Name}");
                    }
                }

                // 更新状态显示
                if (removableDrives.Count == 0)
                {
                    lblDriveStatus.Text = "未检测到储存卡";
                    currentDriveVideos.Clear();
                    ShowDateFoldersView();
                }
                else
                {
                    lblDriveStatus.Text = $"检测到 {removableDrives.Count} 个储存卡";
                }
            }
            catch (Exception ex)
            {
                Log($"检查驱动器时出错: {ex.Message}");
            }
        }

        private Panel CreateDriveCard(DriveInfo drive)
        {
            Panel card = new Panel();
            card.Size = new Size(200, 60);
            card.BorderStyle = BorderStyle.FixedSingle;
            card.Margin = new Padding(5);
            card.BackColor = Color.FromArgb(60, 60, 60);
            card.ForeColor = Color.White;
            card.Cursor = Cursors.Hand;
            card.Tag = drive;
            card.Click += DriveCard_Click;

            string label = string.IsNullOrEmpty(drive.VolumeLabel) ?
                "未命名" : drive.VolumeLabel;

            double totalGB = drive.TotalSize / 1024.0 / 1024.0 / 1024.0;
            double freeGB = drive.AvailableFreeSpace / 1024.0 / 1024.0 / 1024.0;

            Label lblName = new Label();
            lblName.Text = $"{drive.Name} ({label})";
            lblName.Font = new Font("微软雅黑", 9, FontStyle.Bold);
            lblName.Location = new Point(10, 5);
            lblName.AutoSize = true;
            lblName.ForeColor = Color.White;

            Label lblSize = new Label();
            lblSize.Text = $"{freeGB:F1}G 可用，共 {totalGB:F1}G";
            lblSize.Font = new Font("微软雅黑", 8);
            lblSize.Location = new Point(10, 25);
            lblSize.AutoSize = true;
            lblSize.ForeColor = Color.LightGray;

            card.Controls.AddRange(new Control[] { lblName, lblSize });
            return card;
        }

        private void DriveCard_Click(object sender, EventArgs e)
        {
            Panel card = sender as Panel;
            if (card != null && card.Tag is DriveInfo)
            {
                DriveInfo drive = (DriveInfo)card.Tag;

                // 更新卡片选中状态
                foreach (Control ctrl in flpDriveCards.Controls)
                {
                    if (ctrl is Panel driveCard)
                    {
                        driveCard.BackColor = driveCard == card ?
                            Color.FromArgb(80, 80, 80) : Color.FromArgb(60, 60, 60);
                    }
                }

                // 如果已经扫描过，直接显示缓存数据
                if (allDriveVideos.ContainsKey(drive))
                {
                    currentDriveVideos = allDriveVideos[drive];
                    ShowDateFoldersView();

                    // 重置导航
                    navigationStack.Clear();
                    btnBack.Enabled = false;
                    lblCurrentPath.Text = "拍摄日期文件夹";

                    Log($"已加载缓存数据: {drive.Name}");
                }
                else
                {
                    // 开始扫描
                    ScanDriveForVideos(drive);
                }
            }
        }

        #endregion

        #region 视频扫描

        private async void ScanDriveForVideos(DriveInfo drive)
        {
            // 首先检查 drive 是否为 null
            if (drive == null)
            {
                Log("错误：驱动器对象为空");
                return;
            }

            if (scanCancellation != null)
            {
                scanCancellation.Cancel();
                scanCancellation.Dispose();
            }

            scanCancellation = new CancellationTokenSource();

            // 重置导航
            ShowDateFoldersView();
            btnBack.Enabled = false;
            navigationStack.Clear();

            // 显示扫描状态
            lblCurrentPath.Text = "正在扫描...";
            lblDriveStatus.Text = $"正在扫描 {drive.VolumeLabel}...";

            string volumeLabel = "未知";
            try
            {
                // 检查驱动器是否就绪
                if (drive.IsReady)
                {
                    volumeLabel = string.IsNullOrEmpty(drive.VolumeLabel) ?
                        "未命名" : drive.VolumeLabel;
                }
            }
            catch (Exception ex)
            {
                Log($"获取驱动器标签失败: {ex.Message}");
            }

            lblDriveStatus.Text = $"正在扫描 {volumeLabel}...";

            try
            {
                string[] videoExtensions = {
            ".mp4", ".avi", ".mkv", ".mov", ".wmv",
            ".flv", ".mpeg", ".mpg", ".m4v", ".ts",
            ".m2ts", ".rmvb", ".webm", ".mts", ".3gp", ".f4v", ".mxf",
            ".mpg2", ".mpg4", ".vob", ".mod", ".tod", ".trp"
        };

                // 创建扫描进度显示
                Panel scanProgressPanel = CreateScanProgressPanel();
                this.Invoke(new Action(() =>
                {
                    pnlFileBrowser.Controls.Add(scanProgressPanel);
                    scanProgressPanel.BringToFront();
                }));

                List<string> videoPaths = new List<string>();

                // 使用异步扫描
                await Task.Run(() =>
                {
                    try
                    {
                        string rootPath = drive.RootDirectory.FullName;
                        Log($"开始扫描驱动器: {drive.Name}");

                        // 常见的视频文件夹列表
                        string[] commonVideoFolders = {
                    "DCIM", "MP_ROOT", "AVCHD", "PRIVATE", "BDMV",
                    "STREAM", "CLIP", "VIDEO", "VIDEOS", "MOVIES",
                    "CANON", "NIKON", "FUJI", "OLYMPUS", "SAMSUNG",
                    "PANASONIC", "SONY", "GoPro", "DJI", "100MEDIA",
                    "101MEDIA", "102MEDIA", "M4ROOT", "DCIM_PANA",
                    "DCIM_SONY", "DCIM_CANON", "DCIM_NIKON", "DCIM_FUJI",
                    "VIDEO_TS", "AVCHD", "MP_ROOT.INF", "AVF_INFO",
                    "XFPLAY", "CONTENTS", "MISC", "MEDIA", "CAMERA"
                };

                        // 更新扫描状态
                        this.Invoke(new Action(() =>
                        {
                            UpdateScanProgress(scanProgressPanel, "正在查找视频文件夹...", 10);
                        }));

                        // 扫描特定视频文件夹
                        ScanSpecificFolders(rootPath, commonVideoFolders, videoExtensions, videoPaths, scanProgressPanel);

                        // 如果没找到任何视频文件，扫描根目录
                        if (videoPaths.Count == 0)
                        {
                            this.Invoke(new Action(() =>
                            {
                                UpdateScanProgress(scanProgressPanel, "未找到视频文件夹，正在扫描根目录...", 80);
                            }));

                            Log("未在视频文件夹中找到视频文件，扫描根目录...");
                            foreach (string ext in videoExtensions)
                            {
                                try
                                {
                                    string[] files = Directory.GetFiles(rootPath, $"*{ext}", SearchOption.TopDirectoryOnly);
                                    videoPaths.AddRange(files);
                                }
                                catch (UnauthorizedAccessException) { }
                                catch (PathTooLongException) { }
                            }
                        }

                        Log($"扫描完成，找到 {videoPaths.Count} 个视频文件");
                    }
                    catch (Exception ex)
                    {
                        Log($"扫描文件时出错: {ex.Message}");
                    }
                });

                // 移除扫描进度面板
                this.Invoke(new Action(() =>
                {
                    pnlFileBrowser.Controls.Remove(scanProgressPanel);
                }));

                // 如果没找到视频文件
                if (videoPaths.Count == 0)
                {
                    this.Invoke(new Action(() =>
                    {
                        lblDriveStatus.Text = $"未找到视频文件";
                        lblCurrentPath.Text = "拍摄日期文件夹";
                        UpdateDateFoldersDisplay();
                    }));
                    return;
                }

                // 显示分析进度
                this.Invoke(new Action(() =>
                {
                    lblCurrentPath.Text = $"找到 {videoPaths.Count} 个视频，正在分析...";
                }));

                // 分析视频文件（只获取基本信息，不调用FFprobe）
                currentDriveVideos = await AnalyzeVideosBasic(videoPaths, scanCancellation.Token);

                // 缓存扫描结果
                allDriveVideos[drive] = currentDriveVideos;

                // 更新显示
                this.Invoke(new Action(() =>
                {
                    UpdateDateFoldersDisplay();
                    lblDriveStatus.Text = $"扫描完成，找到 {videoPaths.Count} 个视频文件";
                    lblCurrentPath.Text = "拍摄日期文件夹";
                    Log($"扫描完成，找到 {videoPaths.Count} 个视频文件");
                }));
            }
            catch (Exception ex)
            {
                Log($"扫描驱动器失败: {ex.Message}");
                this.Invoke(new Action(() =>
                {
                    lblCurrentPath.Text = "扫描失败";
                }));
            }
            finally
            {
                scanCancellation?.Dispose();
                scanCancellation = null;
            }
        }

        private Panel CreateScanProgressPanel()
        {
            Panel progressPanel = new Panel();
            progressPanel.Size = new Size(500, 120);
            progressPanel.Location = new Point(
                (pnlFileBrowser.Width - 500) / 2,
                (pnlFileBrowser.Height - 120) / 2
            );
            progressPanel.BackColor = Color.FromArgb(70, 70, 70);
            progressPanel.BorderStyle = BorderStyle.FixedSingle;
            progressPanel.ForeColor = Color.White;

            Label lblStatus = new Label();
            lblStatus.Text = "正在扫描储存卡...";
            lblStatus.Font = new Font("微软雅黑", 12, FontStyle.Bold);
            lblStatus.Location = new Point(20, 20);
            lblStatus.Size = new Size(460, 30);
            lblStatus.TextAlign = ContentAlignment.MiddleLeft;
            lblStatus.Name = "lblScanStatus";

            ProgressBar progressBar = new ProgressBar();
            progressBar.Location = new Point(20, 60);
            progressBar.Size = new Size(460, 25);
            progressBar.Style = ProgressBarStyle.Continuous;
            progressBar.Minimum = 0;
            progressBar.Maximum = 100;
            progressBar.Value = 0;
            progressBar.Name = "pbScanProgress";

            Label lblPercent = new Label();
            lblPercent.Text = "0%";
            lblPercent.Font = new Font("微软雅黑", 10);
            lblPercent.Location = new Point(20, 90);
            lblPercent.Size = new Size(460, 20);
            lblPercent.TextAlign = ContentAlignment.MiddleCenter;
            lblPercent.Name = "lblScanPercent";

            progressPanel.Controls.Add(lblStatus);
            progressPanel.Controls.Add(progressBar);
            progressPanel.Controls.Add(lblPercent);

            return progressPanel;
        }


        private async Task<Dictionary<DateTime, List<VideoFile>>> AnalyzeVideosBasic(List<string> videoPaths, CancellationToken cancellationToken)
        {
            var result = new Dictionary<DateTime, List<VideoFile>>();

            int total = videoPaths.Count;
            int processed = 0;
            int lastUpdatePercent = -1;

            // 批量处理，每批100个文件
            int batchSize = 100;
            int totalBatches = (int)Math.Ceiling((double)total / batchSize);

            for (int batch = 0; batch < totalBatches; batch++)
            {
                if (cancellationToken.IsCancellationRequested)
                    break;

                int startIndex = batch * batchSize;
                int endIndex = Math.Min(startIndex + batchSize, total);

                // 处理当前批次
                var batchTasks = new List<Task<VideoFile>>();
                for (int i = startIndex; i < endIndex; i++)
                {
                    string filePath = videoPaths[i];
                    batchTasks.Add(Task.Run(() => GetVideoInfoBasic(filePath)));
                }

                // 等待当前批次完成
                var batchResults = await Task.WhenAll(batchTasks);

                // 处理结果
                foreach (var video in batchResults)
                {
                    if (video != null)
                    {
                        DateTime date = video.CreateTime.Date;
                        if (!result.ContainsKey(date))
                        {
                            result[date] = new List<VideoFile>();
                        }
                        result[date].Add(video);
                    }

                    processed++;
                }

                // 更新进度
                int currentPercent = (int)((processed * 100.0) / total);
                if (currentPercent != lastUpdatePercent && (currentPercent % 10 == 0 || processed == total))
                {
                    lastUpdatePercent = currentPercent;
                    this.BeginInvoke(new Action(() =>
                    {
                        lblCurrentPath.Text = $"正在分析视频: {processed}/{total} ({currentPercent}%)";
                    }));
                }
            }

            return result;
        }

        private VideoFile GetVideoInfoBasic(string filePath)
        {
            try
            {
                var fileInfo = new FileInfo(filePath);
                var video = new VideoFile
                {
                    Path = filePath,
                    Name = Path.GetFileName(filePath),
                    Size = fileInfo.Length,
                    CreateTime = fileInfo.CreationTime,
                    FormattedCreateTime = fileInfo.CreationTime.ToString("yyyy-MM-dd HH:mm:ss"),
                    Duration = "未知",
                    Resolution = "未知",
                    FrameRate = "未知",
                    VideoCodec = "未知",
                    AudioCodec = "未知",
                    Bitrate = "未知"
                };

                return video;
            }
            catch
            {
                return null;
            }
        }

        private int ScanDirectoriesForTargetFolders(string currentPath, string[] targetFolders, List<string> foundFolders, int maxDepth, int currentDepth = 0)
        {
            if (currentDepth > maxDepth)
                return foundFolders.Count;

            try
            {
                // 获取当前目录下的所有文件夹
                string[] directories;
                try
                {
                    directories = Directory.GetDirectories(currentPath);
                }
                catch (UnauthorizedAccessException)
                {
                    return foundFolders.Count;
                }

                foreach (string dir in directories)
                {
                    try
                    {
                        string dirName = new DirectoryInfo(dir).Name;

                        // 跳过系统目录
                        string lowerDirName = dirName.ToLower();
                        if (lowerDirName.StartsWith(".") ||
                            lowerDirName == "system volume information" ||
                            lowerDirName == "$recycle.bin" ||
                            lowerDirName == "recycler" ||
                            lowerDirName == "found.000" ||
                            lowerDirName == "lost+found")
                        {
                            continue;
                        }

                        // 检查是否是目标文件夹
                        bool isTargetFolder = targetFolders.Any(folder =>
                            dirName.Equals(folder, StringComparison.OrdinalIgnoreCase));

                        if (isTargetFolder)
                        {
                            // 如果是DCIM，检查其子文件夹
                            if (dirName.Equals("DCIM", StringComparison.OrdinalIgnoreCase))
                            {
                                foundFolders.Add(dir);

                                // 扫描DCIM的子文件夹
                                string[] subDirs;
                                try
                                {
                                    subDirs = Directory.GetDirectories(dir);
                                    foreach (string subDir in subDirs)
                                    {
                                        string subDirName = new DirectoryInfo(subDir).Name;
                                        // 如果子文件夹是数字+MEDIA格式，也添加到扫描列表
                                        if (Regex.IsMatch(subDirName, @"^\d+MEDIA$", RegexOptions.IgnoreCase))
                                        {
                                            foundFolders.Add(subDir);
                                        }
                                    }
                                }
                                catch { }
                            }
                            else
                            {
                                foundFolders.Add(dir);
                            }
                        }
                        else if (currentDepth < maxDepth)
                        {
                            // 如果不是目标文件夹，继续递归查找
                            ScanDirectoriesForTargetFolders(dir, targetFolders, foundFolders, maxDepth, currentDepth + 1);
                        }
                    }
                    catch (UnauthorizedAccessException) { }
                    catch (PathTooLongException) { }
                }
            }
            catch (UnauthorizedAccessException) { }
            catch (PathTooLongException) { }

            return foundFolders.Count;
        }

        private void UpdateScanProgress(Panel progressPanel, string status, int progress)
        {
            if (progressPanel == null || progressPanel.IsDisposed) return;

            foreach (Control ctrl in progressPanel.Controls)
            {
                if (ctrl.Name == "lblScanStatus")
                {
                    ctrl.Text = status;
                }
                else if (ctrl.Name == "pbScanProgress")
                {
                    ((ProgressBar)ctrl).Value = progress;
                }
                else if (ctrl.Name == "lblScanPercent")
                {
                    ctrl.Text = $"{progress}%";
                }
            }
        }

        private void ScanForVideosInFolder(string folderPath, string[] extensions, List<string> results)
        {
            try
            {
                // 扫描当前文件夹
                foreach (string ext in extensions)
                {
                    try
                    {
                        string[] files = Directory.GetFiles(folderPath, $"*{ext}", SearchOption.TopDirectoryOnly);
                        results.AddRange(files);
                    }
                    catch (UnauthorizedAccessException) { }
                    catch (PathTooLongException) { }
                }

                // 递归扫描子文件夹
                ScanSubfoldersRecursive(folderPath, extensions, results, 0, 2);
            }
            catch (UnauthorizedAccessException) { }
            catch (PathTooLongException) { }
        }

        private void ScanSubfoldersRecursive(string folderPath, string[] extensions, List<string> results, int currentDepth, int maxDepth)
        {
            if (currentDepth >= maxDepth)
                return;

            try
            {
                foreach (string subDir in Directory.GetDirectories(folderPath))
                {
                    try
                    {
                        // 跳过系统目录
                        string dirName = Path.GetFileName(subDir).ToLower();
                        if (dirName.StartsWith(".") ||
                            dirName == "system volume information" ||
                            dirName == "$recycle.bin" ||
                            dirName == "recycler" ||
                            dirName == "found.000")
                            continue;

                        // 扫描当前子文件夹的视频文件
                        foreach (string ext in extensions)
                        {
                            try
                            {
                                string[] files = Directory.GetFiles(subDir, $"*{ext}", SearchOption.TopDirectoryOnly);
                                results.AddRange(files);
                            }
                            catch (UnauthorizedAccessException) { }
                            catch (PathTooLongException) { }
                        }

                        // 递归扫描
                        ScanSubfoldersRecursive(subDir, extensions, results, currentDepth + 1, maxDepth);
                    }
                    catch (UnauthorizedAccessException) { }
                    catch (PathTooLongException) { }
                }
            }
            catch (UnauthorizedAccessException) { }
            catch (PathTooLongException) { }
        }

        #endregion

        #region 数据库操作

        private void BtnNewDatabase_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog dlg = new FolderBrowserDialog())
            {
                dlg.Description = "选择数据库保存位置";

                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    string basePath = dlg.SelectedPath;

                    using (Form inputForm = new Form())
                    {
                        inputForm.Text = "新建数据库";
                        inputForm.Size = new Size(400, 200);
                        inputForm.StartPosition = FormStartPosition.CenterParent;
                        inputForm.BackColor = Color.Black;
                        inputForm.ForeColor = Color.White;

                        Label lblName = new Label
                        {
                            Text = "数据库名称:",
                            Location = new Point(20, 20),
                            Size = new Size(100, 25),
                            ForeColor = Color.White
                        };
                        TextBox txtName = new TextBox
                        {
                            Location = new Point(130, 20),
                            Size = new Size(200, 25),
                            BackColor = Color.FromArgb(60, 60, 60),
                            ForeColor = Color.White
                        };

                        Label lblTags = new Label
                        {
                            Text = "分类标签:",
                            Location = new Point(20, 60),
                            Size = new Size(100, 25),
                            ForeColor = Color.White
                        };
                        TextBox txtTags = new TextBox
                        {
                            Location = new Point(130, 60),
                            Size = new Size(200, 25),
                            Text = "默认分类",
                            BackColor = Color.FromArgb(60, 60, 60),
                            ForeColor = Color.White
                        };

                        Button btnOk = new Button
                        {
                            Text = "确定",
                            Location = new Point(150, 100),
                            Size = new Size(80, 30)
                        };
                        Button btnCancel = new Button
                        {
                            Text = "取消",
                            Location = new Point(250, 100),
                            Size = new Size(80, 30)
                        };

                        btnOk.Click += (s, ev) => inputForm.DialogResult = DialogResult.OK;
                        btnCancel.Click += (s, ev) => inputForm.DialogResult = DialogResult.Cancel;

                        StyleButton(btnOk);
                        StyleButton(btnCancel);

                        inputForm.Controls.AddRange(new Control[] { lblName, txtName, lblTags, txtTags, btnOk, btnCancel });

                        if (inputForm.ShowDialog() == DialogResult.OK)
                        {
                            string dbName = txtName.Text.Trim();
                            string tags = txtTags.Text.Trim();

                            if (string.IsNullOrWhiteSpace(dbName))
                            {
                                MessageBox.Show("数据库名称不能为空", "错误",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }

                            CreateDatabase(basePath, dbName, tags);
                        }
                    }
                }
            }
        }

        private void BtnOpenDatabase_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog dlg = new FolderBrowserDialog())
            {
                dlg.Description = "选择数据库文件夹";

                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    OpenDatabase(dlg.SelectedPath);
                }
            }
        }

        private void CreateDatabase(string basePath, string dbName, string tags)
        {
            try
            {
                string dbPath = Path.Combine(basePath, dbName);

                if (Directory.Exists(dbPath))
                {
                    if (MessageBox.Show($"数据库文件夹已存在，是否继续？", "确认",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                    {
                        return;
                    }
                }
                else
                {
                    Directory.CreateDirectory(dbPath);
                }

                // 创建数据库结构文件
                structureFilePath = Path.Combine(dbPath, $"{dbName}_structure.tree");
                string structureContent = $"数据库名称:{dbName}\n" +
                                         $"创建时间:{DateTime.Now:yyyy-MM-dd HH:mm:ss}\n" +
                                         $"修改时间:{DateTime.Now:yyyy-MM-dd HH:mm:ss}\n" +
                                         $"分类标签:{tags}\n" +
                                         "目录结构:\n";

                File.WriteAllText(structureFilePath, structureContent, Encoding.UTF8);

                // **删除创建代理媒体文件夹的代码**
                /*
                string proxyPath = Path.Combine(dbPath, "代理媒体");
                if (!Directory.Exists(proxyPath))
                {
                    Directory.CreateDirectory(proxyPath);
                }
                */

                currentDatabasePath = dbPath;
                isDatabaseOpen = true;
                LoadDatabaseStructure();

                Log($"数据库 '{dbName}' 创建成功");

                MessageBox.Show($"数据库 '{dbName}' 创建成功", "成功",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"创建数据库失败: {ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void OpenDatabase(string dbPath)
        {
            try
            {
                if (!Directory.Exists(dbPath))
                {
                    MessageBox.Show("数据库文件夹不存在", "错误",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 查找结构文件
                string[] structureFiles = Directory.GetFiles(dbPath, "*_structure.tree");

                if (structureFiles.Length == 0)
                {
                    // 兼容旧的.txt后缀
                    structureFiles = Directory.GetFiles(dbPath, "*_structure.txt");

                    if (structureFiles.Length == 0)
                    {
                        DialogResult result = MessageBox.Show("未找到数据库结构文件，是否创建？", "提示",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                        if (result == DialogResult.Yes)
                        {
                            string dbName = new DirectoryInfo(dbPath).Name;
                            structureFilePath = Path.Combine(dbPath, $"{dbName}_structure.tree");

                            string structureContent = $"数据库名称:{dbName}\n" +
                                                     $"创建时间:{DateTime.Now:yyyy-MM-dd HH:mm:ss}\n" +
                                                     $"修改时间:{DateTime.Now:yyyy-MM-dd HH:mm:ss}\n" +
                                                     $"分类标签:默认分类\n" +
                                                     "目录结构:\n";

                            File.WriteAllText(structureFilePath, structureContent, Encoding.UTF8);
                        }
                        else
                        {
                            return;
                        }
                    }
                    else
                    {
                        structureFilePath = structureFiles[0];
                        // 重命名为.tree后缀
                        string newPath = structureFilePath.Replace(".txt", ".tree");
                        if (!File.Exists(newPath))
                        {
                            File.Move(structureFilePath, newPath);
                            structureFilePath = newPath;
                        }
                    }
                }
                else
                {
                    structureFilePath = structureFiles[0];
                }

                currentDatabasePath = dbPath;
                isDatabaseOpen = true;
                LoadDatabaseStructure();

                Log($"数据库已打开: {dbPath}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"打开数据库失败: {ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MiBatchDeleteChecked_Click(object sender, EventArgs e)
        {
            // 直接调用批量删除功能
            BtnBatchDelete_Click(sender, e);
        }

        private void LoadDatabaseStructure()
        {
            try
            {
                // 保存当前展开的节点路径
                List<string> expandedPaths = new List<string>();
                SaveExpandedNodes(tvDatabase.Nodes, expandedPaths);

                // 保存当前选中的节点路径
                string selectedPath = "";
                if (tvDatabase.SelectedNode != null && tvDatabase.SelectedNode.Tag != null)
                {
                    selectedPath = GetNodePath(tvDatabase.SelectedNode);
                }

                tvDatabase.Nodes.Clear();

                if (!isDatabaseOpen || string.IsNullOrEmpty(currentDatabasePath))
                {
                    TreeNode promptNode = new TreeNode("请打开或创建数据库");
                    promptNode.Tag = "prompt";
                    promptNode.ForeColor = Color.Gray;
                    tvDatabase.Nodes.Add(promptNode);
                    return;
                }

                if (!Directory.Exists(currentDatabasePath))
                {
                    TreeNode errorNode = new TreeNode("数据库目录不存在");
                    errorNode.Tag = "error";
                    errorNode.ForeColor = Color.Red;
                    tvDatabase.Nodes.Add(errorNode);
                    return;
                }

                if (string.IsNullOrEmpty(structureFilePath) || !File.Exists(structureFilePath))
                {
                    // 查找结构文件
                    string[] structureFiles = Directory.GetFiles(currentDatabasePath, "*_structure.tree");

                    if (structureFiles.Length == 0)
                    {
                        // 兼容旧版本
                        structureFiles = Directory.GetFiles(currentDatabasePath, "*_structure.txt");
                    }

                    if (structureFiles.Length == 0)
                    {
                        string dbName = new DirectoryInfo(currentDatabasePath).Name;
                        structureFilePath = Path.Combine(currentDatabasePath, $"{dbName}_structure.tree");

                        string structureContent = $"数据库名称:{dbName}\n" +
                                                $"创建时间:{DateTime.Now:yyyy-MM-dd HH:mm:ss}\n" +
                                                $"修改时间:{DateTime.Now:yyyy-MM-dd HH:mm:ss}\n" +
                                                $"分类标签:默认分类\n" +
                                                "目录结构:\n";

                        File.WriteAllText(structureFilePath, structureContent, Encoding.UTF8);
                    }
                    else
                    {
                        structureFilePath = structureFiles[0];
                    }
                }

                if (!File.Exists(structureFilePath))
                {
                    MessageBox.Show("结构文件不存在", "错误",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string[] lines = File.ReadAllLines(structureFilePath, Encoding.UTF8);
                string dbNameFromFile = "";

                foreach (string line in lines)
                {
                    if (line.StartsWith("数据库名称:"))
                    {
                        dbNameFromFile = line.Substring(5).Trim();
                        TreeNode root = new TreeNode($"数据库: {dbNameFromFile}");
                        root.Tag = "root";
                        tvDatabase.Nodes.Add(root);
                    }
                }

                // 加载实际文件夹结构
                LoadFolderStructure(tvDatabase.Nodes[0], currentDatabasePath, 0);

                if (tvDatabase.Nodes.Count > 0)
                {
                    // 恢复展开状态
                    RestoreExpandedNodes(tvDatabase.Nodes, expandedPaths);

                    // 恢复选中状态
                    if (!string.IsNullOrEmpty(selectedPath))
                    {
                        TreeNode selectedNode = FindNodeByPath(tvDatabase.Nodes, selectedPath);
                        if (selectedNode != null)
                        {
                            tvDatabase.SelectedNode = selectedNode;
                            selectedNode.EnsureVisible();
                        }
                    }
                    else
                    {
                        tvDatabase.Nodes[0].Expand();
                    }
                }

                UpdateDatabaseUI();
                LoadDatabaseInfo();

                Log($"数据库 '{dbNameFromFile}' 加载成功");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"加载数据库结构失败: {ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // 保存展开节点的路径
        private void SaveExpandedNodes(TreeNodeCollection nodes, List<string> expandedPaths)
        {
            foreach (TreeNode node in nodes)
            {
                if (node.IsExpanded)
                {
                    string nodePath = GetNodePath(node);
                    if (!string.IsNullOrEmpty(nodePath))
                    {
                        expandedPaths.Add(nodePath);
                    }
                }

                // 递归保存子节点
                if (node.Nodes.Count > 0)
                {
                    SaveExpandedNodes(node.Nodes, expandedPaths);
                }
            }
        }

        // 恢复展开状态
        private void RestoreExpandedNodes(TreeNodeCollection nodes, List<string> expandedPaths)
        {
            foreach (TreeNode node in nodes)
            {
                string nodePath = GetNodePath(node);
                if (!string.IsNullOrEmpty(nodePath) && expandedPaths.Contains(nodePath))
                {
                    node.Expand();
                }

                // 递归恢复子节点
                if (node.Nodes.Count > 0)
                {
                    RestoreExpandedNodes(node.Nodes, expandedPaths);
                }
            }
        }

        // 获取节点路径标识
        private string GetNodePath(TreeNode node)
        {
            if (node.Tag == null) return "";

            string tag = node.Tag.ToString();
            if (tag == "root")
            {
                return "root";
            }
            else if (tag.StartsWith("folder:"))
            {
                return tag;
            }
            else if (tag.StartsWith("file:"))
            {
                return tag;
            }

            return "";
        }

        // 根据路径查找节点
        private TreeNode FindNodeByPath(TreeNodeCollection nodes, string path)
        {
            foreach (TreeNode node in nodes)
            {
                string nodePath = GetNodePath(node);
                if (nodePath == path)
                {
                    return node;
                }

                // 递归查找子节点
                if (node.Nodes.Count > 0)
                {
                    TreeNode found = FindNodeByPath(node.Nodes, path);
                    if (found != null)
                    {
                        return found;
                    }
                }
            }

            return null;
        }

        private void LoadFolderStructure(TreeNode parentNode, string folderPath, int depth)
        {
            try
            {
                // 检查嵌套深度
                if (depth >= 2)
                {
                    return;
                }

                // 加载子文件夹
                foreach (string dir in Directory.GetDirectories(folderPath))
                {
                    string dirName = new DirectoryInfo(dir).Name;

                    // 跳过系统文件夹
                    if (dirName.Equals("代理媒体", StringComparison.OrdinalIgnoreCase) ||
                        dirName.Equals("System Volume Information", StringComparison.OrdinalIgnoreCase) ||
                        dirName.Equals("$Recycle.Bin", StringComparison.OrdinalIgnoreCase))
                        continue;

                    TreeNode folderNode = new TreeNode(dirName);
                    folderNode.Tag = $"folder:{dir}";
                    folderNode.ForeColor = Color.LightSkyBlue;

                    parentNode.Nodes.Add(folderNode);

                    // 递归加载子文件夹
                    LoadFolderStructure(folderNode, dir, depth + 1);

                    // 加载文件
                    LoadFilesInFolder(folderNode, dir);
                }

                // 如果当前是根节点，加载根目录下的文件
                if (depth == 0)
                {
                    LoadFilesInFolder(parentNode, folderPath);
                }
            }
            catch (Exception ex)
            {
                Log($"加载文件夹结构失败 {folderPath}: {ex.Message}");
            }
        }

        private void LoadFilesInFolder(TreeNode folderNode, string folderPath)
        {
            try
            {
                // 加载视频文件
                string[] videoExtensions = { ".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".mpeg", ".mpg", ".m4v", ".ts", ".m2ts", ".rmvb", ".webm", ".3gp", ".mpg2", ".mpg4", ".vob", ".mts", ".f4v", ".mxf" };

                foreach (string file in Directory.GetFiles(folderPath))
                {
                    string ext = Path.GetExtension(file).ToLower();
                    if (videoExtensions.Contains(ext))
                    {
                        // 跳过数据库结构文件
                        if (file.EndsWith("_structure.tree", StringComparison.OrdinalIgnoreCase))
                            continue;

                        TreeNode fileNode = new TreeNode(Path.GetFileName(file));
                        fileNode.Tag = $"file:{file}";
                        fileNode.ForeColor = Color.LightGreen;
                        folderNode.Nodes.Add(fileNode);
                    }
                }

                // 加载说明文件，跳过数据库结构文件
                foreach (string file in Directory.GetFiles(folderPath, "*.txt"))
                {
                    // 跳过数据库结构文件
                    if (file.EndsWith("_structure.tree", StringComparison.OrdinalIgnoreCase))
                        continue;

                    TreeNode fileNode = new TreeNode(Path.GetFileName(file));
                    fileNode.Tag = $"file:{file}";
                    fileNode.ForeColor = Color.LightYellow;
                    folderNode.Nodes.Add(fileNode);
                }
            }
            catch (Exception ex)
            {
                Log($"加载文件失败 {folderPath}: {ex.Message}");
            }
        }


        private Form CreateBatchMoveDialog(List<string> files, TreeNode sourceNode)
        {
            Form dlg = new Form();
            dlg.Text = "批量移动文件";
            dlg.Size = new Size(400, 300);
            dlg.StartPosition = FormStartPosition.CenterParent;
            dlg.BackColor = Color.FromArgb(45, 45, 45);
            dlg.ForeColor = Color.White;
            dlg.Icon = MediaCopyAssistant.Properties.Resources.影视建库工具图标;

            // 目标文件夹选择
            Label lblTarget = new Label();
            lblTarget.Text = "目标文件夹:";
            lblTarget.Location = new Point(20, 20);
            lblTarget.Size = new Size(80, 25);
            lblTarget.ForeColor = Color.White;

            ComboBox cmbTargetFolders = new ComboBox();
            cmbTargetFolders.Location = new Point(110, 20);
            cmbTargetFolders.Size = new Size(250, 30);
            cmbTargetFolders.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbTargetFolders.BackColor = Color.FromArgb(60, 60, 60);
            cmbTargetFolders.ForeColor = Color.White;

            // 填充数据库内的文件夹（排除根目录和原目录）
            PopulateDatabaseFolders(cmbTargetFolders, sourceNode);

            // 移动规则说明
            Label lblRuleInfo = new Label();
            lblRuleInfo.Text = "移动规则：仅替换文件名中第一位的原文件夹名";
            lblRuleInfo.Location = new Point(20, 60);
            lblRuleInfo.Size = new Size(350, 40);
            lblRuleInfo.ForeColor = Color.LightYellow;
            lblRuleInfo.Font = new Font("微软雅黑", 9);

            // 示例
            Label lblExample = new Label();
            lblExample.Text = "示例：原文件 'A_folder_001.mp4' 移动到 'B_folder' 后，\n将变为 'B_folder_001.mp4'";
            lblExample.Location = new Point(20, 100);
            lblExample.Size = new Size(350, 50);
            lblExample.ForeColor = Color.LightGray;
            lblExample.Font = new Font("微软雅黑", 8);

            // 按钮
            Button btnMove = new Button();
            btnMove.Text = "移动";
            btnMove.Location = new Point(150, 160);
            btnMove.Size = new Size(100, 30);
            StyleButton(btnMove);

            Button btnCancel = new Button();
            btnCancel.Text = "取消";
            btnCancel.Location = new Point(260, 160);
            btnCancel.Size = new Size(100, 30);
            btnCancel.DialogResult = DialogResult.Cancel;
            StyleButton(btnCancel);

            // 移动按钮事件
            btnMove.Click += (s, e) =>
            {
                if (cmbTargetFolders.SelectedItem == null)
                {
                    MessageBox.Show("请选择目标文件夹", "提示",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string targetFolderName = cmbTargetFolders.SelectedItem.ToString();

                // 获取目标文件夹的实际路径
                string targetFolder = GetFolderPathFromDisplayName(targetFolderName);

                if (string.IsNullOrEmpty(targetFolder))
                {
                    MessageBox.Show("无法找到目标文件夹", "错误",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 检查是否选择了原目录
                if (sourceNode != null && sourceNode.Tag != null)
                {
                    string sourceTag = sourceNode.Tag.ToString();
                    if (sourceTag.StartsWith("folder:"))
                    {
                        string sourcePath = sourceTag.Substring(7);
                        if (targetFolder == sourcePath)
                        {
                            MessageBox.Show("不能选择原目录作为目标文件夹", "错误",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }
                }

                DialogResult confirm = MessageBox.Show(
                    $"确定要将 {files.Count} 个文件移动到 '{targetFolderName}' 吗？",
                    "确认移动", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (confirm == DialogResult.Yes)
                {
                    // 使用新的移动规则：仅替换第一位的原文件夹名
                    MoveFilesWithFolderNameReplacement(files, targetFolder);
                    dlg.DialogResult = DialogResult.OK;
                }
            };

            dlg.Controls.AddRange(new Control[] {
        lblTarget, cmbTargetFolders, lblRuleInfo, lblExample, btnMove, btnCancel
    });

            return dlg;
        }

        private void PopulateDatabaseFolders(ComboBox comboBox, TreeNode excludeNode = null)
        {
            comboBox.Items.Clear();

            if (!isDatabaseOpen || string.IsNullOrEmpty(currentDatabasePath))
                return;

            // 获取要排除的文件夹路径
            string excludePath = null;
            if (excludeNode != null && excludeNode.Tag != null)
            {
                string excludeTag = excludeNode.Tag.ToString();
                if (excludeTag.StartsWith("folder:"))
                {
                    excludePath = excludeTag.Substring(7);
                }
            }

            // 不添加根目录，只添加所有子文件夹
            AddDatabaseFoldersRecursive(tvDatabase.Nodes[0], comboBox, "", excludePath);
        }

        private void AddDatabaseFoldersRecursive(TreeNode node, ComboBox comboBox, string indent, string excludePath)
        {
            foreach (TreeNode child in node.Nodes)
            {
                if (child.Tag != null && child.Tag.ToString().StartsWith("folder:"))
                {
                    string folderPath = child.Tag.ToString().Substring(7);

                    // 排除指定的文件夹（原目录）
                    if (folderPath != excludePath)
                    {
                        string displayName = indent + child.Text;
                        comboBox.Items.Add(displayName);

                        // 递归添加子文件夹
                        AddDatabaseFoldersRecursive(child, comboBox, indent + "  ", excludePath);
                    }
                }
            }
        }

        private string GetFolderPathFromDisplayName(string displayName)
        {
            return FindFolderPathRecursive(tvDatabase.Nodes[0], displayName.Trim());
        }

        private string FindFolderPathRecursive(TreeNode node, string displayName)
        {
            foreach (TreeNode child in node.Nodes)
            {
                if (child.Tag != null && child.Tag.ToString().StartsWith("folder:"))
                {
                    if (child.Text == displayName.TrimStart())
                        return child.Tag.ToString().Substring(7);

                    string found = FindFolderPathRecursive(child, displayName.Substring(2));
                    if (!string.IsNullOrEmpty(found))
                        return found;
                }
            }

            return null;
        }

        private void UpdateDatabaseUI()
        {
            btnNewDatabase.Visible = !isDatabaseOpen;
            btnOpenDatabase.Visible = !isDatabaseOpen;

            if (isDatabaseOpen)
            {
                tvDatabase.Visible = true;
            }
        }

        // 验证命名规则，确保每个变量只引用一次
        private bool ValidateNamingRule(string rule, out string errorMessage)
        {
            errorMessage = "";

            // 检查规则是否为空
            if (string.IsNullOrWhiteSpace(rule))
            {
                errorMessage = "命名规则不能为空";
                return false;
            }

            // 检查第一位是否为文件夹名
            if (!rule.StartsWith("{文件夹名}"))
            {
                errorMessage = "命名规则第一位必须是 {文件夹名}";
                return false;
            }

            // 检查每个变量的引用次数
            foreach (string variable in availableVariables)
            {
                int count = CountOccurrences(rule, variable);
                if (count > 1)
                {
                    errorMessage = $"变量 {variable} 只能引用一次，当前引用了 {count} 次";
                    return false;
                }
            }

            return true;
        }

        // 统计字符串中某个子串出现的次数
        private int CountOccurrences(string source, string pattern)
        {
            if (string.IsNullOrEmpty(source) || string.IsNullOrEmpty(pattern))
                return 0;

            int count = 0;
            int index = 0;

            while ((index = source.IndexOf(pattern, index, StringComparison.Ordinal)) != -1)
            {
                count++;
                index += pattern.Length;
            }

            return count;
        }

        // 命名规则文本变化事件
        private void TxtNamingRule_TextChanged(object sender, EventArgs e)
        {
            string rule = txtNamingRule.Text;

            // 实时验证
            if (ValidateNamingRule(rule, out string errorMessage))
            {
                // 验证通过，恢复正常样式
                txtNamingRule.BackColor = Color.FromArgb(60, 60, 60);
                txtNamingRule.ForeColor = Color.White;

                // 移除提示文本
                if (lblRuleStatus != null)
                {
                    lblRuleStatus.Visible = false;
                }
            }
            else
            {
                // 验证失败，显示错误样式
                txtNamingRule.BackColor = Color.FromArgb(80, 0, 0);
                txtNamingRule.ForeColor = Color.LightPink;

                // 显示错误提示
                ShowRuleStatus(errorMessage, Color.Red);
            }
        }

        // 显示规则状态
        private void ShowRuleStatus(string message, Color color)
        {
            // 确保状态标签存在
            if (lblRuleStatus == null)
            {
                lblRuleStatus = new Label();
                lblRuleStatus.Font = new Font("微软雅黑", 8);
                lblRuleStatus.AutoSize = true;

                // 找到命名规则面板并添加标签
                foreach (Control control in pnlBottomRight.Controls)
                {
                    if (control is Panel panel && panel.Controls.Contains(txtNamingRule))
                    {
                        lblRuleStatus.Location = new Point(0, 65); // 在示例标签下方
                        panel.Controls.Add(lblRuleStatus);
                        break;
                    }
                }
            }

            lblRuleStatus.Text = message;
            lblRuleStatus.ForeColor = color;
            lblRuleStatus.Visible = true;
        }

        #endregion

        #region 树形控件事件

        private void TvDatabase_AfterSelect(object sender, TreeViewEventArgs e)
        {
            // 可以在这里显示选中节点的信息
        }

        private bool isProcessingTreeViewClick = false; // 类级别变量

        private void TvDatabase_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            // 防止重复处理
            if (isProcessingTreeViewClick) return;

            try
            {
                isProcessingTreeViewClick = true;

                if (e.Button == MouseButtons.Right)
                {
                    tvDatabase.SelectedNode = e.Node;
                    treeContextMenu.Show(tvDatabase, e.Location);
                }
                else if (e.Button == MouseButtons.Left)
                {
                    // 检查是否点击了复选框区域
                    TreeViewHitTestInfo hitTest = tvDatabase.HitTest(e.Location);

                    // 如果点击的是复选框区域，让TreeView自行处理
                    if (hitTest.Location == TreeViewHitTestLocations.StateImage)
                    {
                        // TreeView会自动处理复选框状态
                        return;
                    }

                    // 如果是文件节点，才允许切换勾选状态
                    if (e.Node.Tag != null && e.Node.Tag.ToString().StartsWith("file:"))
                    {
                        string filePath = e.Node.Tag.ToString().Substring(5);
                        string extension = Path.GetExtension(filePath).ToLower();

                        // 只允许视频文件切换勾选状态，不允许.txt说明文件切换
                        if (extension != ".txt")
                        {
                            // 这里不直接设置Checked状态，而是让TreeView的CheckBoxes属性处理
                            // 但是我们需要确保事件只触发一次
                            e.Node.Checked = !e.Node.Checked;

                            // 设置选中节点，但不触发额外事件
                            tvDatabase.SelectedNode = e.Node;
                        }
                        else
                        {
                            // 如果是.txt文件，可以选中但不勾选
                            tvDatabase.SelectedNode = e.Node;
                        }
                    }
                    else if (e.Node.Tag != null && e.Node.Tag.ToString().StartsWith("folder:"))
                    {
                        // 文件夹节点：选中节点
                        tvDatabase.SelectedNode = e.Node;
                    }
                }
            }
            finally
            {
                // 使用异步方式重置标志，确保事件处理完成后再允许下一次点击
                this.BeginInvoke(new Action(() => {
                    isProcessingTreeViewClick = false;
                }));
            }
        }
        private void TvDatabase_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                dragStartTime = DateTime.Now;
                dragStartPoint = e.Location;
                isDragging = false;

                // 检查是否点击了节点
                TreeNode node = tvDatabase.GetNodeAt(e.X, e.Y);
                if (node != null)
                {
                    dragSourceNode = node;

                    // 修复：不要在这里处理复选框点击，让NodeMouseClick处理
                    // 我们只记录拖拽起始信息
                }
            }
        }

        private void TvDatabase_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && !isDragging && dragSourceNode != null)
            {
                // 检查是否移动了足够的距离（避免轻微抖动误判为拖拽）
                int moveThreshold = 5;
                if (Math.Abs(e.X - dragStartPoint.X) > moveThreshold ||
                    Math.Abs(e.Y - dragStartPoint.Y) > moveThreshold)
                {
                    // 检查是否长按了足够时间
                    if ((DateTime.Now - dragStartTime).TotalMilliseconds >= DRAG_DELAY_MS)
                    {
                        isDragging = true;

                        // 触发拖拽
                        tvDatabase.DoDragDrop(dragSourceNode, DragDropEffects.Move | DragDropEffects.Copy);

                        // 重置状态
                        dragSourceNode = null;
                        isDragging = false;
                    }
                }
            }
        }

        private void TvDatabase_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                // 重置拖拽状态
                dragSourceNode = null;
                isDragging = false;
                dragStartPoint = Point.Empty;
            }
        }

        // 移动文件时仅替换原文件夹名（第一个下划线前的部分）
        private void MoveFilesWithFolderNameReplacement(List<string> files, string targetPath)
        {
            try
            {
                string targetFolderName = Path.GetFileName(targetPath);

                foreach (string sourcePath in files)
                {
                    if (!File.Exists(sourcePath))
                        continue;

                    string fileName = Path.GetFileName(sourcePath);
                    string extension = Path.GetExtension(fileName);
                    string fileNameWithoutExt = Path.GetFileNameWithoutExtension(fileName);

                    string newName;

                    // 检查文件名是否包含下划线
                    if (fileNameWithoutExt.Contains("_"))
                    {
                        // 找到第一个下划线的位置
                        int firstUnderscoreIndex = fileNameWithoutExt.IndexOf('_');

                        // 获取第一个下划线之前的部分（原文件夹名）
                        string firstPart = fileNameWithoutExt.Substring(0, firstUnderscoreIndex);

                        // 获取第一个下划线之后的部分（其他部分）
                        string restPart = fileNameWithoutExt.Substring(firstUnderscoreIndex + 1);

                        // 仅替换第一个部分为目标文件夹名
                        newName = targetFolderName + "_" + restPart + extension;
                    }
                    else
                    {
                        // 如果文件名中没有下划线，直接添加目标文件夹名前缀
                        newName = targetFolderName + "_" + fileNameWithoutExt + extension;
                    }

                    string destPath = Path.Combine(targetPath, newName);

                    // 处理重名
                    destPath = GetUniqueFilePath(destPath);

                    // 移动文件
                    File.Move(sourcePath, destPath);

                    Log($"移动文件（替换文件夹名）: {fileName} -> {Path.GetFileName(destPath)}");
                }

                // 刷新数据库显示
                LoadDatabaseStructure();
            }
            catch (Exception ex)
            {
                Log($"移动文件（替换文件夹名）失败: {ex.Message}");
                MessageBox.Show($"移动失败: {ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void TvDatabase_ItemDrag(object sender, ItemDragEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                TreeNode draggedNode = e.Item as TreeNode;

                // 收集所有选中的文件节点
                List<TreeNode> selectedFileNodes = new List<TreeNode>();

                // 收集当前选中的所有节点
                foreach (TreeNode node in tvDatabase.Nodes)
                {
                    CollectCheckedFileNodesRecursive(node, selectedFileNodes);
                }

                // 如果没有选中的文件，至少拖拽当前节点
                if (selectedFileNodes.Count == 0 && draggedNode != null &&
                    draggedNode.Tag != null && draggedNode.Tag.ToString().StartsWith("file:"))
                {
                    selectedFileNodes.Add(draggedNode);
                }

                if (selectedFileNodes.Count > 0)
                {
                    // 创建数据对象
                    DataObject data = new DataObject();

                    // 存储所有选中的文件路径
                    List<string> selectedFiles = new List<string>();
                    foreach (var node in selectedFileNodes)
                    {
                        if (node.Tag.ToString().StartsWith("file:"))
                        {
                            selectedFiles.Add(node.Tag.ToString().Substring(5));
                        }
                    }

                    if (selectedFiles.Count > 0)
                    {
                        // 关键修复：统一使用标准格式
                        string[] fileArray = selectedFiles.ToArray();
                        data.SetData(DataFormats.FileDrop, fileArray);

                        // 同时设置自定义格式，确保都能识别
                        data.SetData("VideoLibraryManager_SourceFiles", selectedFiles);

                        // 设置拖拽效果为移动（如果是数据库内部移动）
                        DragDropEffects effect = tvDatabase.DoDragDrop(data, DragDropEffects.Move | DragDropEffects.Copy);

                        Log($"开始拖拽 {selectedFiles.Count} 个文件，效果: {effect}");
                    }
                }
            }
        }

        // 辅助方法：递归收集所有勾选的文件节点
        private void CollectCheckedFileNodesRecursive(TreeNode node, List<TreeNode> result)
        {
            if (node.Checked && node.Tag != null && node.Tag.ToString().StartsWith("file:"))
            {
                result.Add(node);
            }

            foreach (TreeNode child in node.Nodes)
            {
                CollectCheckedFileNodesRecursive(child, result);
            }
        }

        private void TvDatabase_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;  // 设置为Copy，不是Move
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }

        private void TvDatabase_DragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }

        private void TvDatabase_DragDrop(object sender, DragEventArgs e)
        {
            try
            {
                Log("拖拽放置开始...");

                Point targetPoint = tvDatabase.PointToClient(new Point(e.X, e.Y));
                TreeNode targetNode = tvDatabase.GetNodeAt(targetPoint);

                if (targetNode == null)
                {
                    Log("拖拽放置失败：没有目标节点");
                    MessageBox.Show("请拖拽到有效的文件夹位置", "提示",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // 获取目标路径
                string targetPath = GetTargetPath(targetNode);
                if (string.IsNullOrEmpty(targetPath))
                {
                    Log("拖拽放置失败：目标路径无效");
                    MessageBox.Show("请拖拽到有效的文件夹位置", "提示",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                Log($"目标路径: {targetPath}");

                // 获取文件列表 - 修复：统一数据格式检查
                List<string> files = null;

                // 关键修复：检查所有可能的数据格式
                if (e.Data.GetDataPresent("VideoLibraryManager_SourceFiles"))
                {
                    Log("检测到自定义格式数据");
                    files = e.Data.GetData("VideoLibraryManager_SourceFiles") as List<string>;
                }
                else if (e.Data.GetDataPresent("VideoLibraryFileList")) // 检查旧格式
                {
                    Log("检测到旧格式数据");
                    files = e.Data.GetData("VideoLibraryFileList") as List<string>;
                }
                else if (e.Data.GetDataPresent(DataFormats.FileDrop)) // 检查标准格式
                {
                    Log("检测到标准文件拖拽格式");
                    string[] fileArray = (string[])e.Data.GetData(DataFormats.FileDrop);
                    files = fileArray.ToList();
                }

                if (files == null || files.Count == 0)
                {
                    Log("拖拽数据无效：没有文件");
                    MessageBox.Show("拖拽数据无效，请重新选择文件", "错误",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                Log($"获取到 {files.Count} 个文件");

                // 验证命名规则
                if (!ValidateNamingRule(txtNamingRule.Text, out string errorMessage))
                {
                    Log($"命名规则无效: {errorMessage}");
                    MessageBox.Show($"命名规则无效: {errorMessage}\n\n请修正后重试", "错误",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                Log("命名规则验证通过");

                // 判断是否是内部移动（所有文件都在当前数据库内）
                bool isInternalMove = files.All(file =>
                    !string.IsNullOrEmpty(currentDatabasePath) &&
                    file.StartsWith(currentDatabasePath));

                if (isInternalMove)
                {
                    // 内部移动：使用移动规则（仅替换文件夹名）
                    MoveFilesWithFolderNameReplacement(files, targetPath);
                }
                else
                {
                    // 外部拷贝：从储存卡到数据库
                    CopyFilesFromRightToLeft(files, targetPath, targetNode);
                }
            }
            catch (Exception ex)
            {
                Log($"拖拽放置错误: {ex.Message}");
                MessageBox.Show($"拖拽失败: {ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // 从储存卡到数据库的拖拽拷贝（右到左）
        private async void CopyFilesFromRightToLeft(List<string> sourceFiles, string targetPath, TreeNode targetNode = null)
        {
            try
            {
                Log($"开始从右往左拷贝，源文件数: {sourceFiles.Count}，目标路径: {targetPath}");

                if (sourceFiles == null || sourceFiles.Count == 0)
                {
                    MessageBox.Show("没有文件可以拷贝", "提示",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // 验证目标路径
                if (string.IsNullOrEmpty(targetPath))
                {
                    MessageBox.Show("目标路径无效", "错误",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 确保目标文件夹存在
                if (!Directory.Exists(targetPath))
                {
                    try
                    {
                        Directory.CreateDirectory(targetPath);
                        Log($"创建目标文件夹: {targetPath}");
                    }
                    catch (Exception ex)
                    {
                        Log($"创建目标文件夹失败: {ex.Message}");
                        MessageBox.Show($"无法创建目标文件夹: {ex.Message}", "错误",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                // 获取目标文件夹名称
                string folderName = Path.GetFileName(targetPath);
                if (string.IsNullOrEmpty(folderName))
                {
                    folderName = "数据库";
                }

                Log($"文件夹名: {folderName}");

                // 准备拷贝任务
                List<CopyTask> copyTasks = new List<CopyTask>();

                for (int i = 0; i < sourceFiles.Count; i++)
                {
                    string sourcePath = sourceFiles[i];

                    if (!File.Exists(sourcePath))
                    {
                        Log($"文件不存在，跳过: {sourcePath}");
                        continue;
                    }

                    try
                    {
                        // 获取视频信息
                        VideoFile videoInfo = GetVideoInfoBasic(sourcePath);

                        // 生成新文件名（使用命名规则栏的规则）
                        string newFileName = GenerateNewFileNameForDrag(videoInfo, folderName, i + 1);
                        string destPath = Path.Combine(targetPath, newFileName);

                        // 处理重名
                        destPath = GetUniqueFilePath(destPath);

                        copyTasks.Add(new CopyTask
                        {
                            Source = sourcePath,
                            Destination = destPath,
                            NewName = newFileName,
                            Size = videoInfo.Size,
                            Completed = false,
                            Verified = false,
                            IsMove = false  // 总是拷贝，不是移动
                        });

                        Log($"准备拷贝: {Path.GetFileName(sourcePath)} -> {newFileName}");
                    }
                    catch (Exception ex)
                    {
                        Log($"准备拷贝任务失败 {sourcePath}: {ex.Message}");
                    }
                }

                if (copyTasks.Count == 0)
                {
                    MessageBox.Show("没有有效的文件可以拷贝", "提示",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                Log($"准备拷贝 {copyTasks.Count} 个文件");

                // 显示进度
                this.Invoke(new Action(() =>
                {
                    pbTotalProgress.Value = 0;
                    pbCurrentProgress.Value = 0;
                    lblTotalProgress.Text = "总进度: 0%";
                    lblCurrentProgress.Text = $"正在准备拷贝 {copyTasks.Count} 个文件...";
                }));

                // 检查磁盘空间
                long totalSize = copyTasks.Sum(t => t.Size);
                try
                {
                    DriveInfo drive = new DriveInfo(Path.GetPathRoot(targetPath));
                    if (drive.AvailableFreeSpace < totalSize)
                    {
                        MessageBox.Show($"磁盘空间不足！\n需要: {FormatFileSize(totalSize)}\n可用: {FormatFileSize(drive.AvailableFreeSpace)}",
                            "空间不足", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                catch { }

                // 开始拷贝
                long totalProcessed = 0;
                int copiedCount = 0;
                int failedCount = 0;
                List<string> failedFiles = new List<string>();

                for (int i = 0; i < copyTasks.Count; i++)
                {
                    var task = copyTasks[i];

                    this.Invoke(new Action(() => {
                        lblCurrentProgress.Text = $"正在拷贝: {task.NewName}";
                        pbCurrentProgress.Value = 0;
                    }));

                    try
                    {
                        Log($"开始拷贝文件 {i + 1}/{copyTasks.Count}: {task.Source} -> {task.Destination}");

                        // 检查目标文件是否已存在且大小相同
                        if (File.Exists(task.Destination))
                        {
                            FileInfo destInfo = new FileInfo(task.Destination);
                            if (destInfo.Length == task.Size)
                            {
                                Log($"文件已存在，跳过: {task.NewName}");
                                task.Completed = true;
                                task.Verified = true;
                                totalProcessed += task.Size;
                                copiedCount++;
                                continue;
                            }
                        }

                        // 拷贝文件
                        await CopyFileWithProgressAsync(task.Source, task.Destination,
                            (progress) => {
                                this.Invoke(new Action(() => {
                                    pbCurrentProgress.Value = progress;
                                }));
                            });

                        task.Completed = true;
                        task.Verified = true;
                        copiedCount++;
                        totalProcessed += task.Size;

                        Log($"拷贝完成: {task.NewName}");
                    }
                    catch (Exception ex)
                    {
                        failedCount++;
                        failedFiles.Add($"{task.NewName} - {ex.Message}");
                        Log($"拷贝失败 {task.NewName}: {ex.Message}");
                        task.Completed = false;
                    }

                    // 更新总进度
                    int totalPercent = (int)((copiedCount * 100.0) / copyTasks.Count);
                    this.Invoke(new Action(() => {
                        pbTotalProgress.Value = totalPercent;
                        lblTotalProgress.Text = $"总进度: {totalPercent}%";
                        lblCurrentProgress.Text = $"已拷贝: {copiedCount}/{copyTasks.Count} 个文件";
                    }));
                }

                // 完成处理
                this.Invoke(new Action(() => {
                    lblCurrentProgress.Text = $"拷贝完成: {copiedCount} 成功, {failedCount} 失败";
                    pbTotalProgress.Value = 100;
                    pbCurrentProgress.Value = 100;
                }));

                // 刷新数据库显示
                LoadDatabaseStructure();

                // 展开目标节点
                if (targetNode != null)
                {
                    this.Invoke(new Action(() => {
                        targetNode.Expand();
                        tvDatabase.SelectedNode = targetNode;
                        targetNode.EnsureVisible();
                    }));
                }

                // 显示结果
                string message = $"拷贝完成！\n成功: {copiedCount} 个文件\n失败: {failedCount} 个文件";

                if (failedCount > 0)
                {
                    message += $"\n\n失败文件:\n{string.Join("\n", failedFiles.Take(3))}";
                    if (failedFiles.Count > 3)
                    {
                        message += $"\n...还有 {failedFiles.Count - 3} 个失败";
                    }

                    MessageBox.Show(message, "拷贝结果",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    MessageBox.Show(message, "完成",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                Log($"拷贝完成: {copiedCount} 成功, {failedCount} 失败");
            }
            catch (Exception ex)
            {
                Log($"从右往左拷贝失败: {ex.Message}");
                MessageBox.Show($"拷贝失败: {ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // 为拖拽拷贝生成文件名（使用命名规则栏的规则）
        private string GenerateNewFileNameForDrag(VideoFile video, string folderName, int sequence)
        {
            try
            {
                string pattern = txtNamingRule.Text;  // 使用命名规则栏的规则
                string originalName = Path.GetFileNameWithoutExtension(video.Name);
                string extension = Path.GetExtension(video.Name);

                // 验证命名规则
                if (!ValidateNamingRule(pattern, out string errorMessage))
                {
                    // 如果验证失败，使用默认规则
                    pattern = "{文件夹名}_{序号}";
                    Log($"命名规则验证失败，使用默认规则: {errorMessage}");
                }

                // 替换变量
                string result = pattern;

                // 替换变量
                result = result.Replace("{文件夹名}", folderName);
                result = result.Replace("{序号}", sequence.ToString("D3"));
                result = result.Replace("{原文件名}", originalName);

                // 如果有视频信息，替换其他变量
                if (video != null)
                {
                    result = result.Replace("{分辨率}", video.Resolution ?? "未知");
                    result = result.Replace("{帧率}", video.FrameRate ?? "未知");
                    result = result.Replace("{时长}", video.Duration ?? "未知");
                    result = result.Replace("{拍摄时间}", video.FormattedCreateTime ?? "未知");
                    result = result.Replace("{视频编码}", video.VideoCodec ?? "未知");
                    result = result.Replace("{音频编码}", video.AudioCodec ?? "未知");
                    result = result.Replace("{码率}", video.Bitrate ?? "未知");
                }

                // 清理文件名中的无效字符
                result = CleanFileName(result);

                return result + extension;
            }
            catch (Exception ex)
            {
                Log($"生成文件名失败: {ex.Message}");
                // 使用安全的后备方案
                return $"{folderName}_{sequence:D3}{Path.GetExtension(video.Name)}";
            }
        }

        // 获取目标路径
        private string GetTargetPath(TreeNode targetNode)
        {
            if (targetNode == null)
            {
                Log("GetTargetPath: 目标节点为null");
                return null;
            }

            if (targetNode.Tag == null)
            {
                Log($"GetTargetPath: 节点标签为空，文本: {targetNode.Text}");
                return null;
            }

            string targetTag = targetNode.Tag.ToString();
            Log($"GetTargetPath: 节点标签 = {targetTag}");

            if (targetTag == "root")
            {
                string path = currentDatabasePath;
                Log($"GetTargetPath: 根节点 -> {path}");
                return path;
            }
            else if (targetTag.StartsWith("folder:"))
            {
                string path = targetTag.Substring(7);
                Log($"GetTargetPath: 文件夹节点 -> {path}");
                return path;
            }
            else if (targetTag.StartsWith("file:"))
            {
                // 如果拖到文件上，使用其父文件夹
                if (targetNode.Parent != null)
                {
                    string parentTag = targetNode.Parent.Tag?.ToString() ?? "";
                    Log($"GetTargetPath: 文件节点，父节点标签 = {parentTag}");

                    if (parentTag == "root")
                    {
                        string path = currentDatabasePath;
                        Log($"GetTargetPath: 父节点为根节点 -> {path}");
                        return path;
                    }
                    else if (parentTag.StartsWith("folder:"))
                    {
                        string path = parentTag.Substring(7);
                        Log($"GetTargetPath: 父节点为文件夹 -> {path}");
                        return path;
                    }
                }
                // 如果没有父节点，返回数据库根目录
                Log($"GetTargetPath: 文件节点无父节点 -> {currentDatabasePath}");
                return currentDatabasePath;
            }
            else if (targetTag == "prompt" || targetTag == "error")
            {
                Log($"GetTargetPath: 特殊节点类型 {targetTag}，返回数据库根目录");
                return currentDatabasePath;
            }

            Log($"GetTargetPath: 未知节点类型: {targetTag}");
            return null;
        }

        private void TvDatabase_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                // 获取点击位置的节点
                TreeNode clickedNode = tvDatabase.GetNodeAt(e.X, e.Y);

                if (clickedNode?.Tag == null) return;

                string tag = clickedNode.Tag.ToString();

                // 只处理文本文件
                if (tag.StartsWith("file:"))
                {
                    string filePath = tag.Substring(5);
                    string ext = Path.GetExtension(filePath).ToLower();

                    // 只处理.txt文件
                    if (ext == ".txt")
                    {
                        try
                        {
                            if (File.Exists(filePath))
                            {
                                Process.Start("notepad.exe", filePath);
                            }
                            else
                            {
                                MessageBox.Show($"文件不存在:\n{filePath}", "错误",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"无法打开文件:\n{ex.Message}", "错误",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    // 其他文件类型：无响应
                }
                // 文件夹节点：让 TreeView 默认行为处理（自动展开/折叠）
                // 不需要调用 Toggle()
            }
        }

        private void TvDatabase_AfterLabelEdit(object sender, NodeLabelEditEventArgs e)
        {
            if (string.IsNullOrEmpty(e.Label))
            {
                e.CancelEdit = true;
                return;
            }

            TreeNode node = e.Node;
            string oldPath = "";
            string newName = e.Label;

            // 获取原路径
            if (node.Tag.ToString().StartsWith("folder:"))
            {
                oldPath = node.Tag.ToString().Substring(7);
            }
            else if (node.Tag.ToString().StartsWith("file:"))
            {
                oldPath = node.Tag.ToString().Substring(5);
            }
            else
            {
                e.CancelEdit = true;
                return;
            }

            try
            {
                string directory = Path.GetDirectoryName(oldPath);
                string newPath = Path.Combine(directory, newName);

                if (node.Tag.ToString().StartsWith("folder:"))
                {
                    if (Directory.Exists(oldPath))
                    {
                        // 重命名文件夹
                        Directory.Move(oldPath, newPath);
                        node.Tag = $"folder:{newPath}";

                        // 更新所有子节点的路径
                        UpdateChildNodePaths(node, oldPath, newPath);

                        Log($"重命名文件夹: {Path.GetFileName(oldPath)} -> {newName}");
                    }
                }
                else if (node.Tag.ToString().StartsWith("file:"))
                {
                    if (File.Exists(oldPath))
                    {
                        // 重命名文件
                        File.Move(oldPath, newPath);
                        node.Tag = $"file:{newPath}";

                        Log($"重命名文件: {Path.GetFileName(oldPath)} -> {newName}");
                    }
                }

                // 保存数据库结构
                SaveDatabaseStructure();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"重命名失败: {ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.CancelEdit = true;
            }
        }

        private void UpdateChildNodePaths(TreeNode parentNode, string oldBasePath, string newBasePath)
        {
            foreach (TreeNode childNode in parentNode.Nodes)
            {
                if (childNode.Tag != null)
                {
                    string tag = childNode.Tag.ToString();
                    if (tag.StartsWith("folder:"))
                    {
                        string oldPath = tag.Substring(7);
                        string relativePath = oldPath.Substring(oldBasePath.Length);
                        string newPath = newBasePath + relativePath;
                        childNode.Tag = $"folder:{newPath}";

                        // 递归更新子节点
                        UpdateChildNodePaths(childNode, oldPath, newPath);
                    }
                    else if (tag.StartsWith("file:"))
                    {
                        string oldPath = tag.Substring(5);
                        string relativePath = oldPath.Substring(oldBasePath.Length);
                        string newPath = newBasePath + relativePath;
                        childNode.Tag = $"file:{newPath}";
                    }
                }
            }
        }

        private int CheckNestingDepth(TreeNode node)
        {
            int depth = 0;
            TreeNode currentNode = node;

            while (currentNode != null && !currentNode.Tag.ToString().Equals("root"))
            {
                depth++;
                currentNode = currentNode.Parent;
            }

            return depth;
        }

        #endregion

        #region 拖动事件处理（储存卡文件列表）

        private void LvFileList_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                dragStartTime = DateTime.Now;
                dragStartPoint = e.Location;
                isDragging = false;

                // 记录起始位置，用于计算移动距离
                Log($"鼠标按下，位置: {e.X}, {e.Y}");
            }
        }

        private void LvFileList_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && !isDragging)
            {
                // 检查是否长按了足够时间
                if ((DateTime.Now - dragStartTime).TotalMilliseconds >= DRAG_DELAY_MS)
                {
                    isDragging = true;

                    // 获取选中的文件列表
                    List<string> selectedFiles = new List<string>();
                    foreach (ListViewItem item in lvFileList.SelectedItems)
                    {
                        if (item.Tag is VideoFile video && File.Exists(video.Path))
                        {
                            selectedFiles.Add(video.Path);
                        }
                    }

                    if (selectedFiles.Count > 0)
                    {
                        // **关键修改：只使用标准的FileDrop格式**
                        DataObject data = new DataObject(DataFormats.FileDrop, selectedFiles.ToArray());

                        // 执行拖拽操作 - 使用Copy效果
                        DragDropEffects effect = lvFileList.DoDragDrop(data, DragDropEffects.Copy);

                        Log($"拖拽完成，选中 {selectedFiles.Count} 个文件，效果: {effect}");

                        // 拖拽完成后重置状态
                        isDragging = false;
                    }
                    else
                    {
                        isDragging = false;
                    }
                }
            }
        }

        private void LvFileList_MouseUp(object sender, MouseEventArgs e)
        {
            // 重置拖拽状态
            dragStartPoint = Point.Empty;
            isDragging = false;
        }

        private void BtnInsertVariable_Click(object sender, EventArgs e)
        {
            ContextMenuStrip variableMenu = new ContextMenuStrip();
            variableMenu.BackColor = Color.FromArgb(60, 60, 60);
            variableMenu.ForeColor = Color.White;

            // 添加删除变量菜单项
            ToolStripMenuItem miDeleteVariable = new ToolStripMenuItem("删除当前变量");
            miDeleteVariable.Click += (s, e2) => DeleteCurrentVariable();
            variableMenu.Items.Add(miDeleteVariable);

            variableMenu.Items.Add(new ToolStripSeparator()); // 添加分隔线

            foreach (string variable in availableVariables)
            {
                ToolStripMenuItem item = new ToolStripMenuItem(variable);

                // 检查变量是否已经在命名规则中使用过
                if (txtNamingRule.Text.Contains(variable))
                {
                    item.Enabled = false;
                    item.Text = $"{variable} (已使用)";
                    item.ForeColor = Color.Gray;
                }

                item.Click += (s, e2) =>
                {
                    if (txtNamingRule.Text.Contains(variable))
                    {
                        MessageBox.Show($"变量 {variable} 已经使用过了，每个变量只能引用一次",
                            "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    // 插入变量并自动添加下划线分隔
                    InsertVariableWithUnderscores(variable);
                };

                variableMenu.Items.Add(item);
            }

            variableMenu.Show(btnInsertVariable, new Point(0, btnInsertVariable.Height));
        }

        // 插入变量并自动添加下划线分隔
        private void InsertVariableWithUnderscores(string variable)
        {
            try
            {
                string currentText = txtNamingRule.Text;
                int cursorPosition = txtNamingRule.SelectionStart;

                // 获取光标前后的字符
                char charBefore = cursorPosition > 0 ? currentText[cursorPosition - 1] : '\0';
                char charAfter = cursorPosition < currentText.Length ? currentText[cursorPosition] : '\0';

                string textToInsert = variable;

                // 如果光标前不是下划线且不是开头，在前面加下划线
                if (cursorPosition > 0 && charBefore != '_' && charBefore != '\0')
                {
                    textToInsert = "_" + textToInsert;
                }

                // 如果光标后不是下划线且不是结尾，在后面加下划线
                if (cursorPosition < currentText.Length && charAfter != '_' && charAfter != '\0')
                {
                    textToInsert = textToInsert + "_";
                }

                // 插入文本
                txtNamingRule.Text = currentText.Insert(cursorPosition, textToInsert);

                // 设置光标位置到变量后面
                int newCursorPosition = cursorPosition + textToInsert.Length;
                txtNamingRule.SelectionStart = newCursorPosition;
                txtNamingRule.Focus();

                // 触发验证
                TxtNamingRule_TextChanged(null, null);
            }
            catch (Exception ex)
            {
                Log($"插入变量失败: {ex.Message}");
            }
        }

        // 删除当前变量
        private void DeleteCurrentVariable()
        {
            try
            {
                string currentText = txtNamingRule.Text;
                int cursorPosition = txtNamingRule.SelectionStart;

                if (string.IsNullOrEmpty(currentText) || cursorPosition <= 0 || cursorPosition > currentText.Length)
                    return;

                // 向前查找变量开始位置
                int startPos = cursorPosition - 1;
                while (startPos >= 0 && !IsVariableBoundary(currentText, startPos))
                {
                    startPos--;
                }

                // 向后查找变量结束位置
                int endPos = cursorPosition;
                while (endPos < currentText.Length && !IsVariableBoundary(currentText, endPos))
                {
                    endPos++;
                }

                // 调整边界
                if (startPos < 0) startPos = 0;
                if (endPos > currentText.Length) endPos = currentText.Length;

                // 提取可能的变量
                string segment = currentText.Substring(startPos, endPos - startPos);

                // 检查是否包含变量
                foreach (string variable in availableVariables)
                {
                    if (segment.Contains(variable))
                    {
                        // 找到变量的具体位置
                        int varStart = currentText.IndexOf(variable, startPos);
                        if (varStart >= 0)
                        {
                            // 确定删除范围：包括变量本身及其前后的下划线
                            int deleteStart = varStart;
                            int deleteEnd = varStart + variable.Length;

                            // 检查前一个字符是否是下划线
                            if (deleteStart > 0 && currentText[deleteStart - 1] == '_')
                            {
                                deleteStart--;
                            }

                            // 检查后一个字符是否是下划线
                            if (deleteEnd < currentText.Length && currentText[deleteEnd] == '_')
                            {
                                deleteEnd++;
                            }

                            // 执行删除
                            txtNamingRule.Text = currentText.Remove(deleteStart, deleteEnd - deleteStart);
                            txtNamingRule.SelectionStart = deleteStart;
                            txtNamingRule.Focus();

                            // 触发验证
                            TxtNamingRule_TextChanged(null, null);
                            return;
                        }
                    }
                }

                // 如果没有找到变量，删除光标附近的单词
                DeleteCurrentWord();
            }
            catch (Exception ex)
            {
                Log($"删除变量失败: {ex.Message}");
            }
        }

        // 辅助方法：检查是否是变量边界（下划线或开头/结尾）
        private bool IsVariableBoundary(string text, int position)
        {
            if (position < 0 || position >= text.Length)
                return true;

            return text[position] == '_';
        }

        // 删除当前单词
        private void DeleteCurrentWord()
        {
            string currentText = txtNamingRule.Text;
            int cursorPosition = txtNamingRule.SelectionStart;

            // 找到单词的开始
            int start = cursorPosition - 1;
            while (start >= 0 && currentText[start] != '_')
            {
                start--;
            }
            if (start < 0) start = 0;
            else start++; // 跳过下划线

            // 找到单词的结束
            int end = cursorPosition;
            while (end < currentText.Length && currentText[end] != '_')
            {
                end++;
            }

            // 删除单词
            if (start < end)
            {
                txtNamingRule.Text = currentText.Remove(start, end - start);
                txtNamingRule.SelectionStart = start;
                txtNamingRule.Focus();
            }
        }

        #endregion

        #region 右键菜单事件

        private void MiNewFolder_Click(object sender, EventArgs e)
        {
            TreeNode parent = tvDatabase.SelectedNode ?? tvDatabase.Nodes[0];
            if (parent == null) return;

            // 检查嵌套深度
            if (CheckNestingDepth(parent) >= 2)
            {
                MessageBox.Show("文件夹嵌套不能超过两层", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string folderName = "新建文件夹";
            int counter = 1;

            while (parent.Nodes.Cast<TreeNode>().Any(n => n.Text == folderName))
            {
                folderName = $"新建文件夹({counter++})";
            }

            // 确定父文件夹路径
            string parentPath = "";
            if (parent.Tag.ToString().Equals("root"))
            {
                parentPath = currentDatabasePath;
            }
            else if (parent.Tag.ToString().StartsWith("folder:"))
            {
                parentPath = parent.Tag.ToString().Substring(7);
            }
            else
            {
                MessageBox.Show("无法在此位置创建文件夹", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string newFolderPath = Path.Combine(parentPath, folderName);

            try
            {
                Directory.CreateDirectory(newFolderPath);

                TreeNode newNode = new TreeNode(folderName);
                newNode.Tag = $"folder:{newFolderPath}";
                newNode.ForeColor = Color.LightSkyBlue;

                parent.Nodes.Add(newNode);
                parent.Expand();

                SaveDatabaseStructure();

                Log($"创建文件夹: {folderName}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"创建文件夹失败: {ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MiNewText_Click(object sender, EventArgs e)
        {
            TreeNode node = tvDatabase.SelectedNode ?? tvDatabase.Nodes[0];
            if (node == null) return;

            if (!isDatabaseOpen || string.IsNullOrEmpty(currentDatabasePath))
            {
                MessageBox.Show("请先打开或创建数据库", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string folderPath;

            if (node.Tag.ToString().Equals("root"))
            {
                folderPath = currentDatabasePath;
            }
            else if (node.Tag.ToString().StartsWith("folder:"))
            {
                folderPath = node.Tag.ToString().Substring(7);
            }
            else
            {
                folderPath = currentDatabasePath;
            }

            if (!Directory.Exists(folderPath))
            {
                try
                {
                    Directory.CreateDirectory(folderPath);
                    Log($"创建文件夹: {folderPath}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"创建文件夹失败: {ex.Message}", "错误",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            string fileName = "说明.txt";
            int counter = 1;

            while (File.Exists(Path.Combine(folderPath, fileName)))
            {
                fileName = $"说明({counter++}).txt";
            }

            string filePath = Path.Combine(folderPath, fileName);

            try
            {
                File.WriteAllText(filePath,
                    $"创建时间: {DateTime.Now:yyyy-MM-dd HH:mm:ss}\n" +
                    $"位置: {folderPath}\n\n" +
                    $"备注:\n" +
                    $"----------------------------\n",
                    Encoding.UTF8);

                Log($"创建说明文件: {fileName}");

                // **始终添加到树中（去掉复选框判断）**
                TreeNode fileNode = new TreeNode(fileName);
                fileNode.Tag = $"file:{filePath}";
                fileNode.ForeColor = Color.LightYellow;
                node.Nodes.Add(fileNode);
                node.Expand();

                // 自动打开文件进行编辑
                Process.Start("notepad.exe", filePath);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"创建说明文件失败: {ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MiRename_Click(object sender, EventArgs e)
        {
            if (tvDatabase.SelectedNode != null &&
                (tvDatabase.SelectedNode.Tag.ToString().StartsWith("folder:") ||
                 tvDatabase.SelectedNode.Tag.ToString().StartsWith("file:")))
            {
                tvDatabase.SelectedNode.BeginEdit();
            }
        }

        private void MiDelete_Click(object sender, EventArgs e)
        {
            TreeNode node = tvDatabase.SelectedNode;
            if (node == null || node.Tag.ToString().Equals("root")) return;

            DialogResult result = MessageBox.Show($"确定要删除 '{node.Text}' 吗？",
                "确认删除", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                string tag = node.Tag.ToString();

                if (tag.StartsWith("folder:"))
                {
                    string folderPath = tag.Substring(7);

                    DialogResult deletePhysical = MessageBox.Show("是否同时删除物理文件夹及其所有内容？",
                        "删除选项", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

                    if (deletePhysical == DialogResult.Yes)
                    {
                        try
                        {
                            if (Directory.Exists(folderPath))
                            {
                                Directory.Delete(folderPath, true);
                                Log($"删除文件夹: {node.Text}");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"删除文件夹失败: {ex.Message}", "错误",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else if (deletePhysical == DialogResult.Cancel)
                    {
                        return;
                    }
                }
                else if (tag.StartsWith("file:"))
                {
                    string filePath = tag.Substring(5);

                    DialogResult deletePhysical = MessageBox.Show("是否同时删除物理文件？",
                        "删除选项", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

                    if (deletePhysical == DialogResult.Yes)
                    {
                        try
                        {
                            if (File.Exists(filePath))
                            {
                                File.Delete(filePath);
                                Log($"删除文件: {node.Text}");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"删除文件失败: {ex.Message}", "错误",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else if (deletePhysical == DialogResult.Cancel)
                    {
                        return;
                    }
                }

                TreeNode parent = node.Parent;
                parent.Nodes.Remove(node);
                SaveDatabaseStructure();
            }
        }

        private void MiOpenFolder_Click(object sender, EventArgs e)
        {
            TreeNode node = tvDatabase.SelectedNode;
            if (node == null) return;

            string path = "";

            if (node.Tag.ToString().Equals("root"))
            {
                path = currentDatabasePath;
            }
            else if (node.Tag.ToString().StartsWith("folder:"))
            {
                path = node.Tag.ToString().Substring(7);
            }
            else if (node.Tag.ToString().StartsWith("file:"))
            {
                path = Path.GetDirectoryName(node.Tag.ToString().Substring(5));
            }

            if (Directory.Exists(path))
            {
                Process.Start("explorer.exe", path);
            }
        }

        private void MiBatchRename_Click(object sender, EventArgs e)
        {
            TreeNode node = tvDatabase.SelectedNode;
            if (node == null || !node.Tag.ToString().StartsWith("folder:")) return;

            string folderPath = node.Tag.ToString().Substring(7);

            using (Form dlg = CreateBatchRenameDialog(folderPath))
            {
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    LoadDatabaseStructure();
                }
            }
        }

        #endregion

        #region 批量管理功能

        private void BtnSelectAll_Click(object sender, EventArgs e)
        {
            if (tvDatabase.SelectedNode == null) return;

            TreeNode selectedNode = tvDatabase.SelectedNode;

            // 只选中当前选中的文件夹下的视频文件，不选中说明文件(.txt)
            foreach (TreeNode child in selectedNode.Nodes)
            {
                if (child.Tag != null && child.Tag.ToString().StartsWith("file:"))
                {
                    string filePath = child.Tag.ToString().Substring(5);
                    string extension = Path.GetExtension(filePath).ToLower();

                    // 只勾选视频文件，不勾选.txt说明文件
                    if (extension != ".txt")
                    {
                        child.Checked = true;
                    }
                }
            }
        }

        private void BtnSelectNone_Click(object sender, EventArgs e)
        {
            if (tvDatabase.SelectedNode == null) return;

            TreeNode selectedNode = tvDatabase.SelectedNode;

            // 只取消选中当前选中的文件夹下的视频文件，不取消说明文件(.txt)的勾选
            foreach (TreeNode child in selectedNode.Nodes)
            {
                if (child.Tag != null && child.Tag.ToString().StartsWith("file:"))
                {
                    string filePath = child.Tag.ToString().Substring(5);
                    string extension = Path.GetExtension(filePath).ToLower();

                    // 只取消勾选视频文件，不取消.txt说明文件的勾选
                    if (extension != ".txt")
                    {
                        child.Checked = false;
                    }
                }
            }
        }

        private void BtnBatchRename_Click(object sender, EventArgs e)
        {
            // 获取所有勾选的文件
            List<TreeNode> checkedFileNodes = GetAllCheckedFileNodes();

            if (checkedFileNodes.Count == 0)
            {
                MessageBox.Show("请先勾选要重命名的文件", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 转换为文件路径列表
            List<string> files = checkedFileNodes
                .Select(n => n.Tag.ToString().Substring(5))
                .ToList();

            // 使用新的批量重命名对话框
            using (Form dlg = CreateBatchRenameDialog(files))
            {
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    // 刷新已经在ApplyBatchRenameWithParams中执行
                }
            }
        }

        private void BtnBatchDelete_Click(object sender, EventArgs e)
        {
            // 获取整个树中所有被勾选的文件节点（不包括.txt文件）
            List<TreeNode> checkedFileNodes = GetAllCheckedFileNodes();

            if (checkedFileNodes.Count == 0)
            {
                MessageBox.Show("请先勾选要删除的文件", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 显示待删除文件列表
            string fileList = string.Join("\n", checkedFileNodes
                .Take(10)  // 最多显示10个文件
                .Select(n => Path.GetFileName(n.Tag.ToString().Substring(5))));

            if (checkedFileNodes.Count > 10)
            {
                fileList += $"\n... 还有 {checkedFileNodes.Count - 10} 个文件";
            }

            string message = $"确定要删除选中的 {checkedFileNodes.Count} 个视频文件吗？\n\n{fileList}";
            DialogResult result = MessageBox.Show(message, "确认删除",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                try
                {
                    int deletedCount = 0;
                    int failedCount = 0;
                    List<string> failedFiles = new List<string>();

                    foreach (TreeNode fileNode in checkedFileNodes)
                    {
                        string filePath = fileNode.Tag.ToString().Substring(5);

                        try
                        {
                            if (File.Exists(filePath))
                            {
                                // 删除物理文件
                                File.Delete(filePath);

                                // 从树中移除节点
                                TreeNode parent = fileNode.Parent;
                                if (parent != null)
                                {
                                    parent.Nodes.Remove(fileNode);
                                }

                                deletedCount++;
                                Log($"删除文件: {Path.GetFileName(filePath)}");
                            }
                        }
                        catch (Exception ex)
                        {
                            failedCount++;
                            failedFiles.Add(Path.GetFileName(filePath) + " - " + ex.Message);
                            Log($"删除失败: {Path.GetFileName(filePath)} - {ex.Message}");
                        }
                    }

                    // 显示结果
                    string resultMessage = $"删除完成：\n成功：{deletedCount} 个视频文件\n失败：{failedCount} 个文件";

                    if (failedCount > 0)
                    {
                        resultMessage += $"\n\n失败的文件：\n{string.Join("\n", failedFiles)}";
                        MessageBox.Show(resultMessage, "删除结果",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        MessageBox.Show(resultMessage, "完成",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    // 保存数据库结构
                    SaveDatabaseStructure();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"删除过程出错: {ex.Message}", "错误",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // 获取整个树中所有被勾选的文件节点
        private List<TreeNode> GetAllCheckedFileNodes()
        {
            List<TreeNode> checkedNodes = new List<TreeNode>();

            // 递归遍历所有节点
            CollectCheckedFileNodes(tvDatabase.Nodes, checkedNodes);

            return checkedNodes;
        }

        // 递归收集勾选的文件节点（只收集视频文件，不包含.txt文件）
        private void CollectCheckedFileNodes(TreeNodeCollection nodes, List<TreeNode> result)
        {
            foreach (TreeNode node in nodes)
            {
                // 如果节点被勾选并且是文件节点
                if (node.Checked && node.Tag != null && node.Tag.ToString().StartsWith("file:"))
                {
                    string filePath = node.Tag.ToString().Substring(5);
                    string extension = Path.GetExtension(filePath).ToLower();

                    // 只添加视频文件，不添加.txt说明文件
                    if (extension != ".txt")
                    {
                        result.Add(node);
                    }
                }

                // 递归检查子节点
                if (node.Nodes.Count > 0)
                {
                    CollectCheckedFileNodes(node.Nodes, result);
                }
            }
        }

        private void BtnBatchMove_Click(object sender, EventArgs e)
        {
            // 获取所有勾选的文件
            List<TreeNode> checkedFileNodes = GetAllCheckedFileNodes();

            if (checkedFileNodes.Count == 0)
            {
                MessageBox.Show("请先勾选要移动的文件", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 转换为文件路径列表
            List<string> files = checkedFileNodes
                .Select(n => n.Tag.ToString().Substring(5))
                .ToList();

            ShowBatchMoveDialog(files);
        }

        private void ShowBatchMoveDialog(List<string> files = null)
        {
            // 如果没有传入文件列表，获取勾选的文件
            if (files == null)
            {
                List<TreeNode> checkedFileNodes = GetAllCheckedFileNodes();
                if (checkedFileNodes.Count == 0)
                {
                    MessageBox.Show("请选择要移动的文件", "提示",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                files = checkedFileNodes
                    .Select(n => n.Tag.ToString().Substring(5))
                    .ToList();
            }

            // 获取当前选中的节点（作为源节点）
            TreeNode sourceNode = tvDatabase.SelectedNode;
            if (sourceNode == null || !sourceNode.Tag.ToString().StartsWith("folder:"))
            {
                // 如果没有选中文件夹，则使用第一个文件所在的文件夹
                if (files.Count > 0)
                {
                    string firstFile = files[0];
                    string folderPath = Path.GetDirectoryName(firstFile);

                    // 在树中查找对应的节点
                    sourceNode = FindTreeNodeByPath(folderPath);
                }
            }

            // 创建移动对话框
            using (Form moveDialog = CreateBatchMoveDialog(files, sourceNode))
            {
                if (moveDialog.ShowDialog() == DialogResult.OK)
                {
                    LoadDatabaseStructure();
                }
            }
        }

        // 辅助方法：根据路径查找树节点
        private TreeNode FindTreeNodeByPath(string folderPath)
        {
            return FindTreeNodeByPathRecursive(tvDatabase.Nodes, folderPath);
        }

        private TreeNode FindTreeNodeByPathRecursive(TreeNodeCollection nodes, string folderPath)
        {
            foreach (TreeNode node in nodes)
            {
                if (node.Tag != null && node.Tag.ToString().StartsWith("folder:"))
                {
                    string nodePath = node.Tag.ToString().Substring(7);
                    if (nodePath == folderPath)
                    {
                        return node;
                    }

                    TreeNode found = FindTreeNodeByPathRecursive(node.Nodes, folderPath);
                    if (found != null)
                    {
                        return found;
                    }
                }
            }

            return null;
        }

        private Form CreateBatchRenameDialog(string folderPath)
        {
            List<string> files = new List<string>();
            string[] videoExtensions = { ".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".mpeg", ".mpg", ".m4v", ".ts", ".m2ts", ".rmvb", ".webm" };

            foreach (string file in Directory.GetFiles(folderPath))
            {
                string ext = Path.GetExtension(file).ToLower();
                if (videoExtensions.Contains(ext))
                {
                    files.Add(file);
                }
            }

            return CreateBatchRenameDialog(files);
        }

        private Form CreateBatchRenameDialog(List<string> files)
        {
            Form dlg = new Form();
            dlg.Text = "批量重命名";
            dlg.Size = new Size(700, 520);
            dlg.StartPosition = FormStartPosition.CenterParent;
            dlg.BackColor = Color.FromArgb(45, 45, 45);
            dlg.ForeColor = Color.White;
            dlg.Icon = MediaCopyAssistant.Properties.Resources.影视建库工具图标;

            Label lblTitle = new Label();
            lblTitle.Text = $"为 {files.Count} 个视频文件批量重命名";
            lblTitle.Location = new Point(20, 20);
            lblTitle.Size = new Size(650, 30);
            lblTitle.Font = new Font("微软雅黑", 10, FontStyle.Bold);
            lblTitle.ForeColor = Color.White;

            // 命名规则说明
            Label lblRule = new Label();
            lblRule.Text = "命名规则：以文件夹名开头，可插入以下变量";
            lblRule.Location = new Point(20, 60);
            lblRule.Size = new Size(300, 20);
            lblRule.ForeColor = Color.LightGreen;

            // 命名模板输入框
            Label lblPattern = new Label();
            lblPattern.Text = "命名模板:";
            lblPattern.Location = new Point(20, 90);
            lblPattern.Size = new Size(80, 25);
            lblPattern.ForeColor = Color.White;

            TextBox txtPattern = new TextBox();
            txtPattern.Text = "{文件夹名}_{序号}_{分辨率}_{帧率}_{时长}";
            txtPattern.Location = new Point(100, 90);
            txtPattern.Size = new Size(400, 30);
            txtPattern.BackColor = Color.FromArgb(60, 60, 60);
            txtPattern.ForeColor = Color.White;

            // 变量插入按钮
            Button btnInsertVar = new Button();
            btnInsertVar.Text = "插入变量";
            btnInsertVar.Location = new Point(510, 90);
            btnInsertVar.Size = new Size(100, 30);
            btnInsertVar.Click += (s, e) => ShowVariableMenuForRename(btnInsertVar, txtPattern);
            StyleButton(btnInsertVar);

            // 可用变量说明
            Label lblVars = new Label();
            lblVars.Text = "可用变量: {文件夹名}, {序号}, {分辨率}, {帧率}, {时长}, {拍摄时间}";
            lblVars.Location = new Point(20, 130);
            lblVars.Size = new Size(600, 25);
            lblVars.ForeColor = Color.LightGray;
            lblVars.Font = new Font("微软雅黑", 9);

            // 示例说明
            Label lblExample = new Label();
            lblExample.Text = "示例: 文件夹名为'拍摄素材'，文件名为'拍摄素材_001_1920x1080_30fps_01:30:00.mp4'";
            lblExample.Location = new Point(20, 155);
            lblExample.Size = new Size(600, 20);
            lblExample.ForeColor = Color.LightGray;
            lblExample.Font = new Font("微软雅黑", 8);

            // 预览列表
            ListBox lstPreview = new ListBox();
            lstPreview.Location = new Point(20, 180);
            lstPreview.Size = new Size(650, 200);
            lstPreview.BackColor = Color.FromArgb(60, 60, 60);
            lstPreview.ForeColor = Color.White;

            // 进度条和状态标签
            ProgressBar pbAnalysis = new ProgressBar();
            pbAnalysis.Location = new Point(20, 390);
            pbAnalysis.Size = new Size(650, 20);
            pbAnalysis.Style = ProgressBarStyle.Continuous;
            pbAnalysis.Minimum = 0;
            pbAnalysis.Maximum = 100;
            pbAnalysis.Value = 0;

            Label lblStatus = new Label();
            lblStatus.Text = "等待预览...";
            lblStatus.Location = new Point(20, 415);
            lblStatus.Size = new Size(650, 20);
            lblStatus.ForeColor = Color.White;

            // 按钮
            Button btnPreview = new Button();
            btnPreview.Text = "预览";
            btnPreview.Location = new Point(20, 440);
            btnPreview.Size = new Size(100, 30);
            btnPreview.Click += async (s, e) => {
                await PreviewBatchRenameWithFolder(files, txtPattern.Text, lstPreview, pbAnalysis, lblStatus);
            };
            StyleButton(btnPreview);

            Button btnApply = new Button();
            btnApply.Text = "应用重命名";
            btnApply.Location = new Point(450, 440);
            btnApply.Size = new Size(100, 30);
            btnApply.DialogResult = DialogResult.OK;
            btnApply.Click += (s, e) => {
                ApplyBatchRenameWithFolder(files, txtPattern.Text, dlg);
            };
            StyleButton(btnApply);

            Button btnCancel = new Button();
            btnCancel.Text = "取消";
            btnCancel.Location = new Point(570, 440);
            btnCancel.Size = new Size(100, 30);
            btnCancel.DialogResult = DialogResult.Cancel;
            StyleButton(btnCancel);

            dlg.Controls.AddRange(new Control[] {
        lblTitle, lblRule, lblPattern, txtPattern, btnInsertVar,
        lblVars, lblExample, lstPreview, pbAnalysis, lblStatus,
        btnPreview, btnApply, btnCancel
    });

            return dlg;
        }

        private void ShowVariableMenuForRename(Control parent, TextBox targetTextBox)
        {
            ContextMenuStrip menu = new ContextMenuStrip();
            menu.BackColor = Color.FromArgb(60, 60, 60);
            menu.ForeColor = Color.White;

            string[] variables = { "{文件夹名}", "{序号}", "{分辨率}", "{帧率}", "{时长}", "{拍摄时间}" };

            foreach (string variable in variables)
            {
                ToolStripMenuItem item = new ToolStripMenuItem(variable);
                item.Click += (s, e) =>
                {
                    // 在光标位置插入变量
                    int cursorPosition = targetTextBox.SelectionStart;
                    targetTextBox.Text = targetTextBox.Text.Insert(cursorPosition, variable);
                    targetTextBox.SelectionStart = cursorPosition + variable.Length;
                    targetTextBox.Focus();
                };
                menu.Items.Add(item);
            }

            menu.Show(parent, new Point(0, parent.Height));
        }

        private async Task PreviewBatchRenameWithFolder(
    List<string> files, string pattern,
    ListBox listBox, ProgressBar progressBar, Label statusLabel)
        {
            try
            {
                listBox.Items.Clear();

                // 验证命名模板是否包含文件夹名
                if (!pattern.Contains("{文件夹名}"))
                {
                    MessageBox.Show("命名模板必须包含 {文件夹名} 变量", "提示",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                statusLabel.Text = "正在获取视频参数...";
                progressBar.Value = 0;

                // 取消之前的视频分析
                CancelVideoAnalysis();
                videoAnalysisCancellation = new CancellationTokenSource();
                var cancellationToken = videoAnalysisCancellation.Token;

                // 使用多线程分析视频参数
                var videoInfos = await GetVideoInfoMultiThreaded(files, progressBar, statusLabel, cancellationToken);

                // 显示预览
                for (int i = 0; i < files.Count; i++)
                {
                    if (cancellationToken.IsCancellationRequested)
                        break;

                    string oldPath = files[i];
                    string oldName = Path.GetFileName(oldPath);
                    string extension = Path.GetExtension(oldName);

                    VideoFile videoInfo = videoInfos[i];

                    // 获取文件夹名
                    string folderName = Path.GetFileName(Path.GetDirectoryName(oldPath));

                    // 生成新文件名
                    string newName = GenerateNewFileNameWithFolder(
                        folderName, i + 1, extension, videoInfo, pattern);

                    listBox.Items.Add($"{oldName}  ->  {newName}");
                }

                statusLabel.Text = $"分析完成，共 {files.Count} 个文件";
                progressBar.Value = 100;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"预览失败: {ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                statusLabel.Text = "预览失败";
            }
        }

        private async Task<List<VideoFile>> GetVideoInfoMultiThreaded(
            List<string> files, ProgressBar progressBar, Label statusLabel, CancellationToken cancellationToken)
        {
            var videoInfos = new List<VideoFile>(new VideoFile[files.Count]);

            try
            {
                Log($"开始多线程获取视频参数，共 {files.Count} 个文件");

                // 清理之前的分析状态
                analyzedFiles.Clear();
                fileAnalysisInProgress.Clear();

                int totalFiles = files.Count;
                int processedCount = 0;

                // 使用Parallel.ForEach进行并行处理
                await Task.Run(() =>
                {
                    try
                    {
                        Parallel.For(0, files.Count, new ParallelOptions
                        {
                            MaxDegreeOfParallelism = Environment.ProcessorCount,
                            CancellationToken = cancellationToken
                        }, (index, state) =>
                        {
                            try
                            {
                                if (cancellationToken.IsCancellationRequested)
                                {
                                    state.Break();
                                    return;
                                }

                                string filePath = files[index];

                                // 标记文件为分析中，防止重复分析
                                if (!fileAnalysisInProgress.TryAdd(filePath, true))
                                    return;

                                // 使用FFprobe分析视频
                                var video = GetVideoInfoWithSemaphore(filePath);
                                if (video != null)
                                {
                                    // 标记为已分析
                                    video.IsAnalyzed = true;

                                    // 添加到已分析文件缓存
                                    analyzedFiles[filePath] = video;

                                    // 添加到结果列表
                                    videoInfos[index] = video;
                                }

                                // 更新进度
                                int newProcessed = Interlocked.Increment(ref processedCount);
                                this.BeginInvoke(new Action(() =>
                                {
                                    int progress = (int)((newProcessed * 100.0) / totalFiles);
                                    progressBar.Value = progress;
                                    statusLabel.Text = $"已分析 {newProcessed}/{totalFiles} 个文件 ({progress}%)";
                                }));
                            }
                            catch (OperationCanceledException)
                            {
                                Log($"视频分析被取消: {files[index]}");
                            }
                            catch (Exception ex)
                            {
                                Log($"分析视频失败 {files[index]}: {ex.Message}");
                            }
                            finally
                            {
                                // 清理分析状态
                                string filePath = files[index];
                                fileAnalysisInProgress.TryRemove(filePath, out _);
                            }
                        });

                        if (!cancellationToken.IsCancellationRequested)
                        {
                            Log($"视频参数获取完成，共分析 {videoInfos.Count(v => v != null)}/{files.Count} 个文件");
                        }
                    }
                    catch (OperationCanceledException)
                    {
                        Log("视频参数获取任务被取消");
                    }
                    catch (Exception ex)
                    {
                        Log($"视频参数获取过程出错: {ex.Message}");
                    }
                });
            }
            catch (Exception ex)
            {
                Log($"启动多线程视频参数获取失败: {ex.Message}");
            }

            return videoInfos;
        }

        private string GenerateNewFileNameWithFolder(
    string folderName, int sequence, string extension,
    VideoFile videoInfo, string pattern)
        {
            try
            {
                // 替换变量
                string result = pattern;

                // 定义变量替换规则
                var variableReplacements = new Dictionary<string, string>
        {
            { "{文件夹名}", folderName },
            { "{序号}", sequence.ToString("D3") },
        };

                // 视频参数变量
                if (videoInfo != null)
                {
                    variableReplacements["{分辨率}"] = FormatVideoResolution(videoInfo.Resolution);
                    variableReplacements["{帧率}"] = FormatFrameRate(videoInfo.FrameRate);
                    variableReplacements["{时长}"] = FormatDurationForFilename(videoInfo.Duration);
                    variableReplacements["{拍摄时间}"] = FormatCreateTimeForFilename(videoInfo.FormattedCreateTime);
                }
                else
                {
                    variableReplacements["{分辨率}"] = "未知";
                    variableReplacements["{帧率}"] = "未知";
                    variableReplacements["{时长}"] = "未知";
                    variableReplacements["{拍摄时间}"] = "未知";
                }

                // 替换所有变量
                foreach (var kvp in variableReplacements)
                {
                    result = result.Replace(kvp.Key, kvp.Value);
                }

                // 清理文件名中的无效字符
                result = CleanFileName(result);

                return result + extension;
            }
            catch (Exception ex)
            {
                Log($"生成新文件名失败: {ex.Message}");
                // 如果出错，返回简单文件名
                return $"{folderName}_{sequence:D3}{extension}";
            }
        }

        private string FormatVideoResolution(string resolution)
        {
            if (string.IsNullOrEmpty(resolution) ||
                resolution == "未知" || resolution == "NULL")
                return "未知";

            // 移除可能的空格和特殊字符
            return resolution.Replace(" ", "").Replace("×", "x").Replace("X", "x");
        }

        private string FormatFrameRate(string frameRate)
        {
            if (string.IsNullOrEmpty(frameRate) ||
                frameRate == "未知" || frameRate == "NULL")
                return "未知";

            // 提取数字部分，如 "30.00 fps" -> "30fps"
            var match = Regex.Match(frameRate, @"(\d+\.?\d*)");
            if (match.Success)
            {
                return $"{match.Value}fps";
            }

            return frameRate.Replace(" ", "").Replace("fps", "fps").Replace("FPS", "fps");
        }

        private string FormatDurationForFilename(string duration)
        {
            if (string.IsNullOrEmpty(duration) ||
                duration == "未知" || duration == "NULL")
                return "未知";

            // 清理格式，如 "00:01:30" -> "01m30s"
            if (duration.Contains(":"))
            {
                try
                {
                    var parts = duration.Split(':');
                    if (parts.Length == 3) // HH:MM:SS
                    {
                        int hours = int.Parse(parts[0]);
                        int minutes = int.Parse(parts[1]);
                        int seconds = int.Parse(parts[2]);

                        if (hours > 0)
                            return $"{hours}h{minutes:D2}m{seconds:D2}s";
                        else if (minutes > 0)
                            return $"{minutes}m{seconds:D2}s";
                        else
                            return $"{seconds}s";
                    }
                }
                catch { }
            }

            return duration;
        }

        private string FormatCreateTimeForFilename(string createTime)
        {
            if (string.IsNullOrEmpty(createTime) || createTime == "未知")
                return "未知";

            // 提取日期部分，如 "2023-01-15 14:30:00" -> "20230115"
            try
            {
                var dateMatch = Regex.Match(createTime, @"(\d{4})-(\d{2})-(\d{2})");
                if (dateMatch.Success)
                {
                    return $"{dateMatch.Groups[1].Value}{dateMatch.Groups[2].Value}{dateMatch.Groups[3].Value}";
                }
            }
            catch { }

            return createTime;
        }

        private void ApplyBatchRenameWithFolder(List<string> files, string pattern, Form dialog)
        {
            try
            {
                // 验证命名模板是否包含文件夹名
                if (!pattern.Contains("{文件夹名}"))
                {
                    MessageBox.Show("命名模板必须包含 {文件夹名} 变量", "错误",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    dialog.DialogResult = DialogResult.None;
                    return;
                }

                int renamedCount = 0;
                int failedCount = 0;
                List<string> failedFiles = new List<string>();

                for (int i = 0; i < files.Count; i++)
                {
                    try
                    {
                        string oldPath = files[i];
                        string oldName = Path.GetFileName(oldPath);
                        string directory = Path.GetDirectoryName(oldPath);
                        string extension = Path.GetExtension(oldPath);

                        // 获取文件夹名
                        string folderName = Path.GetFileName(directory);

                        // 从缓存获取视频信息
                        VideoFile videoInfo = null;
                        if (analyzedFiles.TryGetValue(oldPath, out VideoFile cachedVideo))
                        {
                            videoInfo = cachedVideo;
                        }
                        else
                        {
                            // 如果缓存中没有，尝试快速获取基础信息
                            videoInfo = GetVideoInfoBasic(oldPath);
                        }

                        // 生成新文件名
                        string newName = GenerateNewFileNameWithFolder(
                            folderName, i + 1, extension, videoInfo, pattern);

                        string newPath = Path.Combine(directory, newName);

                        // 处理重名
                        newPath = GetUniqueFilePath(newPath);

                        // 重命名文件
                        File.Move(oldPath, newPath);
                        renamedCount++;

                        Log($"批量重命名: {oldName} -> {Path.GetFileName(newPath)}");
                    }
                    catch (Exception ex)
                    {
                        failedCount++;
                        failedFiles.Add($"{Path.GetFileName(files[i])} - {ex.Message}");
                        Log($"重命名失败 {files[i]}: {ex.Message}");
                    }
                }

                // 显示结果
                string message = $"重命名完成！\n成功: {renamedCount} 个文件\n失败: {failedCount} 个文件";

                if (failedCount > 0)
                {
                    message += $"\n\n失败文件:\n{string.Join("\n", failedFiles.Take(3))}";
                    if (failedFiles.Count > 3)
                    {
                        message += $"\n...还有 {failedFiles.Count - 3} 个失败";
                    }

                    MessageBox.Show(message, "重命名结果",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    MessageBox.Show(message, "完成",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                // 刷新数据库显示
                LoadDatabaseStructure();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"重命名失败: {ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                dialog.DialogResult = DialogResult.None;
            }
        }


        #endregion

        #region 文件拷贝操作

        private void BtnCopySelected_Click(object sender, EventArgs e)
        {
            if (tvDatabase.SelectedNode == null)
            {
                MessageBox.Show("请先选择目标文件夹", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string targetPath = "";
            if (tvDatabase.SelectedNode.Tag.ToString().Equals("root"))
            {
                targetPath = currentDatabasePath;
            }
            else if (tvDatabase.SelectedNode.Tag.ToString().StartsWith("folder:"))
            {
                targetPath = tvDatabase.SelectedNode.Tag.ToString().Substring(7);
            }
            else
            {
                MessageBox.Show("请选择文件夹", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 验证命名规则
            if (!ValidateNamingRule(txtNamingRule.Text, out string errorMessage))
            {
                MessageBox.Show($"命名规则无效: {errorMessage}\n\n请修正后重试", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // 获取当前选中的视频文件
            List<VideoFile> selectedVideos = new List<VideoFile>();
            if (tabMain.SelectedTab == tabStorage && lvFileList.SelectedItems.Count > 0)
            {
                foreach (ListViewItem item in lvFileList.SelectedItems)
                {
                    if (item.Tag is VideoFile video && File.Exists(video.Path))
                    {
                        selectedVideos.Add(video);
                    }
                }

                if (selectedVideos.Count == 0)
                {
                    MessageBox.Show("请先选择要拷贝的视频文件", "提示",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                CopyFilesToDatabase(selectedVideos.Select(v => v.Path).ToList(), targetPath, false);
            }
        }

        private async void CopyFilesToDatabase(List<string> sourceFiles, string targetPath, bool isMove, string namingRule = null)
        {
            if (sourceFiles == null || sourceFiles.Count == 0)
                return;

            // 如果未指定命名规则，使用主界面的规则
            if (string.IsNullOrEmpty(namingRule))
            {
                namingRule = txtNamingRule.Text;
            }

            // 确保目标文件夹存在
            if (!Directory.Exists(targetPath))
            {
                try
                {
                    Directory.CreateDirectory(targetPath);
                    Log($"创建目标文件夹: {targetPath}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"无法创建目标文件夹: {ex.Message}", "错误",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            // 获取目标文件夹名称
            string folderName = new DirectoryInfo(targetPath).Name;

            copyTasks.Clear();

            for (int i = 0; i < sourceFiles.Count; i++)
            {
                string sourcePath = sourceFiles[i];

                // 检查源文件是否存在
                if (!File.Exists(sourcePath))
                {
                    Log($"源文件不存在，跳过: {sourcePath}");
                    continue;
                }

                // 获取视频信息
                VideoFile videoInfo = null;

                // 尝试从当前日期视频列表中获取信息
                if (currentDateVideos != null)
                {
                    videoInfo = currentDateVideos.FirstOrDefault(v => v.Path == sourcePath);
                }

                // 如果没找到，创建基础信息
                if (videoInfo == null)
                {
                    try
                    {
                        var fileInfo = new FileInfo(sourcePath);
                        videoInfo = new VideoFile
                        {
                            Path = sourcePath,
                            Name = Path.GetFileName(sourcePath),
                            CreateTime = fileInfo.CreationTime,
                            FormattedCreateTime = fileInfo.CreationTime.ToString("yyyy-MM-dd HH:mm:ss"),
                            Size = fileInfo.Length
                        };
                    }
                    catch
                    {
                        videoInfo = new VideoFile
                        {
                            Path = sourcePath,
                            Name = Path.GetFileName(sourcePath),
                            CreateTime = DateTime.Now,
                            FormattedCreateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                            Size = 0
                        };
                    }
                }

                // 生成文件名
                string newFileName = GenerateNewFileName(videoInfo, folderName, i + 1);
                string destPath = Path.Combine(targetPath, newFileName);

                // 处理重名
                destPath = GetUniqueFilePath(destPath);

                copyTasks.Add(new CopyTask
                {
                    Source = sourcePath,
                    Destination = destPath,
                    NewName = newFileName,
                    Size = videoInfo.Size,
                    Completed = false,
                    Verified = false,
                    IsMove = isMove
                });
            }

            if (copyTasks.Count == 0)
            {
                MessageBox.Show("没有找到有效的文件", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 开始拷贝
            await StartCopyProcess();
        }

        private string GenerateNewFileName(VideoFile video, string folderName, int sequence, bool includeExtension = true)
        {
            try
            {
                string pattern = txtNamingRule.Text;
                string originalName = Path.GetFileNameWithoutExtension(video.Name);
                string extension = Path.GetExtension(video.Name);

                // 验证命名规则
                if (!ValidateNamingRule(pattern, out string errorMessage))
                {
                    // 如果验证失败，使用默认规则
                    pattern = "{文件夹名}_{序号}_{原文件名}";
                    Log($"命名规则验证失败，使用默认规则: {errorMessage}");
                }

                // 替换变量，确保每个变量只替换一次
                string result = pattern;

                // 按照特定的顺序替换变量
                var variableReplacements = new Dictionary<string, string>
        {
            { "{文件夹名}", folderName },
            { "{序号}", sequence.ToString("D3") },
            { "{原文件名}", originalName },
            { "{分辨率}", video.Resolution ?? "未知" },
            { "{帧率}", video.FrameRate ?? "未知" },
            { "{时长}", video.Duration ?? "未知" },
            { "{拍摄时间}", video.FormattedCreateTime ?? "未知" },
            { "{视频编码}", video.VideoCodec ?? "未知" },
            { "{音频编码}", video.AudioCodec ?? "未知" },
            { "{码率}", video.Bitrate ?? "未知" }
        };

                foreach (var kvp in variableReplacements)
                {
                    // 只替换第一个出现的变量
                    int index = result.IndexOf(kvp.Key);
                    if (index >= 0)
                    {
                        result = result.Remove(index, kvp.Key.Length).Insert(index, kvp.Value);
                    }
                }

                // 清理无效字符
                result = CleanFileName(result);

                return includeExtension ? result + extension : result;
            }
            catch (Exception ex)
            {
                Log($"生成文件名失败: {ex.Message}");
                // 使用安全的后备方案
                return $"{folderName}_{sequence:D3}_{Path.GetFileNameWithoutExtension(video.Name)}{Path.GetExtension(video.Name)}";
            }
        }

        private string CleanFileName(string fileName)
        {
            // 移除Windows文件名中不允许的字符
            string invalidChars = new string(Path.GetInvalidFileNameChars()) + new string(Path.GetInvalidPathChars());
            foreach (char c in invalidChars)
            {
                fileName = fileName.Replace(c.ToString(), "");
            }
            return fileName.Trim();
        }

        private static string GetUniqueFilePath(string filePath)
        {
            if (!File.Exists(filePath))
                return filePath;

            string directory = Path.GetDirectoryName(filePath);
            string fileName = Path.GetFileNameWithoutExtension(filePath);
            string extension = Path.GetExtension(filePath);

            int counter = 1;
            string newFileName;

            do
            {
                newFileName = $"{fileName}_{counter}{extension}";
                counter++;
            } while (File.Exists(Path.Combine(directory, newFileName)));

            return Path.Combine(directory, newFileName);
        }

        private async Task StartCopyProcess()
        {
            if (copyCancellation != null)
            {
                copyCancellation.Cancel();
                copyCancellation.Dispose();
            }

            copyCancellation = new CancellationTokenSource();

            try
            {
                UpdateUI(() =>
                {
                    pbTotalProgress.Value = 0;
                    pbCurrentProgress.Value = 0;
                    lblTotalProgress.Text = "总进度: 0%";
                    lblCurrentProgress.Text = "准备中...";

                    btnCopySelected.Enabled = false;
                    btnBatchRename.Enabled = false;
                    btnBatchDelete.Enabled = false;
                    btnBatchMove.Enabled = false;
                });

                // 检查目标目录是否存在
                string targetDir = Path.GetDirectoryName(copyTasks[0].Destination);
                if (!Directory.Exists(targetDir))
                {
                    Directory.CreateDirectory(targetDir);
                    Log($"创建目标目录: {targetDir}");
                }

                // 检查磁盘空间
                long totalSize = copyTasks.Sum(t => t.Size);
                DriveInfo drive = new DriveInfo(targetDir);
                if (drive.AvailableFreeSpace < totalSize)
                {
                    MessageBox.Show($"磁盘空间不足！\n需要: {FormatFileSize(totalSize)}\n可用: {FormatFileSize(drive.AvailableFreeSpace)}",
                        "空间不足", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // 开始操作
                long totalProcessed = 0;
                int completedCount = 0;

                for (int i = 0; i < copyTasks.Count; i++)
                {
                    var task = copyTasks[i];

                    UpdateUI(() => {
                        lblCurrentProgress.Text = $"正在{(task.IsMove ? "移动" : "拷贝")}: {task.NewName}";
                        pbCurrentProgress.Value = 0;
                    });

                    try
                    {
                        if (!File.Exists(task.Source))
                        {
                            Log($"源文件不存在: {task.Source}");
                            continue;
                        }

                        if (File.Exists(task.Destination))
                        {
                            FileInfo destInfo = new FileInfo(task.Destination);
                            if (destInfo.Length == task.Size)
                            {
                                Log($"文件已存在，跳过: {task.NewName}");
                                task.Completed = true;
                                task.Verified = true;
                                totalProcessed += task.Size;
                                completedCount++;
                                continue;
                            }
                        }

                        // 使用异步拷贝方法，实时更新进度
                        await CopyFileWithProgressAsync(task.Source, task.Destination,
                            (progress) => {
                                UpdateUI(() => {
                                    pbCurrentProgress.Value = progress;
                                });
                            });

                        if (task.IsMove)
                        {
                            // 移动操作：删除源文件
                            File.Delete(task.Source);
                        }

                        task.Completed = true;
                        task.Verified = true;
                        completedCount++;
                        totalProcessed += task.Size;

                        Log($"{(task.IsMove ? "移动" : "拷贝")}完成: {task.NewName}");
                    }
                    catch (Exception ex)
                    {
                        Log($"操作失败 {task.NewName}: {ex.Message}");
                        task.Completed = false;
                    }

                    // 更新总进度
                    int totalPercent = (int)((totalProcessed * 100) / totalSize);
                    UpdateUI(() => {
                        pbTotalProgress.Value = totalPercent;
                        lblTotalProgress.Text = $"总进度: {totalPercent}%";
                        lblCurrentProgress.Text = $"已处理: {completedCount}/{copyTasks.Count} 个文件";
                    });
                }

                // 完成
                UpdateUI(() => {
                    btnCopySelected.Enabled = true;
                    btnBatchRename.Enabled = true;
                    btnBatchDelete.Enabled = true;
                    btnBatchMove.Enabled = true;

                    string operation = copyTasks.Any(t => t.IsMove) ? "移动" : "拷贝";
                    MessageBox.Show($"{operation}完成！{completedCount}/{copyTasks.Count} 个文件已成功{operation}。",
                        "完成", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // 刷新数据库显示
                    LoadDatabaseStructure();
                });

            }
            catch (Exception ex)
            {
                Log($"操作过程出错: {ex.Message}");
                MessageBox.Show($"操作失败: {ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                copyCancellation?.Dispose();
                copyCancellation = null;

                UpdateUI(() => {
                    btnCopySelected.Enabled = true;
                    btnBatchRename.Enabled = true;
                    btnBatchDelete.Enabled = true;
                    btnBatchMove.Enabled = true;
                });
            }
        }

        private async Task CopyFileWithProgressAsync(string sourcePath, string destPath, Action<int> progressCallback)
        {
            const int bufferSize = 81920;
            byte[] buffer = new byte[bufferSize];

            using (FileStream sourceStream = new FileStream(sourcePath, FileMode.Open, FileAccess.Read))
            using (FileStream destStream = new FileStream(destPath, FileMode.Create, FileAccess.Write))
            {
                long fileSize = sourceStream.Length;
                long totalBytesRead = 0;
                int bytesRead;

                while ((bytesRead = await sourceStream.ReadAsync(buffer, 0, buffer.Length)) > 0)
                {
                    await destStream.WriteAsync(buffer, 0, bytesRead);
                    totalBytesRead += bytesRead;

                    // 计算进度百分比
                    int progress = (int)((totalBytesRead * 100) / fileSize);
                    progressCallback?.Invoke(progress);
                }
            }
        }

        private void UpdateUI(Action action)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(action);
            }
            else
            {
                action();
            }
        }

        #endregion

        #region 日志操作

        private void Log(string message)
        {
            string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string logLine = $"[{timestamp}] {message}";

            lock (logLock)
            {
                logContent.AppendLine(logLine);
            }

            if (this.IsHandleCreated && !this.IsDisposed)
            {
                this.BeginInvoke(new Action(() =>
                {
                    if (!txtLog.IsDisposed)
                    {
                        txtLog.AppendText(logLine + Environment.NewLine);
                        txtLog.ScrollToCaret();
                    }
                }));
            }
            else
            {
                CacheLog(message);
            }
        }

        private void CacheLog(string message)
        {
            string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string logLine = $"[{timestamp}] {message}";
            cachedLogs.Add(logLine);
        }

        private void FlushCachedLogs()
        {
            if (cachedLogs.Count > 0 && txtLog != null && !txtLog.IsDisposed)
            {
                foreach (string logLine in cachedLogs)
                {
                    txtLog.AppendText(logLine + Environment.NewLine);
                    logContent.AppendLine(logLine);
                }
                cachedLogs.Clear();
                txtLog.ScrollToCaret();
            }
        }

        private void BtnClearLog_Click(object sender, EventArgs e)
        {
            txtLog.Clear();
            logContent.Clear();
        }

        private void BtnSaveLog_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog dlg = new SaveFileDialog())
            {
                dlg.Filter = "日志文件|*.log|文本文件|*.txt|所有文件|*.*";
                dlg.FileName = $"操作日志_{DateTime.Now:yyyyMMdd_HHmmss}.log";

                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    File.WriteAllText(dlg.FileName, txtLog.Text, Encoding.UTF8);
                    MessageBox.Show("日志保存成功", "成功",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private string FormatFileSize(long bytes)
        {
            string[] sizes = { "B", "KB", "MB", "GB", "TB" };
            double len = bytes;
            int order = 0;

            while (len >= 1024 && order < sizes.Length - 1)
            {
                order++;
                len /= 1024;
            }

            return $"{len:0.##} {sizes[order]}";
        }

        #endregion

        #region 库信息操作

        private void LoadDatabaseInfo()
        {
            try
            {
                if (!File.Exists(structureFilePath))
                    return;

                string[] lines = File.ReadAllLines(structureFilePath, Encoding.UTF8);

                foreach (string line in lines)
                {
                    if (line.StartsWith("数据库名称:"))
                        txtDbName.Text = line.Substring(5);
                    else if (line.StartsWith("创建时间:"))
                        txtCreateTime.Text = line.Substring(5);
                    else if (line.StartsWith("修改时间:"))
                        txtModifyTime.Text = line.Substring(5);
                    else if (line.StartsWith("分类标签:"))
                        txtTags.Text = line.Substring(5);
                }

                txtDbPath.Text = currentDatabasePath;
                btnSaveInfo.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"加载库信息失败: {ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void TxtTags_TextChanged(object sender, EventArgs e)
        {
            btnSaveInfo.Enabled = true;
        }

        private void BtnSaveInfo_Click(object sender, EventArgs e)
        {
            try
            {
                if (!File.Exists(structureFilePath))
                    return;

                string[] lines = File.ReadAllLines(structureFilePath, Encoding.UTF8);

                for (int i = 0; i < lines.Length; i++)
                {
                    if (lines[i].StartsWith("分类标签:"))
                    {
                        lines[i] = $"分类标签:{txtTags.Text}";
                    }
                    else if (lines[i].StartsWith("修改时间:"))
                    {
                        lines[i] = $"修改时间:{DateTime.Now:yyyy-MM-dd HH:mm:ss}";
                    }
                }

                File.WriteAllLines(structureFilePath, lines, Encoding.UTF8);
                LoadDatabaseInfo();

                MessageBox.Show("库信息保存成功", "成功",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"保存库信息失败: {ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnOpenFolder_Click(object sender, EventArgs e)
        {
            if (Directory.Exists(currentDatabasePath))
            {
                Process.Start("explorer.exe", currentDatabasePath);
            }
        }

        private void SaveDatabaseStructure()
        {
            try
            {
                if (string.IsNullOrEmpty(structureFilePath) || !File.Exists(structureFilePath))
                    return;

                string[] lines = File.ReadAllLines(structureFilePath, Encoding.UTF8);
                List<string> newLines = new List<string>();

                bool inStructure = false;
                foreach (string line in lines)
                {
                    if (line.StartsWith("目录结构:"))
                    {
                        newLines.Add(line);
                        inStructure = true;

                        // 扫描实际文件夹结构
                        if (Directory.Exists(currentDatabasePath))
                        {
                            SaveFolderStructure(newLines, currentDatabasePath, "", 0);
                        }
                    }
                    else if (inStructure && (line.Contains("├──") || line.Contains("└──")))
                    {
                        continue;
                    }
                    else
                    {
                        newLines.Add(line);

                        if (line.StartsWith("修改时间:"))
                        {
                            newLines[newLines.Count - 1] = $"修改时间:{DateTime.Now:yyyy-MM-dd HH:mm:ss}";
                        }
                    }
                }

                File.WriteAllLines(structureFilePath, newLines, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"保存数据库结构失败: {ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SaveFolderStructure(List<string> lines, string basePath, string indent, int depth)
        {
            if (depth >= 2)
                return;

            try
            {
                var directories = Directory.GetDirectories(basePath)
                    .Select(d => new DirectoryInfo(d).Name)
                    // **删除代理媒体过滤，因为文件夹已经不存在了**
                    .ToList();

                for (int i = 0; i < directories.Count; i++)
                {
                    string dirName = directories[i];
                    string prefix = (i == directories.Count - 1) ? "└──" : "├──";

                    lines.Add($"{indent}{prefix} {dirName}");

                    // 递归保存子文件夹
                    string childIndent = indent + (i == directories.Count - 1 ? "    " : "│   ");
                    SaveFolderStructure(lines, Path.Combine(basePath, dirName), childIndent, depth + 1);
                }
            }
            catch (Exception ex)
            {
                Log($"保存文件夹结构失败 {basePath}: {ex.Message}");
            }
        }

        private void SaveApplicationState()
        {
            try
            {
                Log("应用关闭");
            }
            catch { }
        }

        #endregion

        #region 辅助方法

        private void OpenVideoWithDefaultPlayer(string videoPath)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = videoPath,
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"无法打开视频: {ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion
    }

    #region 辅助枚举和类

    public enum LogLevel
    {
        Info,
        Warning,
        Error,
        Debug
    }

    public class AppConfig
    {
        public string LastDatabasePath { get; set; }
        public bool ShowFilesInTree { get; set; } = true;
        public bool EnableMD5Check { get; set; } = false;
        public string FfmpegPath { get; set; }
        public string FfprobePath { get; set; }
        public int MaxLogSize { get; set; } = 1000000;
    }

    #endregion
}