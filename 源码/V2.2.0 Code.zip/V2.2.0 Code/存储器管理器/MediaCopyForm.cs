﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using updatelog;

namespace MediaCopyAssistant
{
    /// <summary>
    /// 媒体拷贝助手主窗体
    /// 功能：检测外部存储器并拷贝照片/视频文件
    /// </summary>
    public partial class MediaCopyForm : Form
    {
        #region 数据成员
        // 外部驱动器列表
        private List<DriveInfo> externalDrives = new List<DriveInfo>();
        // 当前选中的驱动器
        private DriveInfo selectedDrive;
        // 底部固定控制面板
        private Panel fixedControlPanel;
        // 顶部菜单栏
        private MenuStrip topMenuStrip;

        // 文件类型定义 - 仅支持照片和视频
        private static readonly string[] PhotoExtensions = { ".jpg", ".jpeg" };
        private static readonly string[] VideoExtensions = { ".mp4", ".mov" };

        // 拷贝状态变量
        private bool isCopying = false;
        private CancellationTokenSource cancellationTokenSource;

        // 状态监控相关字段
        private System.Windows.Forms.Timer globalStatusTimer;
        private readonly ConcurrentDictionary<string, DriveBasicStatus> driveBasicStatuses = new ConcurrentDictionary<string, DriveBasicStatus>();

        // 速度更新定时器相关字段（修复版本）
        private System.Windows.Forms.Timer speedUpdateTimer;
        private long speedUpdateTotalBytes = 0;
        private DateTime speedUpdateStartTime = DateTime.Now;
        private DateTime speedUpdateLastTime = DateTime.Now;
        private long speedUpdateLastBytes = 0;

        // 拷贝统计变量（修复版本）
        private long totalBytesToCopy = 0;
        private long totalCopiedBytes = 0;
        private long lastReportedBytes = 0;
        private DateTime lastProgressUpdateTime = DateTime.MinValue;

        // 设备监控相关字段（新增）
        private ManagementEventWatcher deviceInsertWatcher;
        private ManagementEventWatcher deviceRemoveWatcher;
        #endregion

        #region 构造函数和初始化
        /// <summary>
        /// 构造函数
        /// </summary>
        public MediaCopyForm()
        {
            InitializeComponent();
            InitializeApplication();

            // 启动时静默检查更新
            Task.Run(() => CheckForUpdatesOnStartup());

            // 启动时检查FFmpeg完整性
            Task.Run(async () => await CheckFFmpegOnStartup());
        }

        /// <summary>
        /// 初始化应用程序界面和功能
        /// </summary>
        private void InitializeApplication()
        {
            // 设置窗体基本属性
            this.Text = "媒体拷贝助手 - MediaCopy Assistant v2.2.0";
            this.Size = new Size(1000, 800);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MinimumSize = new Size(1000, 800);
            this.FormBorderStyle = FormBorderStyle.FixedSingle; // 固定单边框，不能调整大小
            this.MaximizeBox = false; // 禁用最大化按钮
            this.MinimizeBox = true;  // 保留最小化按钮

            // 创建顶部菜单栏
            CreateTopMenuStrip();

            // 创建表格布局面板
            TableLayoutPanel tableLayout = new TableLayoutPanel()
            {
                Dock = DockStyle.Fill,
                RowCount = 2,
                ColumnCount = 1,
                Margin = new Padding(0)
            };
            tableLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 65F)); // 主面板区域
            tableLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 35F)); // 控制面板区域

            // 设置主面板
            mainPanel.Dock = DockStyle.Fill;
            mainPanel.BackColor = Color.FromArgb(240, 240, 240);
            mainPanel.AutoScroll = true;

            // 创建底部固定控制面板
            CreateFixedControlPanel();

            // 将面板添加到表格布局
            tableLayout.Controls.Add(mainPanel, 0, 0);
            tableLayout.Controls.Add(fixedControlPanel, 0, 1);

            // 将表格布局添加到窗体
            this.Controls.Add(tableLayout);
            tableLayout.BringToFront();

            // 显示初始界面
            ShowInitialInterface();

            // 初始驱动器检测
            CheckExistingDrives();
            UpdateUI();

            // 初始化状态监控
            InitializeGlobalStatusMonitor();

            // 初始化速度更新定时器
            InitializeSpeedUpdateTimer();

            // 初始化设备监控（新增）
            InitializeDeviceMonitoring();
            InitializeUSBStorageMonitoring();
        }
        #endregion

        #region UI创建方法
        /// <summary>
        /// 创建顶部菜单栏
        /// </summary>
        private void CreateTopMenuStrip()
        {
            topMenuStrip = new MenuStrip()
            {
                Dock = DockStyle.Top,
                BackColor = Color.FromArgb(240, 240, 240),
                Font = GetDefaultFont(10)
            };

            // 小工具菜单
            ToolStripMenuItem toolsMenu = new ToolStripMenuItem("小工具");

            // 文件分类整理工具
            ToolStripMenuItem fileOrganizerItem = new ToolStripMenuItem("文件分类整理");
            fileOrganizerItem.Click += (s, e) =>
            {
                // 创建并显示文件分类整理窗口
                FileOrganizerForm organizerForm = new FileOrganizerForm();
                organizerForm.Show();
            };

            // 文件分类整理工具
            ToolStripMenuItem VideoLibraryManagerItem = new ToolStripMenuItem("影视建库管理工具");
            VideoLibraryManagerItem.Click += (s, e) =>
            {
                // 创建并显示文件分类整理窗口
                VideoLibraryManager VideoLibraryManager = new VideoLibraryManager();
                VideoLibraryManager.Show();
            };

            toolsMenu.DropDownItems.AddRange(new ToolStripItem[] { fileOrganizerItem, VideoLibraryManagerItem });

            ToolStripMenuItem resourceMenu = new ToolStripMenuItem("资源管理");

            // FFmpeg测试菜单项
            ToolStripMenuItem ffmpegTestItem = new ToolStripMenuItem("测试FFmpeg完整性");
            ffmpegTestItem.Click += (s, e) => TestFFmpegIntegrity();

            // FFmpeg管理菜单项
            ToolStripMenuItem ffmpegManageItem = new ToolStripMenuItem("FFmpeg组件管理");
            ffmpegManageItem.Click += (s, e) => ShowFFmpegManager();

            resourceMenu.DropDownItems.AddRange(new ToolStripItem[] {
                ffmpegTestItem,
                ffmpegManageItem,
            });

            // 帮助菜单
            ToolStripMenuItem helpMenu = new ToolStripMenuItem("帮助");

            // 关于和使用说明
            ToolStripMenuItem helpItem = new ToolStripMenuItem("快速使用说明");
            helpItem.Click += (s, e) =>
            {
                MessageBox.Show(this,
                    "媒体拷贝助手 v2.2.0\n\n" +
                    "快速使用：\n" +
                    "1. 插入设备 → 自动检测\n" +
                    "2. 选择存储器 → 点击「选择」\n" +
                    "3. 设置参数 → 点击「开始拷贝」\n\n" +

                    "支持格式：JPG/JPEG/MP4/MOV\n\n" +

                    "功能：\n" +
                    "• 按时间筛选文件\n" +
                    "• 自动分类照片/视频\n" +
                    "• 实时速度显示\n\n" +

                    "重要提示：\n" +
                    "• 拷贝中请勿断开设备",
                    "快速使用说明",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
            };

            // 更新日志
            ToolStripMenuItem updatelogItem = new ToolStripMenuItem("更新日志");
            updatelogItem.Click += (s, e) =>
            {
                UpdateLogForm UpdateLog = new UpdateLogForm();
                UpdateLog.Show();
            };

            // 检查更新菜单项
            ToolStripMenuItem updateItem = new ToolStripMenuItem("检查更新");
            updateItem.Click += async (s, e) =>
            {
                try
                {
                    await CheckForUpdatesAsync();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, $"检查更新时发生错误: {ex.Message}", "错误",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            };
            helpMenu.DropDownItems.Add(updateItem);

            helpMenu.DropDownItems.AddRange(new ToolStripItem[] { helpItem, updatelogItem, updateItem });

            // 游戏子菜单
            ToolStripMenuItem gamesSubMenu = new ToolStripMenuItem("小游戏");

            // 小汽车游戏
            ToolStripMenuItem carGameItem = new ToolStripMenuItem("小（叉）车快跑");
            carGameItem.Click += (s, e) =>
            {
                CarGameForm carGameForm = new CarGameForm();
                carGameForm.Show();
            };

            // 贪吃蛇游戏
            ToolStripMenuItem SnakeItem = new ToolStripMenuItem("贪吃蛇");
            SnakeItem.Click += (s, e) =>
            {
                SnakeForm SnakeForm = new SnakeForm();
                SnakeForm.Show();
            };

            // 将所有游戏添加到游戏子菜单
            gamesSubMenu.DropDownItems.AddRange(new ToolStripItem[] { carGameItem, SnakeItem });

            // 将所有菜单添加到菜单栏
            topMenuStrip.Items.AddRange(new ToolStripItem[] {
                toolsMenu,
                resourceMenu,
                helpMenu,
                gamesSubMenu
            });

            // 将菜单栏添加到窗体
            this.Controls.Add(topMenuStrip);
            topMenuStrip.BringToFront();
        }

        /// <summary>
        /// 创建底部固定控制面板
        /// </summary>
        private void CreateFixedControlPanel()
        {
            fixedControlPanel = new Panel()
            {
                Dock = DockStyle.Fill, // 改为Fill以适应表格布局
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Name = "fixedControlPanel",
                Margin = new Padding(0)
            };

            CreateFixedControlPanelContent(fixedControlPanel);
        }

        /// <summary>
        /// 创建底部固定控制面板的内容
        /// </summary>
        private void CreateFixedControlPanelContent(Panel controlPanel)
        {
            try
            {
                controlPanel.Controls.Clear();

                // 标题标签
                Label titleLabel = new Label()
                {
                    Text = "📋 媒体拷贝设置",
                    Font = GetDefaultFont(16, FontStyle.Bold),
                    ForeColor = Color.DarkBlue,
                    Location = new Point(20, 15),
                    Size = new Size(300, 30),
                    TextAlign = ContentAlignment.MiddleLeft,
                    Name = "titleLabel"
                };
                controlPanel.Controls.Add(titleLabel);

                // 未选择存储器时的提示标签
                Label promptLabel = new Label()
                {
                    Text = "请选择存储器后查看",
                    Font = GetDefaultFont(14, FontStyle.Bold),
                    ForeColor = Color.Gray,
                    Location = new Point(350, 15),
                    Size = new Size(300, 30),
                    TextAlign = ContentAlignment.MiddleLeft,
                    Name = "promptLabel",
                    Visible = true
                };
                controlPanel.Controls.Add(promptLabel);

                // 选中的驱动器信息标签
                Label selectedDriveLabel = new Label()
                {
                    Text = "当前未选择存储器",
                    Location = new Point(20, 50),
                    Size = new Size(400, 25),
                    TextAlign = ContentAlignment.MiddleLeft,
                    Font = GetDefaultFont(11, FontStyle.Bold),
                    ForeColor = Color.Gray,
                    Name = "selectedDriveLabel"
                };
                controlPanel.Controls.Add(selectedDriveLabel);

                int yPos = 80;
                int labelWidth = 120;
                int controlX = 150;
                int rowHeight = 35;

                // 第一行：拷贝时间和文件类型
                CreateFirstRowControls(controlPanel, yPos, labelWidth, controlX);
                yPos += rowHeight;

                // 第二行：拷贝位置和备份设置
                CreateSecondRowControls(controlPanel, yPos, labelWidth, controlX);
                yPos += rowHeight;

                // 第三行：命名设置
                CreateThirdRowControls(controlPanel, yPos, labelWidth, controlX);
                yPos += 40;

                // 第四行：开始按钮和进度显示
                CreateFourthRowControls(controlPanel, yPos);

                // 初始时隐藏所有设置控件
                SetControlPanelVisibility(false);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"创建固定控制面板内容时出错: {ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 创建第一行控件（拷贝时间和文件类型）
        /// </summary>
        private void CreateFirstRowControls(Panel parent, int yPos, int labelWidth, int controlX)
        {
            // 拷贝时间标签
            Label timeLabel = new Label()
            {
                Text = "拷贝起始时间:",
                Location = new Point(20, yPos),
                Size = new Size(labelWidth, 25),
                TextAlign = ContentAlignment.MiddleLeft,
                Font = GetDefaultFont(11),
                Name = "timeLabel"
            };

            // 日期选择器
            DateTimePicker timePicker = new DateTimePicker()
            {
                Location = new Point(controlX, yPos),
                Size = new Size(140, 25),
                Format = DateTimePickerFormat.Short,
                Value = DateTime.Now,
                Font = GetDefaultFont(10),
                Name = "timePicker"
            };
            parent.Controls.Add(timeLabel);
            parent.Controls.Add(timePicker);

            // 文件类型标签
            Label typeLabel = new Label()
            {
                Text = "拷贝文件类型:",
                Location = new Point(300, yPos),
                Size = new Size(labelWidth, 25),
                TextAlign = ContentAlignment.MiddleLeft,
                Font = GetDefaultFont(11),
                Name = "typeLabel"
            };

            // 照片复选框
            CheckBox photoCheck = new CheckBox()
            {
                Text = "📷 照片",
                Location = new Point(430, yPos),
                Size = new Size(80, 25),
                Checked = true,
                Font = GetDefaultFont(10),
                Name = "photoCheck"
            };

            // 视频复选框
            CheckBox videoCheck = new CheckBox()
            {
                Text = "🎥 视频",
                Location = new Point(520, yPos),
                Size = new Size(80, 25),
                Checked = true,
                Font = GetDefaultFont(10),
                Name = "videoCheck"
            };
            parent.Controls.Add(typeLabel);
            parent.Controls.Add(photoCheck);
            parent.Controls.Add(videoCheck);
        }

        /// <summary>
        /// 创建第二行控件（拷贝位置和备份设置）
        /// </summary>
        private void CreateSecondRowControls(Panel parent, int yPos, int labelWidth, int controlX)
        {
            // 拷贝位置标签
            Label copyLabel = new Label()
            {
                Text = "拷贝位置:",
                Location = new Point(20, yPos),
                Size = new Size(labelWidth, 25),
                TextAlign = ContentAlignment.MiddleLeft,
                Font = GetDefaultFont(11),
                Name = "copyLabel"
            };

            // 拷贝路径文本框
            TextBox copyPathText = new TextBox()
            {
                Location = new Point(controlX, yPos),
                Size = new Size(250, 25),
                Text = GetDefaultCopyPath(),
                Font = GetDefaultFont(10),
                Name = "copyPathText"
            };

            // 浏览按钮
            Button copyBrowseBtn = new Button()
            {
                Text = "浏览",
                Location = new Point(controlX + 260, yPos),
                Size = new Size(60, 25),
                Font = GetDefaultFont(10),
                Name = "copyBrowseBtn"
            };
            copyBrowseBtn.Click += (s, e) => BrowseFolder(copyPathText, "选择拷贝目标位置");

            parent.Controls.Add(copyLabel);
            parent.Controls.Add(copyPathText);
            parent.Controls.Add(copyBrowseBtn);

            // 备份复选框
            CheckBox backupCheck = new CheckBox()
            {
                Text = "备份到:",
                Location = new Point(480, yPos),
                Size = new Size(80, 25),
                Font = GetDefaultFont(11),
                Name = "backupCheck"
            };

            // 备份路径文本框
            TextBox backupPathText = new TextBox()
            {
                Location = new Point(570, yPos),
                Size = new Size(250, 25),
                Enabled = false,
                Font = GetDefaultFont(10),
                Name = "backupPathText"
            };

            // 备份浏览按钮
            Button backupBrowseBtn = new Button()
            {
                Text = "浏览",
                Location = new Point(570 + 260, yPos),
                Size = new Size(60, 25),
                Enabled = false,
                Font = GetDefaultFont(10),
                Name = "backupBrowseBtn"
            };
            backupBrowseBtn.Click += (s, e) => BrowseFolder(backupPathText, "选择备份位置");

            // 备份复选框状态改变事件
            backupCheck.CheckedChanged += (s, e) =>
            {
                backupPathText.Enabled = backupCheck.Checked;
                backupBrowseBtn.Enabled = backupCheck.Checked;
            };

            parent.Controls.Add(backupCheck);
            parent.Controls.Add(backupPathText);
            parent.Controls.Add(backupBrowseBtn);
        }

        /// <summary>
        /// 创建第三行控件（命名设置）
        /// </summary>
        private void CreateThirdRowControls(Panel parent, int yPos, int labelWidth, int controlX)
        {
            // 命名设置标签
            Label namingLabel = new Label()
            {
                Text = "文件命名:",
                Location = new Point(20, yPos),
                Size = new Size(labelWidth, 25),
                TextAlign = ContentAlignment.MiddleLeft,
                Font = GetDefaultFont(11),
                Name = "namingLabel"
            };

            // 前缀标签
            Label prefixLabel = new Label()
            {
                Text = "前缀:",
                Location = new Point(controlX, yPos - 2),
                Size = new Size(40, 25),
                TextAlign = ContentAlignment.MiddleLeft,
                Font = GetDefaultFont(10),
                Name = "prefixLabel"
            };

            // 前缀文本框
            TextBox prefixText = new TextBox()
            {
                Location = new Point(controlX + 45, yPos),
                Size = new Size(100, 25),
                Text = "Backup",
                Font = GetDefaultFont(10),
                Name = "prefixText"
            };

            // 时间戳复选框
            CheckBox timestampCheck = new CheckBox()
            {
                Text = "增加时间戳",
                Location = new Point(controlX + 160, yPos),
                Size = new Size(120, 25),
                Checked = true,
                Font = GetDefaultFont(10),
                Name = "timestampCheck"
            };

            // 文件名预览标签
            Label previewLabel = new Label()
            {
                Text = "预览: Backup_20241201_原文件名.jpg",
                Location = new Point(controlX + 300, yPos), // 调整位置
                Size = new Size(400, 25),
                TextAlign = ContentAlignment.MiddleLeft,
                Font = GetDefaultFont(9),
                ForeColor = Color.Gray,
                Name = "previewLabel"
            };

            // 实时更新预览
            prefixText.TextChanged += (s, e) => UpdateFilenamePreview(previewLabel, prefixText, timestampCheck);
            timestampCheck.CheckedChanged += (s, e) => UpdateFilenamePreview(previewLabel, prefixText, timestampCheck);

            parent.Controls.Add(namingLabel);
            parent.Controls.Add(prefixLabel);
            parent.Controls.Add(prefixText);
            parent.Controls.Add(timestampCheck);
            parent.Controls.Add(previewLabel);
        }

        /// <summary>
        /// 创建第四行控件（开始按钮和进度显示）
        /// </summary>
        private void CreateFourthRowControls(Panel parent, int yPos)
        {
            // 开始按钮
            Button startButton = new Button()
            {
                Text = "🚀 开始拷贝",
                Location = new Point(20, yPos),
                Size = new Size(120, 40),
                BackColor = Color.LightBlue,
                Font = GetDefaultFont(12, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                Name = "startButton"
            };
            startButton.Click += StartCopy_Click;

            // 进度标签
            Label progressLabel = new Label()
            {
                Text = "进度:",
                Location = new Point(160, yPos + 10),
                Size = new Size(50, 25),
                TextAlign = ContentAlignment.MiddleLeft,
                Font = GetDefaultFont(11),
                Name = "progressLabel"
            };

            // 进度条
            ProgressBar progressBar = new ProgressBar()
            {
                Location = new Point(220, yPos + 10),
                Size = new Size(300, 25),
                Name = "progressBar"
            };

            // 数据量标签（新增，显示已拷贝/总数据量）
            Label dataAmountLabel = new Label()
            {
                Text = "0 B / 0 B",
                Location = new Point(220, yPos + 35),
                Size = new Size(300, 20),
                TextAlign = ContentAlignment.MiddleCenter,
                Font = GetDefaultFont(9),
                ForeColor = Color.DarkBlue,
                Name = "dataAmountLabel"
            };

            // 速度标签
            Label speedLabel = new Label()
            {
                Text = "速度: --",
                Location = new Point(530, yPos + 10),
                Size = new Size(100, 25),
                TextAlign = ContentAlignment.MiddleLeft,
                Font = GetDefaultFont(10),
                ForeColor = Color.DarkGreen,
                Name = "speedLabel"
            };

            // 状态标签
            Label statusLabel = new Label()
            {
                Text = "准备就绪",
                Location = new Point(640, yPos + 10),
                Size = new Size(300, 25),
                TextAlign = ContentAlignment.MiddleLeft,
                Font = GetDefaultFont(11),
                ForeColor = Color.DarkBlue,
                Name = "statusLabel"
            };

            parent.Controls.Add(startButton);
            parent.Controls.Add(progressLabel);
            parent.Controls.Add(progressBar);
            parent.Controls.Add(dataAmountLabel);
            parent.Controls.Add(speedLabel);
            parent.Controls.Add(statusLabel);
        }

        /// <summary>
        /// 设置控制面板的可见性
        /// </summary>
        private void SetControlPanelVisibility(bool visible)
        {
            if (fixedControlPanel == null) return;

            string[] controlNames = {
                "timeLabel", "timePicker", "typeLabel", "photoCheck", "videoCheck",
                "copyLabel", "copyPathText", "copyBrowseBtn", "backupCheck",
                "backupPathText", "backupBrowseBtn", "namingLabel", "prefixLabel",
                "prefixText", "timestampCheck", "previewLabel", "progressLabel",
                "progressBar", "statusLabel", "startButton", "speedLabel", "dataAmountLabel"
            };

            foreach (string name in controlNames)
            {
                Control control = fixedControlPanel.Controls.Find(name, false).FirstOrDefault();
                if (control != null)
                {
                    control.Visible = visible;
                }
            }

            Label promptLabel = fixedControlPanel.Controls.Find("promptLabel", false).FirstOrDefault() as Label;
            if (promptLabel != null)
            {
                promptLabel.Visible = !visible;
            }
        }
        #endregion

        #region 辅助方法
        /// <summary>
        /// 获取默认字体
        /// </summary>
        private Font GetDefaultFont(float size, FontStyle style = FontStyle.Regular)
        {
            try
            {
                return new Font("得意黑", size + 1, style);
            }
            catch
            {
                return new Font("微软雅黑", size, style);
            }
        }

        /// <summary>
        /// 显示初始界面
        /// </summary>
        private void ShowInitialInterface()
        {
            Label initialLabel = new Label()
            {
                Text = "正在检测存储器...",
                Font = GetDefaultFont(16, FontStyle.Bold),
                ForeColor = Color.DarkBlue,
                Location = new Point(50, 50),
                AutoSize = true
            };
            mainPanel.Controls.Add(initialLabel);
        }

        /// <summary>
        /// 检查现有驱动器
        /// </summary>
        private void CheckExistingDrives()
        {
            externalDrives.Clear();

            try
            {
                // 方法1：使用DriveInfo检测可移动设备
                foreach (var drive in DriveInfo.GetDrives())
                {
                    try
                    {
                        if (drive.IsReady)
                        {
                            // 检测可移动设备
                            if (drive.DriveType == DriveType.Removable)
                            {
                                // 额外检查：确保不是系统保留的驱动器
                                if (drive.TotalSize > 0)
                                {
                                    externalDrives.Add(drive);
                                }
                            }
                            // 检测网络驱动器（某些SD卡读卡器可能被识别为Fixed）
                            else if (drive.DriveType == DriveType.Fixed)
                            {
                                // 检查是否为可能的SD卡读卡器
                                // 通常SD卡读卡器会有特定的卷标或名称
                                string volumeLabel = drive.VolumeLabel?.ToUpper() ?? "";
                                if (volumeLabel.Contains("SD") || volumeLabel.Contains("REMOVABLE"))
                                {
                                    externalDrives.Add(drive);
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"访问驱动器 {drive.Name} 失败: {ex.Message}");
                    }
                }

                // 方法2：使用WMI检测所有可移动存储设备（更全面）
                DetectRemovableDrivesUsingWMI();

                // 如果还是没有找到，显示提示
                if (externalDrives.Count == 0)
                {
                    Console.WriteLine("未检测到外部存储设备");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"检测驱动器时发生错误: {ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 使用WMI检测可移动存储设备（更可靠）
        /// </summary>
        private void DetectRemovableDrivesUsingWMI()
        {
            try
            {
                ManagementObjectSearcher searcher = new ManagementObjectSearcher(
                    "SELECT * FROM Win32_DiskDrive WHERE InterfaceType='USB' OR MediaType LIKE '%Flash%' OR MediaType LIKE '%Removable%'");

                foreach (ManagementObject disk in searcher.Get())
                {
                    try
                    {
                        string deviceId = disk["DeviceID"].ToString();

                        // 获取与磁盘关联的逻辑驱动器
                        ManagementObjectSearcher partitionSearcher = new ManagementObjectSearcher(
                            $"ASSOCIATORS OF {{Win32_DiskDrive.DeviceID='{deviceId.Replace("\\", "\\\\")}'}} WHERE AssocClass = Win32_DiskDriveToDiskPartition");

                        foreach (ManagementObject partition in partitionSearcher.Get())
                        {
                            ManagementObjectSearcher logicalSearcher = new ManagementObjectSearcher(
                                $"ASSOCIATORS OF {{Win32_DiskPartition.DeviceID='{partition["DeviceID"]}'}} WHERE AssocClass = Win32_LogicalDiskToPartition");

                            foreach (ManagementObject logicalDisk in logicalSearcher.Get())
                            {
                                string driveLetter = logicalDisk["DeviceID"].ToString();

                                // 检查是否已在列表中
                                if (!externalDrives.Any(d => d.Name.Equals(driveLetter, StringComparison.OrdinalIgnoreCase)))
                                {
                                    try
                                    {
                                        DriveInfo drive = new DriveInfo(driveLetter);
                                        if (drive.IsReady)
                                        {
                                            externalDrives.Add(drive);
                                        }
                                    }
                                    catch
                                    {
                                        // 忽略无法访问的驱动器
                                    }
                                }
                            }
                        }
                    }
                    catch
                    {
                        // 继续处理下一个磁盘
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"WMI检测失败: {ex.Message}");
            }
        }

        /// <summary>
        /// 更新用户界面
        /// </summary>
        private void UpdateUI()
        {
            mainPanel.Controls.Clear();
            AddRescanButton();

            if (externalDrives.Count == 0)
            {
                ShowNoDrivesInterface();
            }
            else
            {
                ShowDriveList();
            }

            UpdateSelectedDriveInfo();
        }

        /// <summary>
        /// 添加重新检测按钮
        /// </summary>
        private void AddRescanButton()
        {
            Button rescanButton = new Button()
            {
                Text = "重新检测存储器",
                Size = new Size(140, 35),
                Location = new Point(20, 20),
                BackColor = Color.LightBlue,
                Font = GetDefaultFont(11, FontStyle.Bold)
            };
            rescanButton.Click += (s, e) =>
            {
                CheckExistingDrives();
                UpdateUI();
            };
            mainPanel.Controls.Add(rescanButton);
        }

        /// <summary>
        /// 显示无驱动器界面
        /// </summary>
        private void ShowNoDrivesInterface()
        {
            int centerX = mainPanel.ClientSize.Width / 2;
            int centerY = mainPanel.ClientSize.Height / 3;

            Panel containerPanel = new Panel()
            {
                Size = new Size(500, 300),
                Location = new Point(centerX - 250, centerY - 150),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };

            Label iconLabel = new Label()
            {
                Text = "💾",
                Font = new Font("Segoe UI Emoji", 48),
                Location = new Point(200, 30),
                Size = new Size(100, 80),
                TextAlign = ContentAlignment.MiddleCenter
            };

            Label mainLabel = new Label()
            {
                Text = "未检测到存储器",
                Font = GetDefaultFont(24, FontStyle.Bold),
                ForeColor = Color.DarkGray,
                Location = new Point(50, 120),
                Size = new Size(400, 60),
                TextAlign = ContentAlignment.MiddleCenter
            };

            Label subLabel = new Label()
            {
                Text = "请插入USB设备后点击'重新检测存储器'",
                Font = GetDefaultFont(14),
                ForeColor = Color.Gray,
                Location = new Point(50, 190),
                Size = new Size(400, 30),
                TextAlign = ContentAlignment.MiddleCenter
            };

            Label actionLabel = new Label()
            {
                Text = "或者检查设备是否已正确连接并识别",
                Font = GetDefaultFont(12),
                ForeColor = Color.Orange,
                Location = new Point(50, 230),
                Size = new Size(400, 30),
                TextAlign = ContentAlignment.MiddleCenter
            };

            containerPanel.Controls.Add(iconLabel);
            containerPanel.Controls.Add(mainLabel);
            containerPanel.Controls.Add(subLabel);
            containerPanel.Controls.Add(actionLabel);
            mainPanel.Controls.Add(containerPanel);
        }

        /// <summary>
        /// 显示驱动器列表
        /// </summary>
        private void ShowDriveList()
        {
            int startY = 70;

            foreach (var drive in externalDrives)
            {
                Panel drivePanel = CreateDrivePanel(drive, startY);
                if (drivePanel != null)
                {
                    mainPanel.Controls.Add(drivePanel);
                    startY += drivePanel.Height + 10;
                }
            }
        }

        /// <summary>
        /// 创建单个驱动器面板
        /// </summary>
        private Panel CreateDrivePanel(DriveInfo drive, int yPos)
        {
            try
            {
                int panelWidth = Math.Min(650, mainPanel.ClientSize.Width - 40);
                int panelHeight = 140;
                int xPos = (mainPanel.ClientSize.Width - panelWidth) / 2;

                Panel panel = new Panel()
                {
                    Size = new Size(panelWidth, panelHeight),
                    Location = new Point(xPos, yPos),
                    BorderStyle = BorderStyle.FixedSingle,
                    BackColor = (selectedDrive == drive) ? Color.FromArgb(220, 255, 220) : Color.White,
                    Tag = drive
                };

                // 驱动器图标
                Label iconLabel = new Label()
                {
                    Text = GetDriveIcon(drive.DriveType),
                    Font = new Font("Segoe UI Emoji", 18),
                    Location = new Point(15, 15),
                    Size = new Size(35, 35),
                    TextAlign = ContentAlignment.MiddleCenter
                };

                // 驱动器信息
                string volumeName = string.IsNullOrEmpty(drive.VolumeLabel) ? "本地磁盘" : drive.VolumeLabel;
                Label driveLabel = new Label()
                {
                    Text = $"{drive.Name} - {volumeName}",
                    Font = GetDefaultFont(14, FontStyle.Bold),
                    Location = new Point(60, 15),
                    Size = new Size(400, 30),
                    TextAlign = ContentAlignment.MiddleLeft
                };

                // 容量信息
                long totalSize = drive.TotalSize;
                long freeSize = drive.TotalFreeSpace;
                long usedSize = totalSize - freeSize;
                int usagePercent = totalSize > 0 ? (int)((usedSize * 100) / totalSize) : 0;

                Label sizeLabel = new Label()
                {
                    Text = $"总容量: {FormatFileSize(totalSize)} | 已用: {FormatFileSize(usedSize)} | 可用: {FormatFileSize(freeSize)}",
                    Location = new Point(60, 50),
                    Size = new Size(450, 25),
                    TextAlign = ContentAlignment.MiddleLeft,
                    Font = GetDefaultFont(11)
                };

                // 进度条
                ProgressBar progressBar = new ProgressBar()
                {
                    Location = new Point(60, 80),
                    Size = new Size(400, 20),
                    Minimum = 0,
                    Maximum = 100,
                    Value = usagePercent
                };

                // 使用百分比
                Label percentLabel = new Label()
                {
                    Text = $"{usagePercent}%",
                    Location = new Point(465, 80),
                    Size = new Size(40, 20),
                    TextAlign = ContentAlignment.MiddleCenter,
                    Font = GetDefaultFont(10, FontStyle.Bold),
                    ForeColor = GetUsageColor(usagePercent)
                };

                // 拷贝状态标签
                Label basicStatusLabel = new Label()
                {
                    Name = "basicStatusLabel",
                    Text = GetBasicStatusText(drive.Name),
                    Location = new Point(60, 105),
                    Size = new Size(400, 25),
                    TextAlign = ContentAlignment.MiddleLeft,
                    Font = GetDefaultFont(10, FontStyle.Bold),
                    ForeColor = GetBasicStatusColor(drive.Name),
                    BackColor = Color.FromArgb(245, 245, 245),
                    BorderStyle = BorderStyle.FixedSingle,
                    Padding = new Padding(3)
                };

                // 选择按钮
                bool isSelected = (selectedDrive == drive);
                Button selectButton = new Button()
                {
                    Text = isSelected ? "✅ 已选择" : "选择",
                    Location = new Point(520, 45),
                    Size = new Size(90, 35),
                    BackColor = isSelected ? Color.LightGreen : SystemColors.Control,
                    Font = GetDefaultFont(11),
                    Tag = drive,
                    FlatStyle = FlatStyle.Flat
                };
                selectButton.Click += (s, e) => ToggleDriveSelection(drive);

                panel.Controls.Add(iconLabel);
                panel.Controls.Add(driveLabel);
                panel.Controls.Add(sizeLabel);
                panel.Controls.Add(progressBar);
                panel.Controls.Add(percentLabel);
                panel.Controls.Add(basicStatusLabel);
                panel.Controls.Add(selectButton);

                return panel;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"创建驱动器面板失败 ({drive.Name}): {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// 根据使用百分比获取颜色
        /// </summary>
        private Color GetUsageColor(int percentage)
        {
            if (percentage >= 90) return Color.Red;
            if (percentage >= 70) return Color.Orange;
            return Color.Green;
        }

        /// <summary>
        /// 根据驱动器类型获取图标
        /// </summary>
        private string GetDriveIcon(DriveType driveType)
        {
            switch (driveType)
            {
                case DriveType.Removable: return "💾";
                case DriveType.Fixed: return "💻";
                case DriveType.Network: return "🌐";
                case DriveType.CDRom: return "📀";
                default: return "❓";
            }
        }

        /// <summary>
        /// 格式化文件大小（添加单位）
        /// </summary>
        private string FormatFileSize(long bytes)
        {
            if (bytes <= 0) return "0 B";

            string[] suffixes = { "B", "KB", "MB", "GB", "TB" };
            int counter = 0;
            decimal number = bytes;
            while (Math.Round(number / 1024) >= 1)
            {
                number /= 1024;
                counter++;
            }
            return $"{number:n1} {suffixes[counter]}";
        }

        /// <summary>
        /// 格式化速度显示（添加单位）
        /// </summary>
        private string FormatSpeed(double bytesPerSecond)
        {
            if (bytesPerSecond <= 0) return "0 B/s";

            string[] units = { "B/s", "KB/s", "MB/s", "GB/s" };
            int unitIndex = 0;
            double speed = bytesPerSecond;

            while (speed >= 1024 && unitIndex < units.Length - 1)
            {
                speed /= 1024;
                unitIndex++;
            }

            return $"{speed:0.##} {units[unitIndex]}";
        }

        /// <summary>
        /// 格式化时间间隔
        /// </summary>
        private string FormatTimeSpan(TimeSpan timeSpan)
        {
            if (timeSpan.TotalHours >= 1)
                return $"{(int)timeSpan.TotalHours}h {timeSpan.Minutes}m {timeSpan.Seconds}s";
            else if (timeSpan.TotalMinutes >= 1)
                return $"{(int)timeSpan.TotalMinutes}m {timeSpan.Seconds}s";
            else
                return $"{timeSpan.TotalSeconds:0.##}s";
        }

        /// <summary>
        /// 安全的UI调用方法（确保在UI线程上执行）
        /// </summary>
        private void SafeInvoke(Action action)
        {
            if (this.IsDisposed || !this.IsHandleCreated || this.Disposing)
                return;

            try
            {
                if (this.InvokeRequired)
                {
                    this.BeginInvoke(action);
                }
                else
                {
                    action();
                }
            }
            catch (ObjectDisposedException)
            {
                // 忽略已释放的窗体调用
            }
            catch (InvalidOperationException)
            {
                // 忽略无效操作异常
            }
        }

        /// <summary>
        /// 切换驱动器选择状态
        /// </summary>
        private void ToggleDriveSelection(DriveInfo drive)
        {
            try
            {
                if (selectedDrive == drive)
                {
                    selectedDrive = null;
                }
                else
                {
                    selectedDrive = drive;
                }

                UpdateDrivePanelsSelectionState();
                UpdateSelectedDriveInfo();
                SetControlPanelVisibility(selectedDrive != null);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"切换驱动器选择状态时出错: {ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 更新所有驱动器面板的选择状态
        /// </summary>
        private void UpdateDrivePanelsSelectionState()
        {
            foreach (Control control in mainPanel.Controls)
            {
                if (control is Panel panel && panel.Tag is DriveInfo panelDrive)
                {
                    bool isSelected = (panelDrive == selectedDrive);
                    panel.BackColor = isSelected ? Color.FromArgb(220, 255, 220) : Color.White;

                    Button selectButton = panel.Controls.OfType<Button>().FirstOrDefault(b => b.Tag is DriveInfo);
                    if (selectButton != null)
                    {
                        selectButton.Text = isSelected ? "✅ 已选择" : "选择";
                        selectButton.BackColor = isSelected ? Color.LightGreen : SystemColors.Control;
                    }
                }
            }
        }

        /// <summary>
        /// 更新选中的驱动器信息
        /// </summary>
        private void UpdateSelectedDriveInfo()
        {
            if (fixedControlPanel != null)
            {
                Label selectedDriveLabel = fixedControlPanel.Controls.Find("selectedDriveLabel", false).FirstOrDefault() as Label;
                if (selectedDriveLabel != null)
                {
                    if (selectedDrive != null)
                    {
                        string volumeName = string.IsNullOrEmpty(selectedDrive.VolumeLabel) ? "本地磁盘" : selectedDrive.VolumeLabel;
                        selectedDriveLabel.Text = $"当前选中: {selectedDrive.Name} - {volumeName}";
                        selectedDriveLabel.ForeColor = Color.DarkGreen;
                    }
                    else
                    {
                        selectedDriveLabel.Text = "当前未选择存储器";
                        selectedDriveLabel.ForeColor = Color.Gray;
                    }
                }
            }
        }

        /// <summary>
        /// 更新文件名预览
        /// </summary>
        private void UpdateFilenamePreview(Label previewLabel, TextBox prefixText, CheckBox timestampCheck)
        {
            string prefix = string.IsNullOrWhiteSpace(prefixText.Text) ? "Backup" : prefixText.Text;
            string timestamp = timestampCheck.Checked ? DateTime.Now.ToString("yyyyMMdd") : "";
            string separator = timestampCheck.Checked ? "_" : "";

            string preview = $"{prefix}{separator}{timestamp}_原文件名.jpg";
            previewLabel.Text = $"预览: {preview}";
        }

        /// <summary>
        /// 获取默认拷贝路径 - 直接使用桌面路径
        /// </summary>
        private string GetDefaultCopyPath()
        {
            return Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        }

        /// <summary>
        /// 浏览文件夹对话框
        /// </summary>
        private void BrowseFolder(TextBox textBox, string description)
        {
            try
            {
                using (FolderBrowserDialog dialog = new FolderBrowserDialog())
                {
                    dialog.Description = description;
                    dialog.ShowNewFolderButton = true;

                    if (dialog.ShowDialog() == DialogResult.OK)
                    {
                        textBox.Text = dialog.SelectedPath;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"选择文件夹时出错: {ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 更新数据量显示（修复版本）
        /// </summary>
        private void UpdateDataAmountDisplay()
        {
            try
            {
                SafeInvoke(() => {
                    Label dataAmountLabel = fixedControlPanel?.Controls.Find("dataAmountLabel", false).FirstOrDefault() as Label;
                    ProgressBar progressBar = fixedControlPanel?.Controls.Find("progressBar", false).FirstOrDefault() as ProgressBar;

                    if (dataAmountLabel != null && progressBar != null)
                    {
                        if (totalBytesToCopy > 0)
                        {
                            try
                            {
                                // 确保totalCopiedBytes不会超过totalBytesToCopy
                                long safeCopiedBytes = Math.Min(totalCopiedBytes, totalBytesToCopy);

                                // 计算百分比
                                int percentage = (int)((safeCopiedBytes * 100) / totalBytesToCopy);
                                percentage = Math.Min(Math.Max(percentage, 0), 100);

                                // 更新数据量标签
                                dataAmountLabel.Text = $"{FormatFileSize(safeCopiedBytes)} / {FormatFileSize(totalBytesToCopy)} ({percentage}%)";

                                // 更新进度条
                                progressBar.Value = percentage;

                                // 记录最后报告的值
                                lastReportedBytes = safeCopiedBytes;
                            }
                            catch (DivideByZeroException)
                            {
                                dataAmountLabel.Text = $"{FormatFileSize(totalCopiedBytes)} / {FormatFileSize(totalBytesToCopy)}";
                                progressBar.Value = 0;
                            }
                            catch (OverflowException)
                            {
                                dataAmountLabel.Text = $"{FormatFileSize(totalCopiedBytes)} / {FormatFileSize(totalBytesToCopy)}";
                                progressBar.Value = 100;
                            }
                        }
                        else
                        {
                            dataAmountLabel.Text = "0 B / 0 B";
                            progressBar.Value = 0;
                        }

                        // 记录更新时间
                        lastProgressUpdateTime = DateTime.Now;
                    }
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"更新数据量显示时出错: {ex.Message}");
            }
        }
        #endregion

        #region 设备监控方法
        /// <summary>
        /// 初始化设备监控
        /// </summary>
        private void InitializeDeviceMonitoring()
        {
            try
            {
                // 监控设备插入事件
                deviceInsertWatcher = new ManagementEventWatcher(
                    new WqlEventQuery("SELECT * FROM Win32_DeviceChangeEvent WHERE EventType = 2"));
                deviceInsertWatcher.EventArrived += (sender, e) =>
                {
                    // 延迟检测，给系统时间识别设备
                    Task.Delay(1000).ContinueWith(_ =>
                    {
                        SafeInvoke(() =>
                        {
                            CheckExistingDrives();
                            UpdateUI();
                        });
                    });
                };
                deviceInsertWatcher.Start();

                // 监控设备移除事件
                deviceRemoveWatcher = new ManagementEventWatcher(
                    new WqlEventQuery("SELECT * FROM Win32_DeviceChangeEvent WHERE EventType = 3"));
                deviceRemoveWatcher.EventArrived += (sender, e) =>
                {
                    SafeInvoke(() =>
                    {
                        CheckExistingDrives();
                        UpdateUI();
                    });
                };
                deviceRemoveWatcher.Start();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"初始化设备监控失败: {ex.Message}");
            }
        }

        /// <summary>
        /// 监控USB大容量存储设备
        /// </summary>
        private void InitializeUSBStorageMonitoring()
        {
            try
            {
                // 监控USB大容量存储设备
                var query = new WqlEventQuery("SELECT * FROM __InstanceCreationEvent WITHIN 2 WHERE TargetInstance ISA 'Win32_USBHub'");
                var watcher = new ManagementEventWatcher(query);
                watcher.EventArrived += (sender, e) =>
                {
                    // 等待设备完全初始化
                    Task.Delay(2000).ContinueWith(_ =>
                    {
                        SafeInvoke(() =>
                        {
                            CheckExistingDrives();
                            UpdateUI();
                        });
                    });
                };
                watcher.Start();

                // 监控设备移除
                var removeQuery = new WqlEventQuery("SELECT * FROM __InstanceDeletionEvent WITHIN 2 WHERE TargetInstance ISA 'Win32_USBHub'");
                var removeWatcher = new ManagementEventWatcher(removeQuery);
                removeWatcher.EventArrived += (sender, e) =>
                {
                    SafeInvoke(() =>
                    {
                        CheckExistingDrives();
                        UpdateUI();
                    });
                };
                removeWatcher.Start();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"USB设备监控初始化失败: {ex.Message}");
            }
        }
        #endregion

        #region 拷贝核心方法
        /// <summary>
        /// 执行文件拷贝操作
        /// </summary>
        private async Task PerformFileCopy(DateTime copyDate, bool copyPhotos, bool copyVideos,
                                         string copyPath, bool backupEnabled, string backupPath,
                                         string prefix, bool useTimestamp,
                                         Label statusLabel, CancellationToken cancellationToken)
        {
            // 初始化基本状态信息
            var basicStatus = new DriveBasicStatus
            {
                DriveName = selectedDrive.Name,
                Status = "开始拷贝",
                IsCopying = true,
                StartTime = DateTime.Now
            };

            driveBasicStatuses[selectedDrive.Name] = basicStatus;

            // 获取界面控件
            Label speedLabel = fixedControlPanel.Controls.Find("speedLabel", false).FirstOrDefault() as Label;
            ProgressBar progressBar = fixedControlPanel.Controls.Find("progressBar", false).FirstOrDefault() as ProgressBar;
            Label dataAmountLabel = fixedControlPanel.Controls.Find("dataAmountLabel", false).FirstOrDefault() as Label;

            // 重置所有统计变量
            totalBytesToCopy = 0;
            totalCopiedBytes = 0;
            lastReportedBytes = 0;
            speedUpdateTotalBytes = 0;
            speedUpdateLastBytes = 0;
            speedUpdateStartTime = DateTime.Now;
            speedUpdateLastTime = DateTime.Now;
            lastProgressUpdateTime = DateTime.MinValue;

            // 更新UI
            SafeInvoke(() => {
                statusLabel.Text = "正在搜索文件...";
                statusLabel.ForeColor = Color.DarkBlue;

                if (speedLabel != null)
                {
                    speedLabel.Text = "速度: --";
                    speedLabel.ForeColor = Color.DarkGreen;
                }

                if (progressBar != null)
                {
                    progressBar.Value = 0;
                }

                if (dataAmountLabel != null)
                {
                    dataAmountLabel.Text = "0 B / 0 B";
                }
            });

            try
            {
                // 使用异步方法搜索文件
                List<string> filesToCopy = await Task.Run(() => GetFilesToCopy(copyDate, copyPhotos, copyVideos, cancellationToken));

                basicStatus.TotalFiles = filesToCopy.Count;
                basicStatus.Status = "搜索文件";

                // 计算文件统计信息
                var fileStats = await CalculateFileStatistics(filesToCopy);
                int photoCount = fileStats.PhotoCount;
                int videoCount = fileStats.VideoCount;
                totalBytesToCopy = fileStats.TotalSize;

                // 显示文件统计信息 - 弹出提示框（修复：同步调用）
                string fileInfo = $"找到 {filesToCopy.Count} 个文件\n";
                if (copyPhotos) fileInfo += $"照片: {photoCount} 个，大小: {FormatFileSize(fileStats.PhotoSize)}\n";
                if (copyVideos) fileInfo += $"视频: {videoCount} 个，大小: {FormatFileSize(fileStats.VideoSize)}\n";
                fileInfo += $"总大小: {FormatFileSize(totalBytesToCopy)}";

                // 修复：使用同步方式显示确认弹窗并等待用户响应
                DialogResult userResponse = DialogResult.No;

                if (this.InvokeRequired)
                {
                    userResponse = (DialogResult)this.Invoke(new Func<DialogResult>(() =>
                    {
                        return MessageBox.Show(this,
                            $"{fileInfo}\n\n是否开始拷贝？",
                            "文件统计信息",
                            MessageBoxButtons.YesNo,
                            MessageBoxIcon.Information);
                    }));
                }
                else
                {
                    userResponse = MessageBox.Show(this,
                        $"{fileInfo}\n\n是否开始拷贝？",
                        "文件统计信息",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Information);
                }

                // 检查用户是否取消
                if (userResponse == DialogResult.No)
                {
                    basicStatus.IsCopying = false;
                    basicStatus.EndTime = DateTime.Now;
                    basicStatus.Status = "用户取消";

                    SafeInvoke(() => {
                        statusLabel.Text = "用户取消拷贝";
                        statusLabel.ForeColor = Color.Orange;

                        // 恢复开始按钮状态
                        Button startButton = fixedControlPanel.Controls.Find("startButton", false).FirstOrDefault() as Button;
                        if (startButton != null)
                        {
                            startButton.Text = "🚀 开始拷贝";
                            startButton.BackColor = Color.LightBlue;
                        }

                        // 停止速度更新定时器（如果已启动）
                        if (speedUpdateTimer != null && speedUpdateTimer.Enabled)
                        {
                            speedUpdateTimer.Stop();
                        }

                        // 重置进度显示
                        if (dataAmountLabel != null)
                        {
                            dataAmountLabel.Text = "0 B / 0 B";
                        }

                        if (progressBar != null)
                        {
                            progressBar.Value = 0;
                        }
                    });

                    // 设置标志，防止后续的finally块重复恢复
                    isCopying = false;
                    return;
                }

                // 用户确认后继续执行
                basicStatus.Status = "准备拷贝";

                // 更新状态标签
                SafeInvoke(() => {
                    statusLabel.Text = "开始拷贝...";
                });

                if (filesToCopy.Count == 0)
                {
                    basicStatus.IsCopying = false;
                    basicStatus.EndTime = DateTime.Now;
                    basicStatus.Status = "未找到文件";

                    SafeInvoke(() => {
                        statusLabel.Text = "未找到符合条件的文件";
                        statusLabel.ForeColor = Color.Orange;
                    });
                    return;
                }

                basicStatus.Status = "拷贝文件";

                // 空间检测
                long requiredSpace = (long)(totalBytesToCopy * 1.2);
                string copyDriveRoot = Path.GetPathRoot(copyPath);
                DriveInfo copyDrive = new DriveInfo(copyDriveRoot);
                if (copyDrive.AvailableFreeSpace < requiredSpace)
                {
                    string errorMsg = $"目标驱动器空间不足！\n\n需要空间: {FormatFileSize(requiredSpace)}\n可用空间: {FormatFileSize(copyDrive.AvailableFreeSpace)}";
                    basicStatus.Status = "空间不足";

                    // 使用同步方式显示空间不足警告
                    if (this.InvokeRequired)
                    {
                        this.Invoke(new Action(() =>
                        {
                            MessageBox.Show(this, errorMsg, "空间不足警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }));
                    }
                    else
                    {
                        MessageBox.Show(this, errorMsg, "空间不足警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

                    // 恢复UI状态
                    SafeInvoke(() => {
                        Button startButton = fixedControlPanel.Controls.Find("startButton", false).FirstOrDefault() as Button;
                        if (startButton != null)
                        {
                            startButton.Text = "🚀 开始拷贝";
                            startButton.BackColor = Color.LightBlue;
                        }

                        statusLabel.Text = "空间不足，拷贝中止";
                        statusLabel.ForeColor = Color.Red;
                    });

                    isCopying = false;
                    return;
                }

                // 创建主文件夹
                string mainFolderName = prefix;
                string mainCopyPath = Path.Combine(copyPath, mainFolderName);
                string mainBackupPath = backupEnabled ? Path.Combine(backupPath, mainFolderName) : null;

                // 处理文件夹重名
                int counter = 1;
                string originalMainCopyPath = mainCopyPath;
                while (Directory.Exists(mainCopyPath))
                {
                    mainFolderName = $"{prefix}_{counter}";
                    mainCopyPath = Path.Combine(copyPath, mainFolderName);
                    mainBackupPath = backupEnabled ? Path.Combine(backupPath, mainFolderName) : null;
                    counter++;
                }

                // 创建子文件夹
                await Task.Run(() =>
                {
                    if (copyPhotos)
                    {
                        string photosFolder = Path.Combine(mainCopyPath, "照片");
                        string photosBackupFolder = backupEnabled ? Path.Combine(mainBackupPath, "照片") : null;
                        Directory.CreateDirectory(photosFolder);
                        if (backupEnabled) Directory.CreateDirectory(photosBackupFolder);
                    }

                    if (copyVideos)
                    {
                        string videosFolder = Path.Combine(mainCopyPath, "视频");
                        string videosBackupFolder = backupEnabled ? Path.Combine(mainBackupPath, "视频") : null;
                        Directory.CreateDirectory(videosFolder);
                        if (backupEnabled) Directory.CreateDirectory(videosBackupFolder);
                    }
                });

                // 重置拷贝统计
                totalCopiedBytes = 0;
                lastReportedBytes = 0;

                // 开始拷贝前更新数据量显示
                UpdateDataAmountDisplay();

                // 启动速度更新定时器
                if (speedUpdateTimer != null)
                {
                    SafeInvoke(() => {
                        speedUpdateTimer.Stop();
                        speedUpdateTimer.Start();
                    });
                }

                int copiedCount = 0;
                int backupCount = 0;
                int skippedCount = 0;
                int errorCount = 0;
                int actualPhotoCount = 0;
                int actualVideoCount = 0;

                // 记录文件时间范围
                DateTime? earliestDate = null;
                DateTime? latestDate = null;

                // 使用异步方式拷贝文件
                await Task.Run(async () =>
                {
                    int fileIndex = 0;
                    foreach (string sourceFile in filesToCopy)
                    {
                        fileIndex++;

                        if (cancellationToken.IsCancellationRequested)
                        {
                            basicStatus.Status = "拷贝已取消";
                            basicStatus.IsCopying = false;
                            basicStatus.EndTime = DateTime.Now;

                            SafeInvoke(() => {
                                statusLabel.Text = "拷贝已取消";
                                statusLabel.ForeColor = Color.Orange;
                            });
                            break;
                        }

                        try
                        {
                            string fileName = Path.GetFileName(sourceFile);
                            string extension = Path.GetExtension(sourceFile).ToLowerInvariant();

                            // 更新基本状态信息
                            basicStatus.CurrentFile = fileName;
                            basicStatus.ProcessedFiles = fileIndex;
                            basicStatus.Status = "📤 拷贝中...";

                            // 获取文件大小
                            long fileSize = 0;
                            try
                            {
                                FileInfo sourceFileInfo = new FileInfo(sourceFile);
                                fileSize = sourceFileInfo.Length;
                            }
                            catch
                            {
                                fileSize = 0;
                            }

                            // 更新状态标签
                            if (fileIndex % 5 == 0 || fileIndex == filesToCopy.Count)
                            {
                                SafeInvoke(() => {
                                    string displayName = fileName;
                                    if (displayName.Length > 20)
                                    {
                                        displayName = displayName.Substring(0, 17) + "...";
                                    }
                                    statusLabel.Text = $"正在拷贝文件 ({fileIndex}/{filesToCopy.Count}) - {displayName}";
                                });
                            }

                            // 获取文件时间信息
                            DateTime? mediaTime = GetMediaFileTime(sourceFile, extension);
                            if (mediaTime.HasValue)
                            {
                                if (!earliestDate.HasValue || mediaTime.Value < earliestDate.Value)
                                    earliestDate = mediaTime.Value;
                                if (!latestDate.HasValue || mediaTime.Value > latestDate.Value)
                                    latestDate = mediaTime.Value;
                            }

                            // 确定文件类型和目标文件夹
                            bool isPhoto = PhotoExtensions.Contains(extension);
                            string targetFolder = isPhoto ? Path.Combine(mainCopyPath, "照片") : Path.Combine(mainCopyPath, "视频");
                            string backupFolder = backupEnabled ? (isPhoto ? Path.Combine(mainBackupPath, "照片") : Path.Combine(mainBackupPath, "视频")) : null;

                            // 生成目标文件名
                            string newFileName = GenerateNewFileName(fileName, prefix, useTimestamp, true);
                            string destFile = Path.Combine(targetFolder, newFileName);

                            // 使用异步拷贝文件
                            bool copySuccess = await CopySingleFileWithProgressAsync(sourceFile, destFile, true, fileSize, cancellationToken, true);

                            if (copySuccess)
                            {
                                copiedCount++;
                                if (PhotoExtensions.Contains(extension)) actualPhotoCount++;
                                else if (VideoExtensions.Contains(extension)) actualVideoCount++;

                                // 如果启用备份，拷贝到备份位置
                                if (backupEnabled && !string.IsNullOrWhiteSpace(backupFolder))
                                {
                                    string backupFile = Path.Combine(backupFolder, newFileName);
                                    bool backupSuccess = await CopySingleFileWithProgressAsync(sourceFile, backupFile, false, fileSize, cancellationToken, false);

                                    if (backupSuccess)
                                    {
                                        backupCount++;
                                    }
                                }
                            }
                            else
                            {
                                skippedCount++;
                            }
                        }
                        catch (Exception ex)
                        {
                            errorCount++;
                            Console.WriteLine($"拷贝文件 {sourceFile} 时出错: {ex.Message}");
                        }
                    }
                });

                // 停止速度更新定时器
                if (speedUpdateTimer != null)
                {
                    SafeInvoke(() => speedUpdateTimer.Stop());
                }

                // 确保数据量显示为100%
                totalCopiedBytes = totalBytesToCopy;
                UpdateDataAmountDisplay();

                // 计算最终统计数据
                TimeSpan totalTime = DateTime.Now - speedUpdateStartTime;
                double averageSpeed = totalTime.TotalSeconds > 0 ? speedUpdateTotalBytes / totalTime.TotalSeconds : 0;

                // 显示最终结果
                string resultMessage = $"拷贝完成!\n\n" +
                                      $"成功拷贝: {copiedCount} 个文件\n" +
                                      $"照片: {actualPhotoCount} 个\n" +
                                      $"视频: {actualVideoCount} 个\n" +
                                      $"跳过: {skippedCount} 个\n" +
                                      $"错误: {errorCount} 个\n" +
                                      $"备份: {backupCount} 个\n" +
                                      $"总数据量: {FormatFileSize(speedUpdateTotalBytes)}\n" +
                                      $"总用时: {FormatTimeSpan(totalTime)}\n" +
                                      $"平均速度: {FormatSpeed(averageSpeed)}";

                // 添加时间范围信息
                if (earliestDate.HasValue && latestDate.HasValue)
                {
                    resultMessage += $"\n\n文件时间范围: {earliestDate.Value:yyyy-MM-dd} 到 {latestDate.Value:yyyy-MM-dd}";
                }

                // 完成状态
                basicStatus.IsCopying = false;
                basicStatus.EndTime = DateTime.Now;
                basicStatus.Status = "💤 就绪";
                basicStatus.ProcessedFiles = basicStatus.TotalFiles;
                basicStatus.CurrentFile = "";

                SafeInvoke(() => {
                    statusLabel.Text = "拷贝完成";
                    statusLabel.ForeColor = errorCount > 0 ? Color.Orange : Color.Green;
                    if (speedLabel != null)
                    {
                        speedLabel.Text = $"平均速度: {FormatSpeed(averageSpeed)}";
                        speedLabel.ForeColor = Color.DarkBlue;
                    }

                    // 播放完成提示音
                    System.Media.SystemSounds.Exclamation.Play();

                    // 显示文件夹位置信息
                    string folderInfo = $"文件已保存到:\n{mainCopyPath}";
                    if (backupEnabled)
                    {
                        folderInfo += $"\n\n备份位置:\n{mainBackupPath}";
                    }

                    // 使用同步方式显示完成消息框
                    if (this.InvokeRequired)
                    {
                        this.Invoke(new Action(() =>
                        {
                            MessageBox.Show(this,
                                $"{resultMessage}\n\n{folderInfo}",
                                "拷贝完成",
                                MessageBoxButtons.OK,
                                (errorCount > 0) ? MessageBoxIcon.Warning : MessageBoxIcon.Information);
                        }));
                    }
                    else
                    {
                        MessageBox.Show(this,
                            $"{resultMessage}\n\n{folderInfo}",
                            "拷贝完成",
                            MessageBoxButtons.OK,
                            (errorCount > 0) ? MessageBoxIcon.Warning : MessageBoxIcon.Information);
                    }
                });
            }
            catch (Exception ex)
            {
                basicStatus.IsCopying = false;
                basicStatus.EndTime = DateTime.Now;
                basicStatus.Status = $"失败: {ex.Message}";

                SafeInvoke(() => {
                    // 播放错误提示音
                    System.Media.SystemSounds.Hand.Play();

                    statusLabel.Text = $"拷贝失败: {ex.Message}";
                    statusLabel.ForeColor = Color.Red;
                });
                throw;
            }
        }

        /// <summary>
        /// 计算文件统计信息
        /// </summary>
        private async Task<(int PhotoCount, int VideoCount, long PhotoSize, long VideoSize, long TotalSize)> CalculateFileStatistics(List<string> files)
        {
            int photoCount = 0;
            int videoCount = 0;
            long photoSize = 0;
            long videoSize = 0;
            long totalSize = 0;

            await Task.Run(() =>
            {
                foreach (string file in files)
                {
                    try
                    {
                        FileInfo currentFileInfo = new FileInfo(file);
                        long fileSize = currentFileInfo.Length;
                        totalSize += fileSize;

                        string extension = Path.GetExtension(file).ToLowerInvariant();
                        if (PhotoExtensions.Contains(extension))
                        {
                            photoCount++;
                            photoSize += fileSize;
                        }
                        else if (VideoExtensions.Contains(extension))
                        {
                            videoCount++;
                            videoSize += fileSize;
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"计算文件统计信息失败 {file}: {ex.Message}");
                    }
                }
            });

            return (photoCount, videoCount, photoSize, videoSize, totalSize);
        }

        /// <summary>
        /// 异步拷贝单个文件（修复版本）
        /// </summary>
        private async Task<bool> CopySingleFileWithProgressAsync(string sourceFile, string destFile,
            bool handleDuplicate, long fileSize, CancellationToken cancellationToken, bool updateTotalCopiedBytes = true)
        {
            try
            {
                if (File.Exists(destFile))
                {
                    if (!handleDuplicate)
                        return false;

                    string directory = Path.GetDirectoryName(destFile);
                    string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(destFile);
                    string extension = Path.GetExtension(destFile);

                    int counter = 1;
                    string newDestFile;
                    do
                    {
                        newDestFile = Path.Combine(directory, $"{fileNameWithoutExtension}_{counter}{extension}");
                        counter++;
                    } while (File.Exists(newDestFile) && counter < 1000);

                    destFile = newDestFile;
                }

                string destDirectory = Path.GetDirectoryName(destFile);
                if (!Directory.Exists(destDirectory))
                {
                    Directory.CreateDirectory(destDirectory);
                }

                // 使用带进度报告的异步拷贝
                const int bufferSize = 81920; // 80KB缓冲区
                byte[] buffer = new byte[bufferSize];
                int bytesRead;
                long totalBytesRead = 0;
                DateTime lastUpdateTime = DateTime.Now;

                using (FileStream sourceStream = new FileStream(sourceFile, FileMode.Open, FileAccess.Read, FileShare.Read, bufferSize, FileOptions.Asynchronous))
                using (FileStream destStream = new FileStream(destFile, FileMode.Create, FileAccess.Write, FileShare.None, bufferSize, FileOptions.Asynchronous))
                {
                    while ((bytesRead = await sourceStream.ReadAsync(buffer, 0, buffer.Length, cancellationToken)) > 0)
                    {
                        if (cancellationToken.IsCancellationRequested)
                        {
                            return false;
                        }

                        await destStream.WriteAsync(buffer, 0, bytesRead, cancellationToken);
                        totalBytesRead += bytesRead;

                        // 更新速度计算的总字节数（包括备份）
                        Interlocked.Add(ref speedUpdateTotalBytes, bytesRead);

                        // 更新总拷贝字节数（仅主拷贝，不包括备份）
                        if (updateTotalCopiedBytes)
                        {
                            Interlocked.Add(ref totalCopiedBytes, bytesRead);
                        }

                        // 定期更新UI（避免更新太频繁）
                        if (DateTime.Now - lastUpdateTime > TimeSpan.FromMilliseconds(100) ||
                            totalBytesRead == fileSize)
                        {
                            lastUpdateTime = DateTime.Now;
                        }
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"拷贝文件 {sourceFile} 到 {destFile} 失败: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// 开始拷贝按钮点击事件
        /// </summary>
        private void StartCopy_Click(object sender, EventArgs e)
        {
            if (isCopying && cancellationTokenSource != null)
            {
                cancellationTokenSource.Cancel();
                return;
            }

            if (selectedDrive == null)
            {
                MessageBox.Show(this, "请先选择存储器", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 获取用户设置
            DateTime copyDate = GetCopyDate();
            bool copyPhotos = GetPhotoCheckValue();
            bool copyVideos = GetVideoCheckValue();
            string copyPath = GetCopyPathValue();
            bool backupEnabled = GetBackupCheckValue();
            string backupPath = GetBackupPathValue();
            string prefix = GetPrefixValue();
            bool useTimestamp = GetTimestampCheckValue();

            // 验证设置
            if (string.IsNullOrWhiteSpace(prefix))
            {
                MessageBox.Show(this, "文件前缀不能为空", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!Directory.Exists(copyPath))
            {
                try
                {
                    Directory.CreateDirectory(copyPath);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, $"无法创建目标目录: {ex.Message}", "错误",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            if (backupEnabled && !Directory.Exists(backupPath))
            {
                try
                {
                    Directory.CreateDirectory(backupPath);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, $"无法创建备份目录: {ex.Message}", "错误",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            // 开始拷贝
            StartCopyProcess(copyDate, copyPhotos, copyVideos, copyPath,
                           backupEnabled, backupPath, prefix, useTimestamp);
        }

        /// <summary>
        /// 获取要拷贝的文件列表 - 按媒体文件内部时间搜索，选择起始日期及之后的所有文件
        /// </summary>
        private List<string> GetFilesToCopy(DateTime copyDate, bool copyPhotos, bool copyVideos,
                                          CancellationToken cancellationToken)
        {
            List<string> filesToCopy = new List<string>();
            List<string> extensions = new List<string>();

            if (copyPhotos) extensions.AddRange(PhotoExtensions);
            if (copyVideos) extensions.AddRange(VideoExtensions);

            if (extensions.Count == 0)
            {
                MessageBox.Show(this, "请至少选择一种文件类型（照片或视频）", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return filesToCopy;
            }

            try
            {
                // 常见媒体文件夹
                string[] searchFolders = {
                    "DCIM", "Photos", "Pictures", "Images",
                    "Video", "Videos", "Movies", "MP_ROOT",
                    "PRIVATE", "AVCHD", "Camera"
                };

                // 搜索所有可能的文件夹
                foreach (string folder in searchFolders)
                {
                    if (cancellationToken.IsCancellationRequested)
                        break;

                    string folderPath = Path.Combine(selectedDrive.RootDirectory.FullName, folder);
                    if (Directory.Exists(folderPath))
                    {
                        SearchFilesInDirectory(folderPath, extensions, copyDate, filesToCopy, cancellationToken);
                    }
                }

                // 如果还没有找到文件，搜索整个驱动器
                if (filesToCopy.Count == 0)
                {
                    SearchFilesInDirectory(selectedDrive.RootDirectory.FullName, extensions, copyDate, filesToCopy, cancellationToken);
                }

                // 按文件类型和文件名排序
                filesToCopy.Sort((a, b) =>
                {
                    string extA = Path.GetExtension(a).ToLowerInvariant();
                    string extB = Path.GetExtension(b).ToLowerInvariant();

                    bool isPhotoA = PhotoExtensions.Contains(extA);
                    bool isPhotoB = PhotoExtensions.Contains(extB);

                    if (isPhotoA && !isPhotoB) return -1;
                    if (!isPhotoA && isPhotoB) return 1;
                    return string.Compare(a, b, StringComparison.Ordinal);
                });

            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"搜索文件时出错: {ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return filesToCopy;
        }

        /// <summary>
        /// 在指定目录中搜索文件 - 按媒体文件内部时间搜索，选择起始日期及之后的所有文件
        /// </summary>
        private void SearchFilesInDirectory(string directory, List<string> extensions, DateTime copyDate,
                                          List<string> filesToCopy, CancellationToken cancellationToken, bool searchSubdirectories = true)
        {
            try
            {
                SearchOption searchOption = searchSubdirectories ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;

                foreach (string file in Directory.EnumerateFiles(directory, "*.*", searchOption))
                {
                    if (cancellationToken.IsCancellationRequested)
                        break;

                    try
                    {
                        string extension = Path.GetExtension(file).ToLowerInvariant();

                        // 跳过没有扩展名的文件
                        if (string.IsNullOrEmpty(extension))
                            continue;

                        // 检查文件类型
                        if (extensions.Contains(extension))
                        {
                            // 获取媒体文件的内部时间（拍摄时间）
                            DateTime? mediaTime = GetMediaFileTime(file, extension);

                            if (mediaTime.HasValue)
                            {
                                // 检查媒体文件的拍摄日期是否在起始日期及之后
                                if (mediaTime.Value.Date >= copyDate.Date)
                                {
                                    // 验证文件确实是有效的媒体文件
                                    if (IsValidMediaFile(file))
                                    {
                                        filesToCopy.Add(file);
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception)
                    {
                        // 跳过无法访问的文件，但继续搜索其他文件
                        continue;
                    }
                }
            }
            catch (Exception)
            {
                // 忽略目录访问错误，继续搜索其他目录
            }
        }

        /// <summary>
        /// 获取媒体文件的内部时间（拍摄时间）
        /// </summary>
        private DateTime? GetMediaFileTime(string filePath, string extension)
        {
            try
            {
                // 根据文件类型使用不同的方法获取内部时间
                if (PhotoExtensions.Contains(extension))
                {
                    return GetPhotoTakenTime(filePath);
                }
                else if (VideoExtensions.Contains(extension))
                {
                    return GetVideoCreationTime(filePath);
                }
            }
            catch (Exception ex)
            {
                // 如果获取内部时间失败，回退到文件创建时间
                Console.WriteLine($"获取媒体文件内部时间失败 {filePath}: {ex.Message}");
            }

            // 如果无法获取内部时间，使用文件创建时间作为备用
            try
            {
                return File.GetCreationTime(filePath);
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// 获取照片的拍摄时间（从EXIF数据）
        /// </summary>
        private DateTime? GetPhotoTakenTime(string filePath)
        {
            try
            {
                using (var fs = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                using (var image = Image.FromStream(fs, false, false))
                {
                    // 使用更安全的属性获取方式
                    int[] timePropertyIds = { 0x9003, 0x9004, 0x0132 };

                    foreach (int propertyId in timePropertyIds)
                    {
                        try
                        {
                            var propItem = image.GetPropertyItem(propertyId);
                            if (propItem != null)
                            {
                                string dateTaken = Encoding.UTF8.GetString(propItem.Value).Trim('\0');
                                if (DateTime.TryParseExact(dateTaken, "yyyy:MM:dd HH:mm:ss", null,
                                    System.Globalization.DateTimeStyles.None, out DateTime result))
                                {
                                    return result;
                                }
                            }
                        }
                        catch (ArgumentException)
                        {
                            continue;
                        }
                    }
                    return null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"读取照片EXIF数据失败 {filePath}: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// 获取视频的创建时间（从文件元数据）
        /// </summary>
        private DateTime? GetVideoCreationTime(string filePath)
        {
            try
            {
                // 对于视频文件，我们首先尝试获取媒体创建时间
                return GetVideoMediaCreationTime(filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"读取视频元数据失败 {filePath}: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// 获取视频媒体的创建时间（使用Windows Shell）
        /// </summary>
        private DateTime? GetVideoMediaCreationTime(string filePath)
        {
            try
            {
                // 使用FileInfo获取基本的文件时间信息
                FileInfo videoFileInfo = new FileInfo(filePath);

                // 优先使用文件的创建时间，对于视频文件这通常是录制时间
                return videoFileInfo.CreationTime;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// 验证文件是否为有效的媒体文件
        /// </summary>
        private bool IsValidMediaFile(string filePath)
        {
            try
            {
                FileInfo mediaFileInfo = new FileInfo(filePath);

                // 跳过过小的文件（可能不是真正的媒体文件）
                if (mediaFileInfo.Length < 10 * 1024) // 小于10KB
                {
                    return false;
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 生成新的文件名
        /// </summary>
        private string GenerateNewFileName(string originalName, string prefix, bool useTimestamp, bool dateOnly = false)
        {
            string extension = Path.GetExtension(originalName);
            string nameWithoutExtension = Path.GetFileNameWithoutExtension(originalName);

            // 使用本地时间
            DateTime currentTime = DateTime.Now;

            string timestamp;
            if (dateOnly)
            {
                // 只使用日期部分，不包含时间
                timestamp = currentTime.ToString("yyyyMMdd");
            }
            else
            {
                timestamp = useTimestamp ? currentTime.ToString("yyyyMMdd_HHmmss") : "";
            }

            string separator = useTimestamp ? "_" : "";

            // 构建新文件名
            string baseName;
            if (useTimestamp)
            {
                baseName = $"{prefix}{separator}{timestamp}_{nameWithoutExtension}";
            }
            else
            {
                baseName = $"{prefix}_{nameWithoutExtension}";
            }

            // 清理文件名中的非法字符
            baseName = CleanFileName(baseName);

            // 确保文件名长度不超过系统限制
            if (baseName.Length > 200)
            {
                baseName = baseName.Substring(0, 200);
            }

            return baseName + extension;
        }

        /// <summary>
        /// 清理文件名中的非法字符
        /// </summary>
        private string CleanFileName(string fileName)
        {
            char[] invalidChars = Path.GetInvalidFileNameChars();
            foreach (char c in invalidChars)
            {
                fileName = fileName.Replace(c, '_');
            }
            return fileName;
        }

        /// <summary>
        /// 开始拷贝过程
        /// </summary>
        private async void StartCopyProcess(DateTime copyDate, bool copyPhotos, bool copyVideos,
                                        string copyPath, bool backupEnabled, string backupPath,
                                        string prefix, bool useTimestamp)
        {
            if (selectedDrive == null || !selectedDrive.IsReady)
            {
                MessageBox.Show(this, "选择的存储器不可用或已断开连接", "错误",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                ProgressBar progressBar = fixedControlPanel.Controls.Find("progressBar", false).FirstOrDefault() as ProgressBar;
                Label statusLabel = fixedControlPanel.Controls.Find("statusLabel", false).FirstOrDefault() as Label;
                Label speedLabel = fixedControlPanel.Controls.Find("speedLabel", false).FirstOrDefault() as Label;
                Button startButton = fixedControlPanel.Controls.Find("startButton", false).FirstOrDefault() as Button;
                Label dataAmountLabel = fixedControlPanel.Controls.Find("dataAmountLabel", false).FirstOrDefault() as Label;

                if (progressBar == null || statusLabel == null || startButton == null)
                {
                    MessageBox.Show(this, "无法访问界面控件", "错误",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                isCopying = true;
                cancellationTokenSource = new CancellationTokenSource();
                startButton.Text = "🛑 停止拷贝";
                startButton.BackColor = Color.LightCoral;

                // 重置进度条和数据量显示
                SafeInvoke(() => {
                    progressBar.Value = 0;
                    if (dataAmountLabel != null)
                    {
                        dataAmountLabel.Text = "0 B / 0 B";
                    }
                });

                SafeInvoke(() => {
                    statusLabel.Text = "正在搜索文件...";
                    statusLabel.ForeColor = Color.DarkBlue;
                    if (speedLabel != null)
                    {
                        speedLabel.Text = "速度: --";
                        speedLabel.ForeColor = Color.DarkGreen;
                    }
                });

                // 拷贝方法 - 使用 await 来等待异步操作
                try
                {
                    await Task.Run(async () =>
                    {
                        try
                        {
                            await PerformFileCopy(copyDate, copyPhotos, copyVideos, copyPath,
                                                      backupEnabled, backupPath, prefix, useTimestamp,
                                                      statusLabel, cancellationTokenSource.Token);
                        }
                        catch (OperationCanceledException)
                        {
                            SafeInvoke(() => {
                                statusLabel.Text = "拷贝已取消";
                                statusLabel.ForeColor = Color.Orange;
                            });
                        }
                        catch (Exception ex)
                        {
                            SafeInvoke(() => {
                                statusLabel.Text = $"拷贝失败: {ex.Message}";
                                statusLabel.ForeColor = Color.Red;
                            });
                        }
                    });
                }
                finally
                {
                    SafeInvoke(() =>
                    {
                        isCopying = false;
                        startButton.Text = "🚀 开始拷贝";
                        startButton.BackColor = Color.LightBlue;

                        // 停止速度更新定时器
                        if (speedUpdateTimer != null)
                        {
                            speedUpdateTimer.Stop();
                        }
                    });
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"启动拷贝过程时出错: {ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 窗体关闭事件
        /// </summary>
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            // 停止全局状态监控计时器
            if (globalStatusTimer != null)
            {
                globalStatusTimer.Stop();
                globalStatusTimer.Dispose();
            }

            // 停止速度更新定时器
            if (speedUpdateTimer != null)
            {
                speedUpdateTimer.Stop();
                speedUpdateTimer.Dispose();
            }

            // 停止设备监控（新增）
            if (deviceInsertWatcher != null)
            {
                deviceInsertWatcher.Stop();
                deviceInsertWatcher.Dispose();
            }

            if (deviceRemoveWatcher != null)
            {
                deviceRemoveWatcher.Stop();
                deviceRemoveWatcher.Dispose();
            }

            if (isCopying && cancellationTokenSource != null)
            {
                cancellationTokenSource.Cancel();
                Thread.Sleep(500);
            }
            base.OnFormClosing(e);
        }

        /// <summary>
        /// 获取拷贝日期
        /// </summary>
        private DateTime GetCopyDate()
        {
            if (fixedControlPanel != null)
            {
                var timePicker = fixedControlPanel.Controls.OfType<DateTimePicker>().FirstOrDefault();
                if (timePicker != null)
                {
                    return timePicker.Value.Date;
                }
            }
            return DateTime.Now.Date;
        }

        /// <summary>
        /// 获取照片复选框值
        /// </summary>
        private bool GetPhotoCheckValue()
        {
            if (fixedControlPanel != null)
            {
                var photoCheck = fixedControlPanel.Controls.OfType<CheckBox>()
                    .FirstOrDefault(c => c.Text.Contains("照片"));
                return photoCheck?.Checked ?? true;
            }
            return true;
        }

        /// <summary>
        /// 获取视频复选框值
        /// </summary>
        private bool GetVideoCheckValue()
        {
            if (fixedControlPanel != null)
            {
                var videoCheck = fixedControlPanel.Controls.OfType<CheckBox>()
                    .FirstOrDefault(c => c.Text.Contains("视频"));
                return videoCheck?.Checked ?? true;
            }
            return true;
        }

        /// <summary>
        /// 获取拷贝路径值
        /// </summary>
        private string GetCopyPathValue()
        {
            if (fixedControlPanel != null)
            {
                var copyPathText = fixedControlPanel.Controls.OfType<TextBox>()
                    .FirstOrDefault(t => t.Name == "copyPathText");
                return copyPathText?.Text ?? GetDefaultCopyPath();
            }
            return GetDefaultCopyPath();
        }

        /// <summary>
        /// 获取备份复选框值
        /// </summary>
        private bool GetBackupCheckValue()
        {
            if (fixedControlPanel != null)
            {
                var backupCheck = fixedControlPanel.Controls.OfType<CheckBox>()
                    .FirstOrDefault(c => c.Name == "backupCheck");
                return backupCheck?.Checked ?? false;
            }
            return false;
        }

        /// <summary>
        /// 获取备份路径值
        /// </summary>
        private string GetBackupPathValue()
        {
            if (fixedControlPanel != null)
            {
                var backupPathText = fixedControlPanel.Controls.OfType<TextBox>()
                    .FirstOrDefault(t => t.Name == "backupPathText");
                return backupPathText?.Text ?? "";
            }
            return "";
        }

        /// <summary>
        /// 获取前缀值
        /// </summary>
        private string GetPrefixValue()
        {
            if (fixedControlPanel != null)
            {
                var prefixText = fixedControlPanel.Controls.OfType<TextBox>()
                    .FirstOrDefault(t => t.Name == "prefixText");
                return prefixText?.Text ?? "Backup";
            }
            return "Backup";
        }

        /// <summary>
        /// 获取时间戳复选框值
        /// </summary>
        private bool GetTimestampCheckValue()
        {
            if (fixedControlPanel != null)
            {
                var timestampCheck = fixedControlPanel.Controls.OfType<CheckBox>()
                    .FirstOrDefault(c => c.Name == "timestampCheck");
                return timestampCheck?.Checked ?? true;
            }
            return true;
        }
        #endregion

        #region 自动更新方法

        /// <summary>
        /// 检查更新
        /// </summary>
        private async Task CheckForUpdatesAsync()
        {
            try
            {
                // 禁用更新按钮
                ToolStripMenuItem updateItem = GetUpdateMenuItem();
                if (updateItem != null)
                {
                    updateItem.Enabled = false;
                    updateItem.Text = "检查中...";
                }

                // 更新状态
                Label statusLabel = fixedControlPanel?.Controls.Find("statusLabel", false).FirstOrDefault() as Label;
                if (statusLabel != null)
                {
                    statusLabel.Text = "正在检查更新...";
                    statusLabel.ForeColor = Color.DarkBlue;
                }

                // 检查更新
                AutoUpdater updater = new AutoUpdater();
                var updateInfo = updater.CheckForUpdates();

                if (updateInfo == null)
                {
                    MessageBox.Show(this,
                        "无法检查更新，可能原因：\n" +
                        "1. 网络连接异常\n" +
                        "2. 更新服务器不可用\n" +
                        "3. 请检查配置文件\n\n" +
                        "请确认已正确配置GitHub/Gitee仓库信息。",
                        "更新检查失败",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
                else if (updateInfo.IsUpdateAvailable)
                {
                    // 显示更新确认
                    string message = $"✨ 发现新版本 v{updateInfo.LatestVersion}！\n\n" +
                                    $"当前版本: v{AutoUpdater.CurrentVersion}\n" +
                                    $"更新源: {updateInfo.Source}\n" +
                                    $"发布日期: {updateInfo.ReleaseDate:yyyy-MM-dd}\n" +
                                    $"更新后文件名: {AutoUpdater.GenerateNewFileName(updateInfo.LatestVersion)}\n\n" +
                                    $"更新说明:\n{TruncateText(updateInfo.ReleaseNotes, 300)}\n\n" +
                                    $"是否立即下载并更新？";

                    DialogResult result = MessageBox.Show(this, message,
                        "发现新版本",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Information);

                    if (result == DialogResult.Yes)
                    {
                        // 开始下载更新
                        await DownloadAndInstallUpdate(updater, updateInfo);
                    }
                }
                else
                {
                    MessageBox.Show(this,
                        $"✅ 当前已是最新版本！\n\n" +
                        $"当前版本: v{AutoUpdater.CurrentVersion}\n" +
                        $"最新版本: v{updateInfo.LatestVersion}\n" +
                        $"更新源: {updateInfo.Source}",
                        "更新检查",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this,
                    $"检查更新时出错:\n{ex.Message}",
                    "错误",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            finally
            {
                // 恢复按钮状态
                ToolStripMenuItem updateItem = GetUpdateMenuItem();
                if (updateItem != null)
                {
                    updateItem.Text = "检查更新";
                    updateItem.Enabled = true;
                }

                // 恢复状态标签
                Label statusLabel = fixedControlPanel?.Controls.Find("statusLabel", false).FirstOrDefault() as Label;
                if (statusLabel != null)
                {
                    statusLabel.Text = "准备就绪";
                    statusLabel.ForeColor = Color.DarkBlue;
                }
            }
        }

        /// <summary>
        /// 下载并安装更新
        /// </summary>
        private async Task DownloadAndInstallUpdate(AutoUpdater updater, AutoUpdater.UpdateInfo updateInfo)
        {
            // 创建进度窗口
            DownloadProgressForm progressForm = new DownloadProgressForm(updateInfo.Source, updateInfo.LatestVersion.ToString());
            progressForm.Show();

            bool success = false;

            try
            {
                // 使用Task.Run在后台下载
                success = await Task.Run(() =>
                {
                    try
                    {
                        return updater.DownloadAndUpdate(updateInfo.DownloadUrl, updateInfo.LatestVersion,
                            (percent) =>
                            {
                                progressForm.UpdateProgress(percent);
                            });
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"下载失败: {ex.Message}");
                        return false;
                    }
                });
            }
            finally
            {
                progressForm.Close();
            }

            if (success)
            {
                // 显示成功消息
                MessageBox.Show(this,
                    "✅ 更新下载完成！\n\n" +
                    $"新版本已保存为: {AutoUpdater.GenerateNewFileName(updateInfo.LatestVersion)}\n" +
                    "程序将自动重启以完成更新...\n\n" +
                    "更新过程：\n" +
                    "1. 程序自动关闭\n" +
                    "2. 删除旧版本\n" +
                    "3. 安装新版本\n" +
                    "4. 启动新版本",
                    "更新完成",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                // 等待一会儿让用户看到消息
                await Task.Delay(2000);

                // 退出程序，让更新脚本继续工作
                Application.Exit();
            }
            else
            {
                MessageBox.Show(this,
                    "下载更新失败，请检查网络连接后重试\n\n" +
                    "如果多次失败，请尝试手动更新。",
                    "下载失败",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 截断文本
        /// </summary>
        private string TruncateText(string text, int maxLength)
        {
            if (string.IsNullOrEmpty(text)) return "无更新说明";
            if (text.Length <= maxLength) return text;
            return text.Substring(0, maxLength) + "...";
        }

        /// <summary>
        /// 获取更新菜单项
        /// </summary>
        private ToolStripMenuItem GetUpdateMenuItem()
        {
            if (topMenuStrip == null) return null;

            foreach (ToolStripItem item in topMenuStrip.Items)
            {
                if (item is ToolStripMenuItem menuItem && menuItem.Text == "帮助")
                {
                    foreach (ToolStripItem subItem in menuItem.DropDownItems)
                    {
                        if (subItem is ToolStripMenuItem subMenuItem &&
                            (subMenuItem.Text == "检查更新" || subMenuItem.Text == "检查中..."))
                        {
                            return subMenuItem;
                        }
                    }
                }
            }

            return null;
        }

        /// <summary>
        /// 启动时检查更新
        /// </summary>
        private async Task CheckForUpdatesOnStartup()
        {
            // 等待程序完全启动
            await Task.Delay(2500);

            try
            {
                Console.WriteLine("启动时检查更新...");

                // 检查更新
                AutoUpdater updater = new AutoUpdater();
                var updateInfo = updater.CheckForUpdates();

                if (updateInfo?.IsUpdateAvailable == true)
                {
                    // 在UI线程显示提示
                    SafeInvoke(() =>
                    {
                        DialogResult result = MessageBox.Show(this,
                            $"发现新版本 v{updateInfo.LatestVersion}！\n\n" +
                            $"更新源: {updateInfo.Source}\n" +
                            $"更新后文件名: {AutoUpdater.GenerateNewFileName(updateInfo.LatestVersion)}\n\n" +
                            $"更新说明:\n{TruncateText(updateInfo.ReleaseNotes, 300)}\n\n" +
                            $"是否现在下载并更新？",
                            "发现新版本",
                            MessageBoxButtons.YesNo,
                            MessageBoxIcon.Question);

                        if (result == DialogResult.Yes)
                        {
                            _ = DownloadAndInstallUpdate(updater, updateInfo);
                        }
                    });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"启动时检查更新失败: {ex.Message}");
                // 静默失败，不影响主程序
            }
        }

        #endregion

        #region ffmpeg
        /// <summary>
        /// 测试FFmpeg完整性
        /// </summary>
        private void TestFFmpegIntegrity()
        {
            try
            {
                FFmpegManager ffmpegManager = new FFmpegManager();
                bool isComplete = ffmpegManager.CheckFFmpegIntegrity();

                if (isComplete)
                {
                    MessageBox.Show(this,
                        "✅ FFmpeg组件完整\n\n" +
                        "所有必要组件都已正确安装。",
                        "完整性测试通过",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show(this,
                        "⚠️ FFmpeg组件不完整\n\n" +
                        "检测到部分组件缺失或损坏。\n" +
                        "请在资源管理中下载或修复组件。",
                        "完整性测试失败",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this,
                    $"测试FFmpeg完整性时出错：\n{ex.Message}",
                    "错误",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 显示FFmpeg管理器
        /// </summary>
        private void ShowFFmpegManager()
        {
            FFmpegManagerForm ffmpegManagerForm = new FFmpegManagerForm();
            ffmpegManagerForm.Show();
        }


        /// <summary>
        /// 启动时检查FFmpeg
        /// </summary>
        private async Task CheckFFmpegOnStartup()
        {
            try
            {
                // 等待主窗体完全加载
                await Task.Delay(3000);

                FFmpegManager ffmpegManager = new FFmpegManager();
                bool isComplete = ffmpegManager.CheckFFmpegIntegrity();

                if (!isComplete)
                {
                    // 使用UI线程显示提示
                    SafeInvoke(() =>
                    {
                        DialogResult result = MessageBox.Show(this,
                            "⚠️ FFmpeg组件不完整\n\n" +
                            "检测到FFmpeg组件缺失或损坏，这可能会影响视频处理功能。\n" +
                            "是否现在自动下载并安装？\n\n" +
                            "注意：下载需要网络连接，文件大小约50-100MB。",
                            "FFmpeg组件缺失",
                            MessageBoxButtons.YesNo,
                            MessageBoxIcon.Warning);

                        if (result == DialogResult.Yes)
                        {
                            // 显示下载窗口
                            ShowFFmpegDownloadDialog();
                        }
                    });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"启动时检查FFmpeg失败: {ex.Message}");
            }
        }

        /// <summary>
        /// 显示FFmpeg下载对话框
        /// </summary>
        private void ShowFFmpegDownloadDialog()
        {
            FFmpegDownloadForm downloadForm = new FFmpegDownloadForm();
            downloadForm.ShowDialog();
        }

        #endregion

        #region 状态监控方法
        /// <summary>
        /// 驱动器基本状态类
        /// </summary>
        public class DriveBasicStatus
        {
            public string DriveName { get; set; }
            public string Status { get; set; } = "就绪";
            public string CurrentFile { get; set; } = "";
            public int TotalFiles { get; set; }
            public int ProcessedFiles { get; set; }
            public bool IsCopying { get; set; }
            public DateTime? StartTime { get; set; }
            public DateTime? EndTime { get; set; }
        }

        /// <summary>
        /// 初始化全局状态监控
        /// </summary>
        private void InitializeGlobalStatusMonitor()
        {
            globalStatusTimer = new System.Windows.Forms.Timer();
            globalStatusTimer.Interval = 20; // 20ms更新一次
            globalStatusTimer.Tick += GlobalStatusTimer_Tick;
            globalStatusTimer.Start();
        }

        /// <summary>
        /// 初始化速度更新定时器（修复版本）
        /// </summary>
        private void InitializeSpeedUpdateTimer()
        {
            speedUpdateTimer = new System.Windows.Forms.Timer
            {
                Interval = 500 // 500ms更新一次，避免过于频繁的UI更新
            };
            speedUpdateTimer.Tick += SpeedUpdateTimer_Tick;
        }

        /// <summary>
        /// 速度更新定时器事件（修复版本）
        /// </summary>
        private void SpeedUpdateTimer_Tick(object sender, EventArgs e)
        {
            UpdateSpeedDisplay();
            UpdateDataAmountDisplay(); // 同时更新数据量显示
        }

        /// <summary>
        /// 更新速度显示（修复版本）
        /// </summary>
        private void UpdateSpeedDisplay()
        {
            try
            {
                if (!isCopying || speedUpdateStartTime == DateTime.MinValue)
                    return;

                Label speedLabel = fixedControlPanel?.Controls.Find("speedLabel", false).FirstOrDefault() as Label;
                if (speedLabel == null) return;

                DateTime now = DateTime.Now;
                TimeSpan elapsed = now - speedUpdateLastTime;

                // 至少0.5秒更新一次，避免速度显示抖动
                if (elapsed.TotalSeconds < 0.5)
                    return;

                long currentBytes = speedUpdateTotalBytes;
                long bytesSinceLastUpdate = currentBytes - speedUpdateLastBytes;

                // 计算瞬时速度
                double instantSpeed = 0;
                if (elapsed.TotalSeconds > 0 && bytesSinceLastUpdate > 0)
                {
                    instantSpeed = bytesSinceLastUpdate / elapsed.TotalSeconds;
                }

                SafeInvoke(() =>
                {
                    if (instantSpeed > 0)
                    {
                        speedLabel.Text = $"速度: {FormatSpeed(instantSpeed)}";

                        // 根据速度设置颜色
                        if (instantSpeed > 50 * 1024 * 1024) // > 50 MB/s
                            speedLabel.ForeColor = Color.Green;
                        else if (instantSpeed > 10 * 1024 * 1024) // > 10 MB/s
                            speedLabel.ForeColor = Color.DarkGreen;
                        else if (instantSpeed > 1 * 1024 * 1024) // > 1 MB/s
                            speedLabel.ForeColor = Color.Orange;
                        else if (instantSpeed > 0)
                            speedLabel.ForeColor = Color.Red;
                        else
                            speedLabel.ForeColor = Color.DarkGreen;
                    }
                    else
                    {
                        speedLabel.Text = "速度: --";
                        speedLabel.ForeColor = Color.DarkGreen;
                    }
                });

                // 更新上次记录的值
                speedUpdateLastBytes = currentBytes;
                speedUpdateLastTime = now;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"更新速度显示时出错: {ex.Message}");
            }
        }

        /// <summary>
        /// 全局状态监控定时器事件
        /// </summary>
        private void GlobalStatusTimer_Tick(object sender, EventArgs e)
        {
            UpdateAllDriveBasicStatus();
        }

        /// <summary>
        /// 更新所有驱动器的基本状态
        /// </summary>
        private void UpdateAllDriveBasicStatus()
        {
            if (this.InvokeRequired)
            {
                // 使用BeginInvoke避免阻塞
                this.BeginInvoke(new Action(UpdateAllDriveBasicStatus));
                return;
            }

            // 限制更新频率
            foreach (Control control in mainPanel.Controls)
            {
                if (control is Panel panel && panel.Tag is DriveInfo drive)
                {
                    UpdateDriveBasicStatus(panel, drive);
                }
            }
        }

        /// <summary>
        /// 更新单个驱动器的基本状态
        /// </summary>
        private void UpdateDriveBasicStatus(Panel drivePanel, DriveInfo drive)
        {
            Label statusLabel = drivePanel.Controls.Find("basicStatusLabel", false).FirstOrDefault() as Label;
            if (statusLabel == null) return;

            string statusText = GetBasicStatusText(drive.Name);
            Color statusColor = GetBasicStatusColor(drive.Name);

            statusLabel.Text = statusText;
            statusLabel.ForeColor = statusColor;
        }

        /// <summary>
        /// 获取基本状态文本
        /// </summary>
        private string GetBasicStatusText(string driveName)
        {
            if (!driveBasicStatuses.ContainsKey(driveName))
            {
                return "💤 就绪";
            }

            var status = driveBasicStatuses[driveName];

            if (status.IsCopying)
            {
                string fileInfo = string.IsNullOrEmpty(status.CurrentFile) ?
                    "" : $" - {Path.GetFileName(status.CurrentFile)}";

                if (fileInfo.Length > 25)
                    fileInfo = fileInfo.Substring(0, 22) + "...";

                return $"🔄 {status.Status} ({status.ProcessedFiles}/{status.TotalFiles}){fileInfo}";
            }
            else if (status.EndTime.HasValue)
            {
                return $"就绪  ✅ 完成 ({status.TotalFiles} 文件)";
            }

            return "💤 就绪";
        }

        /// <summary>
        /// 获取基本状态颜色
        /// </summary>
        private Color GetBasicStatusColor(string driveName)
        {
            if (!driveBasicStatuses.ContainsKey(driveName))
            {
                return Color.Gray;
            }

            var status = driveBasicStatuses[driveName];

            if (status.IsCopying) return Color.DarkBlue;
            if (status.EndTime.HasValue)
            {
                return Color.Green;
            }

            return Color.Gray;
        }
        #endregion
    }
}