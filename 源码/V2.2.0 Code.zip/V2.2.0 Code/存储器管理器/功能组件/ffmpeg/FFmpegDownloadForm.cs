﻿using System;
using System.Drawing;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MediaCopyAssistant
{
    public partial class FFmpegDownloadForm : Form
    {
        private FFmpegManager ffmpegManager;
        private bool isDownloading = false;

        public FFmpegDownloadForm()
        {
            InitializeComponent();
            InitializeForm();
        }

        /// <summary>
        /// 获取默认字体
        /// </summary>
        private Font GetDefaultFont(float size, FontStyle style = FontStyle.Regular)
        {
            try
            {
                return new Font("得意黑", size + 1, style);
            }
            catch
            {
                return new Font("微软雅黑", size, style);
            }
        }

        private void InitializeForm()
        {
            this.Text = "FFmpeg组件下载";
            this.Size = new Size(500, 350);
            this.Icon = MediaCopyAssistant.Properties.Resources.ffmpeg安装管理器图标;
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            // 创建UI控件
            CreateControls();
        }

        private void CreateControls()
        {
            // 标题
            Label titleLabel = new Label()
            {
                Text = "FFmpeg组件下载",
                Font = GetDefaultFont(16, FontStyle.Bold),
                ForeColor = Color.DarkBlue,
                Location = new Point(20, 20),
                Size = new Size(450, 40),
                TextAlign = ContentAlignment.MiddleLeft
            };

            // 状态标签
            Label statusLabel = new Label()
            {
                Text = "准备下载...",
                Font = GetDefaultFont(10),
                Location = new Point(20, 70),
                Size = new Size(450, 30),
                TextAlign = ContentAlignment.MiddleLeft,
                Name = "statusLabel"
            };

            // 进度条
            ProgressBar progressBar = new ProgressBar()
            {
                Location = new Point(20, 110),
                Size = new Size(440, 30),
                Name = "progressBar"
            };

            // 进度标签
            Label progressLabel = new Label()
            {
                Text = "0%",
                Font = GetDefaultFont(10),
                Location = new Point(20, 150),
                Size = new Size(440, 30),
                TextAlign = ContentAlignment.MiddleCenter,
                Name = "progressLabel"
            };

            // 下载按钮
            Button downloadButton = new Button()
            {
                Text = "开始下载",
                Location = new Point(150, 200),
                Size = new Size(100, 40),
                BackColor = Color.LightBlue,
                Font = GetDefaultFont(10, FontStyle.Bold),
                Name = "downloadButton"
            };
            downloadButton.Click += DownloadButton_Click;

            // 取消按钮
            Button cancelButton = new Button()
            {
                Text = "取消",
                Location = new Point(260, 200),
                Size = new Size(100, 40),
                BackColor = Color.LightGray,
                Font = GetDefaultFont(10),
                Name = "cancelButton"
            };
            cancelButton.Click += (s, e) => this.Close();

            // 信息标签
            Label infoLabel = new Label()
            {
                Text = "FFmpeg是一个强大的多媒体处理工具，\n用于视频文件的处理和转换。",
                Font = GetDefaultFont(9),
                ForeColor = Color.Gray,
                Location = new Point(20, 250),
                Size = new Size(440, 50),
                TextAlign = ContentAlignment.MiddleLeft
            };

            // 添加控件
            this.Controls.Add(titleLabel);
            this.Controls.Add(statusLabel);
            this.Controls.Add(progressBar);
            this.Controls.Add(progressLabel);
            this.Controls.Add(downloadButton);
            this.Controls.Add(cancelButton);
            this.Controls.Add(infoLabel);
        }

        private async void DownloadButton_Click(object sender, EventArgs e)
        {
            if (isDownloading) return;

            Button downloadButton = this.Controls.Find("downloadButton", false)[0] as Button;
            Label statusLabel = this.Controls.Find("statusLabel", false)[0] as Label;
            ProgressBar progressBar = this.Controls.Find("progressBar", false)[0] as ProgressBar;
            Label progressLabel = this.Controls.Find("progressLabel", false)[0] as Label;

            isDownloading = true;
            downloadButton.Enabled = false;
            downloadButton.Text = "下载中...";

            ffmpegManager = new FFmpegManager();

            try
            {
                var progress = new Progress<int>(percent =>
                {
                    progressBar.Value = percent;
                    progressLabel.Text = $"{percent}%";
                });

                var status = new Progress<string>(message =>
                {
                    statusLabel.Text = message;
                });

                bool success = await ffmpegManager.DownloadAndInstallFFmpeg(progress, status);

                if (success)
                {
                    MessageBox.Show(this,
                        "✅ FFmpeg下载安装成功！\n\n" +
                        "所有组件已正确安装。\n" +
                        $"版本：{ffmpegManager.GetFFmpegVersion()}",
                        "安装完成",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);

                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    MessageBox.Show(this,
                        "❌ FFmpeg下载安装失败\n\n" +
                        "请检查网络连接后重试。",
                        "安装失败",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);

                    downloadButton.Enabled = true;
                    downloadButton.Text = "重试下载";
                    isDownloading = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this,
                    $"下载过程中出现错误：\n{ex.Message}",
                    "错误",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                downloadButton.Enabled = true;
                downloadButton.Text = "开始下载";
                isDownloading = false;
            }
        }
    }
}