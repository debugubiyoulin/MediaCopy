﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MediaCopyAssistant
{
    public partial class FFmpegManagerForm : Form
    {
        private FFmpegManager ffmpegManager;
        private Label versionLabel;
        private ListView componentList;
        private Label statusMessage;

        public FFmpegManagerForm()
        {
            InitializeComponent();
            InitializeForm();
        }

        /// <summary>
        /// 获取默认字体
        /// </summary>
        private Font GetDefaultFont(float size, FontStyle style = FontStyle.Regular)
        {
            try
            {
                return new Font("得意黑", size + 1, style);
            }
            catch
            {
                return new Font("微软雅黑", size, style);
            }
        }

        private void InitializeForm()
        {
            this.Text = "FFmpeg组件管理";
            this.Size = new Size(600, 400);
            this.Icon = MediaCopyAssistant.Properties.Resources.ffmpeg安装管理器图标;
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            // 创建UI控件
            CreateControls();
            RefreshStatus();
        }

        private void CreateControls()
        {
            // 标题
            Label titleLabel = new Label()
            {
                Text = "FFmpeg组件管理",
                Font = GetDefaultFont(16, FontStyle.Bold),
                ForeColor = Color.DarkBlue,
                Location = new Point(20, 20),
                Size = new Size(550, 40),
                TextAlign = ContentAlignment.MiddleLeft
            };

            // 状态组框
            GroupBox statusGroup = new GroupBox()
            {
                Text = "组件状态",
                Location = new Point(20, 70),
                Size = new Size(550, 150),
                Font = GetDefaultFont(10)
            };

            // 版本信息 - 存储为字段引用
            versionLabel = new Label()
            {
                Text = "版本：",
                Location = new Point(20, 30),
                Size = new Size(200, 25),
                Font = GetDefaultFont(10)
            };

            // 组件列表 - 存储为字段引用
            componentList = new ListView()
            {
                Location = new Point(20, 60),
                Size = new Size(500, 80),
                View = View.Details,
                FullRowSelect = true,
                GridLines = true
            };
            componentList.Columns.Add("组件名称", 200);
            componentList.Columns.Add("状态", 100);
            componentList.Columns.Add("大小", 100);

            statusGroup.Controls.Add(versionLabel);
            statusGroup.Controls.Add(componentList);

            // 操作按钮
            Button testButton = new Button()
            {
                Text = "🔍 测试完整性",
                Location = new Point(20, 240),
                Size = new Size(120, 35),
                BackColor = Color.LightBlue,
                Font = GetDefaultFont(10)
            };
            testButton.Click += TestButton_Click;

            Button downloadButton = new Button()
            {
                Text = "⬇️ 下载安装",
                Location = new Point(150, 240),
                Size = new Size(120, 35),
                BackColor = Color.LightGreen,
                Font = GetDefaultFont(10)
            };
            downloadButton.Click += DownloadButton_Click;

            Button deleteButton = new Button()
            {
                Text = "🗑️ 删除组件",
                Location = new Point(280, 240),
                Size = new Size(120, 35),
                BackColor = Color.LightCoral,
                Font = GetDefaultFont(10)
            };
            deleteButton.Click += DeleteButton_Click;

            Button refreshButton = new Button()
            {
                Text = "🔄 刷新状态",
                Location = new Point(410, 240),
                Size = new Size(120, 35),
                BackColor = Color.LightGray,
                Font = GetDefaultFont(10)
            };
            refreshButton.Click += (s, e) => RefreshStatus();

            // 状态消息 - 存储为字段引用
            statusMessage = new Label()
            {
                Text = "",
                Location = new Point(20, 290),
                Size = new Size(550, 50),
                Font = GetDefaultFont(9),
                ForeColor = Color.DarkRed,
                TextAlign = ContentAlignment.MiddleLeft
            };

            // 添加控件
            this.Controls.Add(titleLabel);
            this.Controls.Add(statusGroup);
            this.Controls.Add(testButton);
            this.Controls.Add(downloadButton);
            this.Controls.Add(deleteButton);
            this.Controls.Add(refreshButton);
            this.Controls.Add(statusMessage);
        }

        private void RefreshStatus()
        {
            ffmpegManager = new FFmpegManager();

            // 更新版本信息 - 直接使用字段引用
            if (versionLabel != null)
                versionLabel.Text = $"版本：{ffmpegManager.GetFFmpegVersion()}";

            // 更新组件列表 - 直接使用字段引用
            if (componentList != null)
            {
                componentList.Items.Clear();

                Dictionary<string, bool> componentStatus = ffmpegManager.GetComponentStatus();

                foreach (var component in componentStatus)
                {
                    ListViewItem item = new ListViewItem(component.Key);
                    item.SubItems.Add(component.Value ? "✅ 已安装" : "❌ 缺失");
                    item.SubItems.Add(GetFileSize(component.Key));
                    componentList.Items.Add(item);
                }
            }

            // 更新状态消息
            UpdateStatusMessage();
        }

        private string GetFileSize(string fileName)
        {
            try
            {
                // 更新路径：移除了"bin"目录
                string filePath = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Temp",
                    "MediaCopyAssistant",
                    "ffmpeg",  // 直接放在ffmpeg目录下
                    fileName);

                if (File.Exists(filePath))
                {
                    FileInfo info = new FileInfo(filePath);
                    return FormatFileSize(info.Length);
                }
            }
            catch { }

            return "N/A";
        }

        private string FormatFileSize(long bytes)
        {
            if (bytes < 1024) return $"{bytes} B";
            if (bytes < 1024 * 1024) return $"{(bytes / 1024.0):0.0} KB";
            return $"{(bytes / (1024.0 * 1024.0)):0.0} MB";
        }

        private void UpdateStatusMessage()
        {
            if (statusMessage != null && ffmpegManager != null)
            {
                bool isComplete = ffmpegManager.CheckFFmpegIntegrity();

                if (isComplete)
                {
                    statusMessage.Text = "✅ FFmpeg组件完整，所有功能可用。";
                    statusMessage.ForeColor = Color.DarkGreen;
                }
                else
                {
                    statusMessage.Text = "⚠️ FFmpeg组件不完整，部分功能可能无法使用。";
                    statusMessage.ForeColor = Color.Orange;
                }
            }
        }

        private void TestButton_Click(object sender, EventArgs e)
        {
            bool isComplete = ffmpegManager.CheckFFmpegIntegrity();

            MessageBox.Show(this,
                isComplete ?
                    "✅ FFmpeg完整性测试通过！\n\n所有组件正常工作。" :
                    "⚠️ FFmpeg完整性测试失败！\n\n检测到组件缺失或损坏。",
                "完整性测试",
                MessageBoxButtons.OK,
                isComplete ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
        }

        private void DownloadButton_Click(object sender, EventArgs e)
        {
            FFmpegDownloadForm downloadForm = new FFmpegDownloadForm();
            if (downloadForm.ShowDialog() == DialogResult.OK)
            {
                RefreshStatus();
            }
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(this,
                "⚠️ 确定要删除所有FFmpeg组件吗？\n\n" +
                "删除后，视频处理功能将不可用。\n" +
                "需要重新下载才能恢复功能。",
                "确认删除",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                bool success = ffmpegManager.DeleteFFmpegComponents();

                MessageBox.Show(this,
                    success ?
                        "✅ FFmpeg组件已删除。" :
                        "❌ 删除组件时发生错误。",
                    "删除结果",
                    MessageBoxButtons.OK,
                    success ? MessageBoxIcon.Information : MessageBoxIcon.Error);

                RefreshStatus();
            }
        }
    }
}