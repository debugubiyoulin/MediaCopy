﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace updatelog
{
    /// <summary>
    /// 独立的更新日志窗口
    /// </summary>
    public partial class UpdateLogForm : Form
    {
        private List<UpdateEntry> _updateLog;
        private Panel _contentPanel;

        public UpdateLogForm()
        {
            InitializeComponent();
            _updateLog = new List<UpdateEntry>();
            SetupUI();
            InitializeDefaultLog();
        }

        /// <summary>
        /// 获取默认字体
        /// </summary>
        private Font GetDefaultFont(float size, FontStyle style = FontStyle.Regular)
        {
            try
            {
                return new Font("得意黑", size + 2, style);
            }
            catch
            {
                return new Font("微软雅黑", size, style);
            }
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            this.Text = "更新日志";
            this.Size = new Size(650, 500);
            this.Icon = MediaCopyAssistant.Properties.Resources.媒体拷贝助手图标;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;
            this.ForeColor = Color.Black;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.KeyPreview = true;
            this.ResumeLayout(false);
        }

        private void SetupUI()
        {
            // 标题
            var titleLabel = new Label
            {
                Text = "更新日志",
                Font = GetDefaultFont(18, FontStyle.Bold),
                ForeColor = Color.DarkBlue,
                Location = new Point(20, 20),
                Size = new Size(300, 40)
            };
            this.Controls.Add(titleLabel);

            // 内容面板
            _contentPanel = new Panel
            {
                Location = new Point(20, 70),
                Size = new Size(600, 350),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                AutoScroll = true
            };
            this.Controls.Add(_contentPanel);

            // 关闭按钮
            var closeButton = new Button
            {
                Text = "关闭 (Esc)",
                Font = GetDefaultFont(10),
                Location = new Point(500, 430),
                Size = new Size(120, 35),
                BackColor = Color.LightGray,
                ForeColor = Color.Black
            };
            closeButton.Click += (s, e) => this.Close();
            this.Controls.Add(closeButton);

            // 键盘事件
            this.KeyDown += (s, e) => { if (e.KeyCode == Keys.Escape) this.Close(); };
        }

        private void InitializeDefaultLog()
        {
            _updateLog.Add(new UpdateEntry("V2.2.0", "2025-12-26",
                "新增一个小工具-影视建库工具",
                "完善了窗口的图标"));

            _updateLog.Add(new UpdateEntry("V2.1.10", "2025-12-20",
                "新增一个新的选项：资源管理",
                "新增对即将添加功能的支持，先保个密",
                "优化了字体不统一问题",
                "修复自动更新代码中的一点小问题，使更新更顺畅",
                "修复更新下载进度条不动，但可以完成更新问题",
                "修复自动更新不显示更新内容的问题"));

            _updateLog.Add(new UpdateEntry("V2.1.9", "2025-12-16",
                "新增自动更新",
                "新增拷贝数据信息提醒",
                "修复储存卡插入不能自动识别的问题",
                "修复拷贝完成后提示不明显的问题",
                "修复进度条显示不是总拷贝量的问题",
                "修复在视频文件拷贝时，拷贝速度不是实时显示的当前速度的问题"));

            _updateLog.Add(new UpdateEntry("V2.1.8", "2025-12-4",
                "删除哈希校验，因为这个东西带来了许多BUG",
                "删除小叉车快跑暂停功能",
                "重写了小叉车快跑",
                "修复小叉车快跑重置关卡速度问题",
                "修复小游戏图标问题",
                "把小叉车快跑更改到贪吃蛇前面"));

            _updateLog.Add(new UpdateEntry("V2.1.7", "2025-12-4",
                "新增拷贝速度显示",
                "更名为媒体拷贝助手-MediaCopy",
                "更改应用图标",
                "重写快速使用说明",
                "完善程序集信息",
                "修复驱动盘状态显示后台不动的问题",
                "修复了拷贝文件数量统计异常问题(修复上一个问题带来的)",
                "修复了进度条更新异常问题(修复上一个问题带来的)",
                "修复了备份文件计数问题，会影响进度条显示(修复上一个问题带来的)",
                "修复了各种计数组件打架的问题(修复上一个问题带来的)",
                "修复了资源泄漏问题",
                "修复了UI线程阻塞问题",
                "整理代码"));

            _updateLog.Add(new UpdateEntry("V2.1.6", "2025-11-24",
                "新增哈希校验，可以验证文件是否损坏",
                "新增驱动盘状态显示",
                "修复了中途停止拷贝卡按钮问题",
                "修复了文件分类整理工具过程中可以重置的问题",
                "修复了一个持续了八个版本的下栏没有对齐的问题"));

            _updateLog.Add(new UpdateEntry("V2.1.5", "2025-11-19",
                "删除网络时间相关组件",
                "删除小游戏-吃豆人",
                "删除文件菜单",
                "删除设置菜单",
                "将帮助里的关于和使用说明合成一个",
                "整理代码",
                "因为没做好一个功能，睡不着了"));

            _updateLog.Add(new UpdateEntry("V2.1.4", "2025-11-13",
                "新增小工具-文件分类整理工具的使用说明和预览",
                "新增小工具-文件分类整理工具整理方式",
                "新增小工具-文件分类整理工具对相机RAW格式文件支持",
                "睡了一个好觉"));

            _updateLog.Add(new UpdateEntry("V2.1.3", "2025-11-09",
                "修复了图标显示问题"));

            _updateLog.Add(new UpdateEntry("V2.1.2", "2025-11-09",
                "新增空间检测功能，避免了拷贝过程中因空间不足导致的失败",
                "给小工具-文件分类整理工具增加忽略子文件夹功能",
                "增加版权信息",
                "吃了一根烤肠"));

            _updateLog.Add(new UpdateEntry("V2.1.1", "2025-11-07",
                "新增小工具-文件分类整理",
                "新增所有窗口图标",
                "限制窗口大小和禁止最大化",
                "测试网络获得时间戳成功"));

            _updateLog.Add(new UpdateEntry("V2.1.0", "2025-11-05",
                "添加从网络获得时间戳选项",
                "优化了代码中的问题",
                "修复版本号异常问题"));

            _updateLog.Add(new UpdateEntry("V2.0.6", "2025-11-02",
                "修复吃豆人幽灵AI问题",
                "添加更新日志"));

            _updateLog.Add(new UpdateEntry("V2.0.5", "2025-11-02",
                "修改上层状态栏",
                "添加小游戏（吃豆人）"));

            _updateLog.Add(new UpdateEntry("V2.0.4", "2025-10-19",
                "添加小游戏（小（叉）车快跑）",
                "修复图层问题"));

            _updateLog.Add(new UpdateEntry("V2.0.3", "2025-10-19",
                "增加上层菜单栏",
                "添加小游戏（贪吃蛇）",
                "修复已知问题"));

            _updateLog.Add(new UpdateEntry("V2.0.1", "2025-10-15",
                "修复已知问题"));

            _updateLog.Add(new UpdateEntry("V2.0.0", "2025-10-12",
                "重写图形化界面",
                "新增更详细的视频照片导出能力",
                "新增智能打包"));

            _updateLog.Add(new UpdateEntry("V1.0", "2025-10-08",
                "更改语言为C#",
                "添加图形化界面"));

            _updateLog.Add(new UpdateEntry("V0.1", "2025-10-06",
                "初始版本发布",
                "通过BAT文件实现基础功能"));

            RefreshContent();
        }

        private void RefreshContent()
        {
            _contentPanel.SuspendLayout();
            _contentPanel.Controls.Clear();

            int currentY = 20;

            // 从新到旧显示
            for (int i = 0; i < _updateLog.Count; i++)
            {
                var update = _updateLog[i];

                // 版本标题
                var versionLabel = new Label
                {
                    Text = $"{update.Version} - {update.Date}",
                    Font = GetDefaultFont(12, FontStyle.Bold),
                    ForeColor = Color.DarkBlue,
                    Location = new Point(20, currentY),
                    Size = new Size(550, 25)
                };
                _contentPanel.Controls.Add(versionLabel);
                currentY += 30;

                // 更新内容
                foreach (var change in update.Changes)
                {
                    var changeLabel = new Label
                    {
                        Text = $"• {change}",
                        Font = GetDefaultFont(9),
                        ForeColor = Color.Black,
                        Location = new Point(20, currentY),
                        Size = new Size(550, 20)
                    };
                    _contentPanel.Controls.Add(changeLabel);
                    currentY += 22;
                }

                // 添加分隔线（除了最后一个）
                if (i < _updateLog.Count - 1)
                {
                    currentY += 10;
                    var separator = new Panel
                    {
                        BackColor = Color.LightGray,
                        Location = new Point(20, currentY),
                        Size = new Size(550, 1)
                    };
                    _contentPanel.Controls.Add(separator);
                    currentY += 20;
                }
            }

            _contentPanel.ResumeLayout();
        }

        /// <summary>
        /// 更新日志条目
        /// </summary>
        public class UpdateEntry
        {
            public string Version { get; set; }
            public string Date { get; set; }
            public List<string> Changes { get; set; }

            public UpdateEntry(string version, string date, params string[] changes)
            {
                Version = version;
                Date = date;
                Changes = new List<string>(changes);
            }
        }

        /// <summary>
        /// 添加更新日志
        /// </summary>
        public void AddUpdate(string version, string date, params string[] changes)
        {
            _updateLog.Insert(0, new UpdateEntry(version, date, changes));
            RefreshContent();
        }

        /// <summary>
        /// 显示更新日志窗口
        /// </summary>
        public static void ShowUpdateLog()
        {
            using (var updateForm = new UpdateLogForm())
            {
                updateForm.ShowDialog();
            }
        }
    }
}