﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace MediaCopyAssistant
{
    public class AutoUpdater
    {
        // 当前版本
        public static Version CurrentVersion = new Version("2.2.0");

        // 配置信息 - 请修改为您的实际信息
        private const string GitHubUsername = "debugubiyoulin";
        private const string GiteeUsername = "debugubiyoulinll";
        private const string RepositoryName = "MediaCopyAssistant";

        // API地址
        private static readonly string GitHubApiUrl = "https://api.github.com/repos/" + GitHubUsername + "/" + RepositoryName + "/releases/latest";
        private static readonly string GiteeApiUrl = "https://gitee.com/api/v5/repos/" + GiteeUsername + "/" + RepositoryName + "/releases/latest";

        public class UpdateInfo
        {
            public bool IsUpdateAvailable { get; set; }
            public Version LatestVersion { get; set; }
            public string DownloadUrl { get; set; }
            public string ReleaseNotes { get; set; }
            public DateTime ReleaseDate { get; set; }
            public string Source { get; set; }
        }

        /// <summary>
        /// 检查更新（双源检查）
        /// </summary>
        public UpdateInfo CheckForUpdates()
        {
            try
            {
                Console.WriteLine("=== 开始检查更新 ===");

                // 同时检查GitHub和Gitee，选择最先响应的
                UpdateInfo githubInfo = CheckGitHub();
                UpdateInfo giteeInfo = CheckGitee();

                // 优先使用有更新的源
                if (githubInfo != null && githubInfo.IsUpdateAvailable)
                {
                    Console.WriteLine($"✅ 选择GitHub源，版本: v{githubInfo.LatestVersion}");
                    return githubInfo;
                }

                if (giteeInfo != null && giteeInfo.IsUpdateAvailable)
                {
                    Console.WriteLine($"✅ 选择Gitee源，版本: v{giteeInfo.LatestVersion}");
                    return giteeInfo;
                }

                // 如果都没有更新，返回一个未更新的信息
                UpdateInfo latestInfo = githubInfo ?? giteeInfo;
                if (latestInfo != null)
                {
                    return new UpdateInfo
                    {
                        IsUpdateAvailable = false,
                        LatestVersion = latestInfo.LatestVersion,
                        Source = latestInfo.Source
                    };
                }

                return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"检查更新失败: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// 检查GitHub更新
        /// </summary>
        private UpdateInfo CheckGitHub()
        {
            try
            {
                Console.WriteLine("检查GitHub更新...");

                using (WebClient client = CreateWebClient())
                {
                    client.Headers.Add("User-Agent", "MediaCopyAssistant");
                    client.Headers.Add("Accept", "application/vnd.github.v3+json");

                    string json = client.DownloadString(GitHubApiUrl);
                    Console.WriteLine($"GitHub响应长度: {json.Length}");

                    return ParseGitHubResponse(json);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"GitHub检查失败: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// 检查Gitee更新
        /// </summary>
        private UpdateInfo CheckGitee()
        {
            try
            {
                Console.WriteLine("检查Gitee更新...");

                using (WebClient client = CreateWebClient())
                {
                    string json = client.DownloadString(GiteeApiUrl);
                    Console.WriteLine($"Gitee响应长度: {json.Length}");

                    return ParseGiteeResponse(json);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Gitee检查失败: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// 解析GitHub响应
        /// </summary>
        private UpdateInfo ParseGitHubResponse(string json)
        {
            try
            {
                // 提取版本号
                string versionString = ExtractJsonValue(json, "tag_name");
                if (string.IsNullOrEmpty(versionString))
                {
                    Console.WriteLine("未找到tag_name字段");
                    return null;
                }

                // 清理版本号
                versionString = CleanVersionString(versionString);

                // 解析版本
                Version latestVersion;
                if (!Version.TryParse(versionString, out latestVersion))
                {
                    Console.WriteLine($"无法解析版本号: {versionString}");
                    return null;
                }

                Console.WriteLine($"GitHub版本: {versionString}");

                // 提取下载链接
                string downloadUrl = ExtractDownloadUrlFromGitHub(json);
                if (string.IsNullOrEmpty(downloadUrl))
                {
                    Console.WriteLine("未找到下载链接");
                    return null;
                }

                Console.WriteLine($"GitHub下载链接: {downloadUrl}");

                // 提取发布日期
                DateTime releaseDate = DateTime.Now;
                string dateString = ExtractJsonValue(json, "published_at");
                if (!string.IsNullOrEmpty(dateString))
                {
                    DateTime.TryParse(dateString, out releaseDate);
                }

                // 提取更新说明
                string releaseNotes = ExtractJsonValue(json, "body");
                if (string.IsNullOrEmpty(releaseNotes))
                {
                    releaseNotes = "无更新说明";
                }

                return new UpdateInfo
                {
                    IsUpdateAvailable = latestVersion > CurrentVersion,
                    LatestVersion = latestVersion,
                    DownloadUrl = downloadUrl,
                    ReleaseNotes = releaseNotes,
                    ReleaseDate = releaseDate,
                    Source = "GitHub"
                };
            }
            catch (Exception ex)
            {
                Console.WriteLine($"解析GitHub响应失败: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// 解析Gitee响应
        /// </summary>
        private UpdateInfo ParseGiteeResponse(string json)
        {
            try
            {
                // 提取版本号
                string versionString = ExtractJsonValue(json, "tag_name");
                if (string.IsNullOrEmpty(versionString))
                {
                    Console.WriteLine("未找到tag_name字段");
                    return null;
                }

                // 清理版本号
                versionString = CleanVersionString(versionString);

                // 解析版本
                Version latestVersion;
                if (!Version.TryParse(versionString, out latestVersion))
                {
                    Console.WriteLine($"无法解析版本号: {versionString}");
                    return null;
                }

                Console.WriteLine($"Gitee版本: {versionString}");

                // 提取下载链接
                string downloadUrl = ExtractDownloadUrlFromGitee(json);
                if (string.IsNullOrEmpty(downloadUrl))
                {
                    Console.WriteLine("未找到下载链接");
                    return null;
                }

                Console.WriteLine($"Gitee下载链接: {downloadUrl}");

                // 提取发布日期
                DateTime releaseDate = DateTime.Now;
                string dateString = ExtractJsonValue(json, "created_at");
                if (!string.IsNullOrEmpty(dateString))
                {
                    DateTime.TryParse(dateString, out releaseDate);
                }

                // 提取更新说明
                string releaseNotes = ExtractJsonValue(json, "body");
                if (string.IsNullOrEmpty(releaseNotes))
                {
                    releaseNotes = "无更新说明";
                }

                return new UpdateInfo
                {
                    IsUpdateAvailable = latestVersion > CurrentVersion,
                    LatestVersion = latestVersion,
                    DownloadUrl = downloadUrl,
                    ReleaseNotes = releaseNotes,
                    ReleaseDate = releaseDate,
                    Source = "Gitee"
                };
            }
            catch (Exception ex)
            {
                Console.WriteLine($"解析Gitee响应失败: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// 从GitHub JSON中提取下载链接
        /// </summary>
        private string ExtractDownloadUrlFromGitHub(string json)
        {
            try
            {
                // 查找assets数组
                int assetsStart = json.IndexOf("\"assets\":[");
                if (assetsStart == -1)
                {
                    Console.WriteLine("未找到assets数组，尝试使用模板生成链接");
                    return GenerateGitHubDownloadUrl();
                }

                // 查找第一个assets项
                int assetStart = json.IndexOf("{", assetsStart);
                if (assetStart == -1)
                {
                    Console.WriteLine("未找到assets项");
                    return GenerateGitHubDownloadUrl();
                }

                // 查找browser_download_url
                int urlStart = json.IndexOf("\"browser_download_url\":\"", assetStart);
                if (urlStart == -1)
                {
                    Console.WriteLine("未找到browser_download_url");
                    return GenerateGitHubDownloadUrl();
                }

                urlStart += "\"browser_download_url\":\"".Length;
                int urlEnd = json.IndexOf("\"", urlStart);

                if (urlEnd == -1)
                {
                    Console.WriteLine("未找到URL结束引号");
                    return GenerateGitHubDownloadUrl();
                }

                string url = json.Substring(urlStart, urlEnd - urlStart);

                // 验证URL是否有效
                if (!url.StartsWith("http"))
                {
                    Console.WriteLine($"下载链接格式不正确: {url}");
                    return GenerateGitHubDownloadUrl();
                }

                return url;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"提取下载链接失败: {ex.Message}");
                return GenerateGitHubDownloadUrl();
            }
        }

        /// <summary>
        /// 从Gitee JSON中提取下载链接
        /// </summary>
        private string ExtractDownloadUrlFromGitee(string json)
        {
            try
            {
                // Gitee的格式略有不同
                // 查找assets数组
                int assetsStart = json.IndexOf("\"assets\":[");
                if (assetsStart == -1)
                {
                    Console.WriteLine("未找到assets数组，尝试使用模板生成链接");
                    return GenerateGiteeDownloadUrl();
                }

                // 查找第一个assets项
                int assetStart = json.IndexOf("{", assetsStart);
                if (assetStart == -1)
                {
                    Console.WriteLine("未找到assets项");
                    return GenerateGiteeDownloadUrl();
                }

                // 查找browser_download_url
                int urlStart = json.IndexOf("\"browser_download_url\":\"", assetStart);
                if (urlStart == -1)
                {
                    // Gitee可能使用不同的字段名
                    urlStart = json.IndexOf("\"download_url\":\"", assetStart);
                    if (urlStart == -1)
                    {
                        Console.WriteLine("未找到下载链接字段");
                        return GenerateGiteeDownloadUrl();
                    }
                    urlStart += "\"download_url\":\"".Length;
                }
                else
                {
                    urlStart += "\"browser_download_url\":\"".Length;
                }

                int urlEnd = json.IndexOf("\"", urlStart);

                if (urlEnd == -1)
                {
                    Console.WriteLine("未找到URL结束引号");
                    return GenerateGiteeDownloadUrl();
                }

                string url = json.Substring(urlStart, urlEnd - urlStart);

                // 验证URL是否有效
                if (!url.StartsWith("http"))
                {
                    Console.WriteLine($"下载链接格式不正确: {url}");
                    return GenerateGiteeDownloadUrl();
                }

                return url;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"提取下载链接失败: {ex.Message}");
                return GenerateGiteeDownloadUrl();
            }
        }

        /// <summary>
        /// 生成GitHub下载链接（备用）
        /// </summary>
        private string GenerateGitHubDownloadUrl()
        {
            // 假设文件命名格式为：MediaCopyAssistant_V版本号.exe
            // 例如：MediaCopyAssistant_V2_2_0.exe
            return $"https://github.com/{GitHubUsername}/{RepositoryName}/releases/download/latest/MediaCopyAssistant.exe";
        }

        /// <summary>
        /// 生成Gitee下载链接（备用）
        /// </summary>
        private string GenerateGiteeDownloadUrl()
        {
            // 假设文件命名格式为：MediaCopyAssistant_V版本号.exe
            return $"https://gitee.com/{GiteeUsername}/{RepositoryName}/releases/download/latest/MediaCopyAssistant.exe";
        }

        /// <summary>
        /// 提取JSON值
        /// </summary>
        private string ExtractJsonValue(string json, string key)
        {
            try
            {
                string searchKey = $"\"{key}\":\"";
                int start = json.IndexOf(searchKey);
                if (start == -1)
                {
                    // 尝试不带引号
                    searchKey = $"\"{key}\":";
                    start = json.IndexOf(searchKey);
                    if (start == -1) return null;

                    start += searchKey.Length;
                    // 跳过空格
                    while (start < json.Length && char.IsWhiteSpace(json[start]))
                        start++;

                    // 检查值类型
                    if (start < json.Length)
                    {
                        if (json[start] == '"')
                        {
                            start++;
                            int end = json.IndexOf("\"", start);
                            if (end == -1) return null;
                            return json.Substring(start, end - start);
                        }
                        else if (json[start] == 'n' && json.Substring(start, 4) == "null")
                        {
                            return null;
                        }
                    }
                    return null;
                }

                start += searchKey.Length;
                int end2 = json.IndexOf("\"", start);
                if (end2 == -1) return null;

                return json.Substring(start, end2 - start);
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// 清理版本字符串
        /// </summary>
        private string CleanVersionString(string version)
        {
            if (string.IsNullOrEmpty(version)) return "1.0.0";

            // 移除常见的版本前缀
            string[] prefixes = { "v", "V", "version", "Version", "release-", "Release-" };

            foreach (string prefix in prefixes)
            {
                if (version.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                {
                    version = version.Substring(prefix.Length);
                }
            }

            // 移除空格
            version = version.Trim();

            return version;
        }

        /// <summary>
        /// 创建WebClient
        /// </summary>
        private WebClient CreateWebClient()
        {
            WebClient client = new WebClient();
            client.Encoding = System.Text.Encoding.UTF8;
            client.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");
            return client;
        }

        /// <summary>
        /// 下载并更新程序
        /// </summary>
        public bool DownloadAndUpdate(string downloadUrl, Version newVersion, Action<int> progressCallback = null)
        {
            try
            {
                Console.WriteLine($"=== 开始下载更新 ===");
                Console.WriteLine($"下载链接: {downloadUrl}");
                Console.WriteLine($"新版本: {newVersion}");

                // 获取当前程序目录和文件名
                string currentExePath = Process.GetCurrentProcess().MainModule.FileName;
                string currentDir = Path.GetDirectoryName(currentExePath);
                string currentExeName = Path.GetFileName(currentExePath);

                Console.WriteLine($"当前程序路径: {currentExePath}");
                Console.WriteLine($"当前程序目录: {currentDir}");
                Console.WriteLine($"当前程序文件名: {currentExeName}");

                // 新文件直接下载到当前程序目录，并加上.temp扩展名
                string tempFilePath = Path.Combine(currentDir, currentExeName + ".temp");
                Console.WriteLine($"临时下载文件: {tempFilePath}");

                // 如果已存在临时文件，先删除
                if (File.Exists(tempFilePath))
                {
                    File.Delete(tempFilePath);
                    Console.WriteLine($"删除已存在的临时文件");
                }

                // 下载文件
                Console.WriteLine($"开始下载...");
                using (WebClient client = CreateWebClient())
                {
                    if (progressCallback != null)
                    {
                        client.DownloadProgressChanged += (s, e) =>
                        {
                            progressCallback(e.ProgressPercentage);
                        };
                    }

                    client.DownloadFile(downloadUrl, tempFilePath);
                }

                // 验证文件
                Console.WriteLine($"下载完成，验证文件...");
                if (!File.Exists(tempFilePath))
                {
                    throw new Exception("下载的文件不存在");
                }

                FileInfo fileInfo = new FileInfo(tempFilePath);
                Console.WriteLine($"文件大小: {fileInfo.Length} bytes ({fileInfo.Length / 1024.0 / 1024.0:F2} MB)");

                // 检查文件大小
                if (fileInfo.Length < 1024 * 100) // 小于100KB
                {
                    // 可能是HTML错误页面
                    string content = File.ReadAllText(tempFilePath);
                    if (content.Contains("<html") || content.Contains("<!DOCTYPE") || content.Contains("404"))
                    {
                        throw new Exception($"下载的不是可执行文件，可能是错误页面。文件大小: {fileInfo.Length} bytes");
                    }
                    throw new Exception($"文件大小异常: {fileInfo.Length} bytes，可能不是完整的可执行文件");
                }

                // 检查文件头
                byte[] header = new byte[2];
                using (FileStream fs = new FileStream(tempFilePath, FileMode.Open, FileAccess.Read))
                {
                    fs.Read(header, 0, 2);
                }

                bool isExecutable = (header[0] == 0x4D && header[1] == 0x5A); // MZ
                Console.WriteLine($"文件头: {header[0]:X2} {header[1]:X2} (可执行文件: {isExecutable})");

                if (!isExecutable)
                {
                    Console.WriteLine("警告: 文件可能不是标准的Windows可执行文件");
                }

                Console.WriteLine($"文件验证通过");

                // 创建更新脚本
                string updateScript = CreateUpdateScript(tempFilePath, currentExePath);
                string scriptPath = Path.Combine(currentDir, "update.bat");

                // 使用正确的编码（GB2312/936），避免中文乱码
                Encoding gb2312 = Encoding.GetEncoding(936);
                File.WriteAllText(scriptPath, updateScript, gb2312);
                Console.WriteLine($"创建更新脚本: {scriptPath}");

                // 启动更新脚本
                Console.WriteLine($"启动更新脚本...");
                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = $"/c \"{scriptPath}\"",
                    UseShellExecute = true,
                    WindowStyle = ProcessWindowStyle.Hidden, // 隐藏窗口
                    Verb = "runas" // 请求管理员权限（如果需要）
                };

                Process.Start(psi);
                Console.WriteLine($"更新脚本已启动，程序将退出");

                // 立即退出程序，让更新脚本接管
                Environment.Exit(0);

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"下载更新失败: {ex.Message}");
                Console.WriteLine($"堆栈跟踪: {ex.StackTrace}");

                MessageBox.Show($"下载更新失败:\n{ex.Message}", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        /// <summary>
        /// 创建更新脚本
        /// </summary>
        private string CreateUpdateScript(string tempFilePath, string currentExePath)
        {
            // 获取当前程序信息
            string currentDir = Path.GetDirectoryName(currentExePath);
            string currentExeName = Path.GetFileName(currentExePath);

            // 新版本文件名（与原文件同名）
            string newExePath = currentExePath;
            string newExeName = currentExeName;

            // 简单的更新脚本
            string script = @"
@echo off
chcp 936 >nul
title 媒体拷贝助手 - 更新程序
echo ========================================
echo       媒体拷贝助手 - 自动更新
echo ========================================
echo.

:: 等待原程序完全退出
echo 正在等待程序退出...
timeout /t 2 /nobreak >nul

:: 尝试删除原程序文件
echo 正在替换旧版本...
del /F /Q """ + currentExePath + @""" 2>nul

:: 检查是否删除成功
if exist """ + currentExePath + @""" (
    echo 删除旧版本失败，可能是文件仍在使用中
    echo 正在重试...
    timeout /t 2 /nobreak >nul
    del /F /Q """ + currentExePath + @""" 2>nul
    
    if exist """ + currentExePath + @""" (
        echo 仍然无法删除旧版本，请手动删除后重试
        echo 文件位置: """ + currentExePath + @"""
        pause
        exit /b 1
    )
)

echo 旧版本已删除

:: 重命名临时文件为新版本
echo 正在安装新版本...
ren """ + tempFilePath + @""" """ + newExeName + @""" 2>nul

if not exist """ + newExePath + @""" (
    echo 重命名失败，尝试直接复制...
    copy /Y """ + tempFilePath + @""" """ + newExePath + @""" 2>nul
    
    if not exist """ + newExePath + @""" (
        echo 错误：安装新版本失败！
        echo 请手动将文件复制到程序目录
        echo 源文件: """ + tempFilePath + @"""
        echo 目标文件: """ + newExePath + @"""
        pause
        exit /b 1
    )
    
    :: 删除临时文件
    del /F /Q """ + tempFilePath + @""" 2>nul
)

echo 新版本安装成功！

:: 启动新版本
echo 正在启动新版本...
timeout /t 1 /nobreak >nul

:: 切换到程序目录
cd /d """ + currentDir + @"""

:: 启动新程序
start "" """ + newExePath + @"""

echo.
echo 更新完成！
echo 窗口将在3秒后自动关闭...
timeout /t 3 /nobreak >nul
exit
";

            return script;
        }

        /// <summary>
        /// 生成新文件名
        /// </summary>
        public static string GenerateNewFileName(Version version)
        {
            return $"媒体拷贝助手 - MediaCopy V{version}.exe";
        }

        /// <summary>
        /// 从文件名中提取版本号
        /// </summary>
        public static Version ExtractVersionFromFileName(string fileName)
        {
            try
            {
                // 匹配 V1.2.3 或 V1_2_3 格式
                Match match = Regex.Match(fileName, @"V(\d+)[._](\d+)(?:[._](\d+))?(?:[._](\d+))?", RegexOptions.IgnoreCase);

                if (match.Success)
                {
                    int major = int.Parse(match.Groups[1].Value);
                    int minor = int.Parse(match.Groups[2].Value);
                    int build = match.Groups[3].Success ? int.Parse(match.Groups[3].Value) : 0;
                    int revision = match.Groups[4].Success ? int.Parse(match.Groups[4].Value) : 0;

                    if (revision > 0)
                        return new Version(major, minor, build, revision);
                    else if (build > 0)
                        return new Version(major, minor, build);
                    else
                        return new Version(major, minor);
                }
            }
            catch
            {
                // 忽略错误
            }

            return null;
        }

        /// <summary>
        /// 获取最佳的更新源
        /// </summary>
        public static string GetBestSourceInfo()
        {
            return "GitHub 和 Gitee 双源";
        }
    }
}